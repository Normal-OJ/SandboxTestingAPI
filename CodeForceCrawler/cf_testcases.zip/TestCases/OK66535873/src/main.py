t = int(input())
while t > 0:
    t = t - 1
    s = input()
    if len(s) == 1:
        if s[0] == '?':
            print('a')
        else:
            print(s)
        continue
    ok = True
    l = 'd'
    ans = ""
    for i in range(len(s) - 1):
        if s[i] != '?':
            ans += s[i]
            if s[i] == l or s[i] == s[i+1]:
                ok = False
                break
        else:
            if l == 'a' or s[i+1] == 'a':
                if l == 'b' or s[i+1] == 'b':
                    ans += 'c'
                else:
                    ans += 'b'
            else:
                ans += 'a'
        l = ans[i]
    if(s[len(s) - 1] == '?'):
        if ans[len(ans)-1] != 'a':
            ans += 'a'
        elif ans[len(ans)-1] != 'b':
            ans += 'b'
        elif ans[len(ans)-1] != 'c':
            ans += 'c'
    else:
        ans += s[len(s) - 1]
    if ok:
        print(ans)
    else:
        print("-1")
