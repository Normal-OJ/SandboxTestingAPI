

n=int(input())
for i in range(n):
    k=int(input())
    l1=list(map(int,input().split()))

    for i in range(len(l1)):
        a=i+1  #a=3
        tempa=l1.index(a)
        ctr=0
        l2=[x for x in range(1,a+1)]
        for j in range(1,a):
            ind=l1.index(j)
            
            for k in range(min(ind,tempa),max(ind,tempa)):
                if(l1[k] not in l2):
                    ctr=1
                    break
        if(ctr==0):
            print(1,end="")
        else:
            print(0,end="")
                