#include<iostream>
#include<cstdio>
#include<cstring>
#include<map>
using namespace std;
int a[400005];
int main(){
    int t, i, j, k, n;
    cin>>t;
    while(t--){
        map<int,int> m;
        memset(a,0,sizeof(a));
        m.clear();
        int x;
        int sum = 0;
        cin >> n;
        for (i = 0; i < n;++i){
            scanf("%d", &x);
            if(!m[x]){
                a[sum++] = x;
            }
            ++m[x];
        }
        int g = 0, s = 0, b = 0;
        g = m[a[0]];
        s = m[a[1]];
        for (i = 2; i < sum;++i){
            if (g + s + b + m[a[i]] > n / 2)
                break;
            if (s <= g)
                s += m[a[i]];
            else
                b += m[a[i]];
        }
        if (g < s && g < b && g+s+b <= n/2){
            printf("%d %d %d\n", g, s, b);
        }
        else
            printf("0 0 0\n");
    }
    return 0;
}
	 		 	  		 	 	 	  			     	