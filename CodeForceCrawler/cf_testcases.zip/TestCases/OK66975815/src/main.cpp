#include<bits/stdc++.h>
#define ll long long
#define int ll
#define mp make_pair
#define pii pair<int,int>
#define pb push_back
#define r1 rt<<1
#define r2 rt<<1|1
#define fi first
#define se second
#define db double
#define ld long db
#define ri register int
#define rep(i,a,b) for(ri i=(a);i<=(b);++i)
#define rep2(i,a,b,c) for(ri i=(a);i<=(b);i+=(c))
#define REP(i,a,b) for(ri i=(a);i>=(b);--i)
#define REP2(i,a,b,c) for(ri i=(a);i>=(b);i-=(c))
using namespace std;

inline ll read(){
	ll x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9') x=(x<<1)+(x<<3)+(c^'0'),c=getchar();
	return x*f;
}
int a[600000];
signed main()
{
	ri t=read();
	while(t--){
		ri n=read(),m=n>>1;
		rep(i,1,n)a[i]=read();
		while(a[m]==a[m+1])--m;
		ri x=1,y,z;
		while(x<=m&&a[x]==a[x+1])++x;
		y=x+1;
		while(x+y<=m&&a[x+y]==a[x+y+1])++y;
		z=m-x-y;
		if(x<y&&x<z&x>0&&y>0&&z>0)cout<<x<<' '<<y<<' '<<z<<endl;
		else cout<<0<<' '<<0<<' '<<0<<endl;
	}
	return 0; 
}
