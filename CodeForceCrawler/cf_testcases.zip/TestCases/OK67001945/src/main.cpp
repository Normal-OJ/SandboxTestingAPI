#include<iostream>
#include<vector>
using namespace std;
int n, t;
vector<int> p;
int main(){
	cin >> t;
	for(int qwq = 1; qwq <= t; qwq++){
		cin >> n;
		p.clear();
		int y = 0, cnt = 0;
		for(int i = 0; i < n; i++) {
			int x;
			cin >> x;
			if(x != y){
				if(y) p.push_back(cnt);
				y = x, cnt = 1;
			}else cnt++;
		}
		p.push_back(cnt);
		
		if(n <= 5) {
			cout << "0 0 0" <<endl;
			continue;
		}
		
		int g = p[0], s = 0, i = 1;
		bool flag = false;
		while(i < p.size() && s <= g) s += p[i++];
		
		if(g < s){
			int b = 0;
			while(i < p.size() && b <= g) b += p[i++];
			while(i < p.size() && g + s + b + p[i] <= n / 2) b += p[i++];
			if(b > g && g + s + b <= n / 2){
				flag = true;
				cout << g << " " << s << " " << b <<endl;
			}
		}
		
		if(!flag) cout << 0 << " " << 0 << " " << 0 << endl;
	}
	return 0;
}