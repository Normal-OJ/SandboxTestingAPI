#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define forr(i,a,b) for( int i=(a) ; i<=(b) ; ++i)
#define ford(i,a,b) for( int i=(a) ; i>=(b) ; --i)
#define ll long long
#define pii pair<long long ,long long>
#define mp make_pair
#define f first
#define s second
#define task "1265A"
template <typename T> inline void read(T &x){char c;bool nega=0;while((!isdigit(c=getchar()))&&(c!='-'));if(c=='-'){nega=1;c=getchar();}x=c-48;while(isdigit(c=getchar())) x=x*10+c-48;if(nega) x=-x;}
template <typename T> inline void writep(T x){if(x>9) writep(x/10);putchar(x%10+48);}
template <typename T> inline void write(T x){if(x<0){putchar('-');x=-x;}writep(x);putchar(' ');}
template <typename T> inline void writeln(T x){write(x);putchar('\n');}

using namespace std;
using namespace __gnu_pbds;
typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> ordered_set;

const long long mod=1e9+7;
const long pp=3e5;

int n,m,k ;
int a[pp],b[pp] ;

long long dp[pp] ;

string S ;

void dowork()
{
    cin>>S;
    int n=S.length();
    if(n==1)
    {
        if(S[0]=='?') cout<< 'a';
        else cout<< S;
        cout<< endl;
        return ;
    }else
    {
        S="+"+S+"+";
        forr(i,2,n)
        if(S[i]!='?'&&S[i]==S[i-1])
        {
            cout<< -1 << endl;
            return ;
        }
        forr(i,1,n)
        if(S[i]=='?')
        {
            char x;
            forr(j,'a','z')
            if(j!=S[i-1]&&j!=S[i+1]) x=(char) j;
            S[i]=x;
        }
        forr(i,1,n)
        cout<< S[i] ;
        cout<< endl;
    }
}

int main()
{
    
    ios_base::sync_with_stdio(0);
    cin.tie();
    cout.tie();
    int n1; cin>>n1;
    while(n1--)
    dowork();
    return 0;
}
