#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        int a[n+1];
        map<int,int>fre;
        set<int,greater<int> >s;
        for(int i=1;i<=n;i++)
        {
            cin>>a[i];
            s.insert(a[i]);
            fre[a[i]]++;
        }
        vector<int>v;
        int no=0;
        for(auto it:s)
        {
            if(no+fre[it]<=n/2)
            v.push_back(it),no+=fre[it];
            else
            break;
        }
        if(v.size()<3)
        cout<<"0 0 0"<<endl;
        else
        {
            int g=0,s=0,b=0;
            g=fre[v[0]];
            int i=1;
            while(s<=g&&i<v.size())
            {
                s+=fre[v[i++]];
            }
            while(i<v.size())
            b+=fre[v[i++]];
            if(g>=b||g>=s)
            {
                cout<<"0 0 0"<<endl;
                continue;
            }
            cout<<g<<" "<<s<<" "<<b<<endl;
        }
        
    
    }
}