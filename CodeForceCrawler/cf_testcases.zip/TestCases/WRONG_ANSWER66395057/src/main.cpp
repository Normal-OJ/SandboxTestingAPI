#include<bits/stdc++.h>
using namespace std;

#define ll long long

const ll mod=998244353;
int p[200005];
ll dp[200005];
ll sum[200005];

ll quick_pow(ll x,ll a)
{
    ll ans=1;
    while(a)
    {
        if(a&1)
        {
            ans*=x;
            ans%=mod;
        }
        x*=x;
        x%=mod;
        a>>=1;
    }
    return ans;
}

int main()
{
    int n;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&p[i]);
    }
    for(int i=1;i<=n;i++)
    {
        ll x=100,y=quick_pow(p[i],mod-2);
        x*=y;
        x%=mod;
        dp[i]=1+(x-1)*(sum[i-1]+1);
        dp[i]%=mod;
        sum[i]=sum[i-1]+dp[i];
    }
    printf("%lld\n",sum[n]);
    return 0;
}
