#include <bits/stdc++.h>

using namespace std;

#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define mp(a, b) make_pair(a, b)
#define pb push_back
#define f first
#define s second

#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}

typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;

const double inf = 1e9 + 7;

int main() {
  ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);

  int t, n, num, prev, groups, g, s, b, nm;

  cin >> t;


  f0r(i, t) {
    vector<int> ps;
    g = 0; s = 0; b = 0;  
    ps.pb(0);
    groups = 1;
    prev = -1;

    cin >> n;

    f0r (j, n) {
      cin >> num;
      if (prev == -1 || num == prev) {
        ps.back()++;
      } else {
        ps.pb(1);
        groups++;
      }
      prev = num;
    }

    if (n < 6 || groups <= 3) {
      cout << 0 << " " << 0 << " " << 0 << endl;
      continue;
    }

    nm = 0;

    for (int j = groups - 1; j > 1; j--) {
      nm += ps[j];
      if (2 * nm < n) {
        continue;
      }
      g = ps[0];
      for (int k = 1; k < j; k++) {
        s += ps[k];
        if (s > g) {
          break;
        }
      }
      break;
    }

    b = n - nm - g - s;

    if (b > g && s > g) {
      cout << g << " " << s << " " << b << endl;
    } else {
      cout << 0 << " " << 0 << " " << 0 << endl;
    }
  }
        
}