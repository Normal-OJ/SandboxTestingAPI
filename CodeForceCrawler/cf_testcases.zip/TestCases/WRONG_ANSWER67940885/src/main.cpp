#include <bits/stdc++.h>
using namespace std;
#define f first
#define s second
#define pb push_back
typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll, ll> pii;
typedef vector<int> vi;
typedef vector<pii> vpii;
typedef vector<ll> vll;
const int MN = 5e5+5, MOD=1e9+1;
ll lcm (ll a, ll b) {return a*b/__gcd(a,b);}
ll multiplyMod(ll a, ll b) { return (a % MOD * b % MOD) % MOD; }
ll addMod(ll a, ll b) { return (a % MOD + b % MOD) % MOD; }
ll subMod(ll a, ll b) { return (a % MOD - b % MOD) % MOD; }
int t, n;
int arr[MN];
int occur[MN];
int main() {
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cin >> t;
    while (t--) {
        cin >> n;
        memset(arr, -1, sizeof arr);
        memset(occur, -1, sizeof occur);
        for (int i = 0; i<n;i++) {
            cin >> arr[i];
            occur[arr[i]] = i;
        }
        int l = occur[1], r = occur[1];
        string ans = "1";
        for (int m = 2; m<=n;m++) {
            int location = occur[m];
            if (((location <= r && location >= l) || (location == r+1 || location == l-1)) && ans[m-2] == '1') {
                ans = ans + '1';
            }
            else if (m == n) {
                ans = ans + '1';
            }
            else {
                ans = ans+'0';
            }
            l = min(l, location);
            r = max(r, location);
        }
        cout << ans << '\n';


    }
}