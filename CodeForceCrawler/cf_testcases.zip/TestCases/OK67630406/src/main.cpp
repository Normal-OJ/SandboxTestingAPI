#include<bits/stdc++.h>
using namespace std;
#define fastio ios_base::sync_with_stdio(false);cin.tie(NULL);

int main()
{
    fastio;
    int n,t,i,j,a,b;
    string s2="aa";
    string s3="bb";
    string s4="cc";
    cin>>t;
    while(t--)
    {
        string s;
        cin>>s;
        if(s.find(s2)!=std::string::npos || s.find(s3)!=std::string::npos || s.find(s4)!=std::string::npos)
            cout<<-1<<"\n";
        else{
            for(i=0;i<s.size();i++)
            {
                if(s[i]=='?' && s[i-1]!='b' && s[i+1]!='b')
                    s[i]='b';
                else if(s[i]=='?' && s[i-1]!='c' && s[i+1]!='c')
                    s[i]='c';
                else if(s[i]=='?' && s[i-1]!='a' && s[i+1]!='a')
                    s[i]='a';
            }
            cout<<s<<"\n";
        }
    }
    return 0;
}
