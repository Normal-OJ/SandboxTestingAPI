#include <bits/stdc++.h>

using namespace std;

typedef int in;
#define int long long

int n,a[400005];

in main()
{
    int t;
    cin >> t;
    while(t --){
        cin >> n;
        for(int i = 0 ; i < n ; i ++){
            cin >> a[i];
        }
        if(n / 2 < 5){
            cout << "0 0 0\n";
            continue;
        }
        int g = 0,s = 0,b = 0;
        n /= 2;
        for(int i = 1 ; i < n ; i ++){
            if(a[i] < a[i - 1]){
                g = i;
                break;
            }
        }
        bool bl = 0;
        int idx = 0;
        for(int i = n - 1 ; i >= g ; i --){
            if(a[i] > a[i + 1]){
                idx = i;
                bl = 1;
                break;
            }
        }
        if(!bl){
            cout << "0 0 0\n";
            continue;
        }
        for(int i = idx - g - 1 ; i >= g ; i --){
            if(a[i] > a[i + 1]){
                b = (idx + 1) - i - 1;
                break;
            }
        }
        if((idx + 1) - (b + g) <= g || g <= s || g <= b || !g || !b || !s){
            cout << "0 0 0\n";
            continue;
        }
        cout << g << " " << (idx + 1) - (b + g) << " " << b << endl;
    }
    return 0;
}
