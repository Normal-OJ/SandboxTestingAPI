﻿
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 16
VisualStudioVersion = 16.0.29519.87
MinimumVisualStudioVersion = 10.0.40219.1
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "CodeForces", "CodeForces.vcxproj", "{31D5B191-3D35-4CDA-A7BB-1475021BEE2A}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|x64 = Debug|x64
		Debug|x86 = Debug|x86
		Release|x64 = Release|x64
		Release|x86 = Release|x86
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{31D5B191-3D35-4CDA-A7BB-1475021BEE2A}.Debug|x64.ActiveCfg = Debug|x64
		{31D5B191-3D35-4CDA-A7BB-1475021BEE2A}.Debug|x64.Build.0 = Debug|x64
		{31D5B191-3D35-4CDA-A7BB-1475021BEE2A}.Debug|x86.ActiveCfg = Debug|Win32
		{31D5B191-3D35-4CDA-A7BB-1475021BEE2A}.Debug|x86.Build.0 = Debug|Win32
		{31D5B191-3D35-4CDA-A7BB-1475021BEE2A}.Release|x64.ActiveCfg = Release|x64
		{31D5B191-3D35-4CDA-A7BB-1475021BEE2A}.Release|x64.Build.0 = Release|x64
		{31D5B191-3D35-4CDA-A7BB-1475021BEE2A}.Release|x86.ActiveCfg = Release|Win32
		{31D5B191-3D35-4CDA-A7BB-1475021BEE2A}.Release|x86.Build.0 = Release|Win32
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
	GlobalSection(ExtensibilityGlobals) = postSolution
		SolutionGuid = {0BB86AB5-405C-4E28-A9DB-517B259A4285}
	EndGlobalSection
EndGlobal
