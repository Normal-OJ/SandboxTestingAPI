t = int(input())

for rep in range(0, t):
    n = int(input())
    p = input().split()
    p = list(map(int, p))
    poz = [None] * (n + 1)

    for i in range(0, n):
        poz[p[i]] = i
    
    s = {None}
    minim = 1000000
    maxim = -1000000
    for i in range(1, n + 1):
        s.add(poz[i])
        minim = min(minim, poz[i])
        maxim = max(maxim, poz[i])
        if maxim - minim + 1 == i:
            print(1, end = "")
        else:
            print(0, end = "")
    #print("\n")