#include <bits/stdc++.h>
using namespace std;
#define fast ios_base::sync_with_stdio(false);cin.tie(NULL)
#define ll long long
#define pb push_back

int main(){
    fast;
    ll n,k,t;
    cin>>t;
    string s;
    while(t--){
        cin>>n;
        ll a[n+5],g=0,s=0;
        for(ll i=0;i<n;i++)cin>>a[i];
        for(ll i=0;i<n;i++){
            if(a[i]!=a[i+1]){
                g=i+1;
                break;
            }
        }
        for(ll i=g;i<n;i++){
            s++;
            if(s>g&&a[i]>a[i+1])break;
        }
        if(s+g>n/2||g>=s||g>=(n/2)-s-g)cout<<0<<" "<<0<<" "<<0<<endl;
        else cout<<g<<" "<<s<<" "<<(n/2)-s-g<<endl;
    }
    return 0;
}
