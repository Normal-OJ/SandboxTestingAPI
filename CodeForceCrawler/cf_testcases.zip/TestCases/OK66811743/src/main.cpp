#include <bits/stdc++.h>



using namespace std;

typedef long double ld;
typedef long long ll;

const int MAX_N = 4e5+10;
const int INF = 1e9;
const ll MOD = 1e9 + 7;

int a[MAX_N];
int n;
vector<int>v;
int main() {
    ios_base::sync_with_stdio(false);
    int t;
    cin>>t;
    while(t--) {
        cin>>n;
        v.clear();
        for(int i = 1 ; i <= n ; i++) {
            cin>>a[i];
        }
        int cnt = 1;
        for(int i = 2 ; i <= n ; i++) {
            if(a[i] == a[i-1])
                cnt++;
            else  {
                v.push_back(cnt);
                cnt = 1;
            }
        }
        v.push_back(cnt);
        int sum = 0;
        int thresh = v.size();
        for(int i = 0 ; i < v.size() ; i++) {
            sum += v[i];
            if(sum > n/2) {
                thresh = i;
                sum -= v[i];
                break;
            }
        }
        if(thresh < 3) {
            cout<<0<<" "<<0<<" "<<0<<endl;
            continue;
        }
        int sum1 = 0;
        for(int i = 1 ; i < thresh ; i++) {
            sum1 += v[i];
            if(sum1 > v[0])
                break;
        }
        if(sum1 < v[0]) {
            cout<<0<<" "<<0<<" "<<0<<endl;
            continue;
        }
        if(sum - v[0] - sum1 > v[0]) {
            cout<<v[0]<<" "<<sum1<<" "<<sum-v[0]-sum1<<endl;

        }
        else {
            cout<<0<<" "<<0<<" "<<0<<endl;
            continue;
        }



    }

} 