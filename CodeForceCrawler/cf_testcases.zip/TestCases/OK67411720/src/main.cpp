#include<bits/stdc++.h>
#define ll long long
#define lnode node*2,start,mid
#define rnode node*2+1,mid+1,end
#define rep(i,a,b) for(ll i=a;i<=(b);i+=1)
#define input freopen("in.txt", "r", stdin)
#define out freopen("out.txt", "w", stdout)
#define To_string(num,str) {stringstream ss;ss<<num;ss>>str;}
#define To_num(str,num) {stringstream ss;ss<<str;ss>>num;}
const double pi=acos(-1.0);
const int maxn=(4e5+10);
const int inf=0x3f3f3f3f;
const ll mod=1e9+7;
using namespace std;
int a[maxn];
map<int,int> con;
int bh[maxn];
int main()
{   cin.tie(0);
    ios::sync_with_stdio(false);
    int t,n;
    cin>>t;
    while(t--)
    {
        cin>>n;
        ll sum=0,now=0,swt=1;
        con.clear();
        for(int i=1;i<=n;i++)
        {
            cin>>a[i];
            con[a[i]]+=1;
        }
        int num=0;
        for(map<int,int>::iterator it=con.begin();it!=con.end();it++)
        {
            num+=1;
            sum+=it->second;
            bh[num]=it->second;
        }
        if(num<4) swt=0;
        ll next=-1,gold=0,silver=0,bronze=0;
        for(int i=1;i<=num;i++)
        {
            now+=bh[i];
            if(now*2>=sum)
            {
                next=i+1;
                sum-=now;
                break;
            }
        }

        gold=bh[num];
        sum-=bh[num];
        if(num-next+1<3) swt=0;

        for(int i=next;i<num;i++)
        {
            bronze+=bh[i];
            if(bronze>gold)
            {
                silver=sum-bronze;
                if(silver<=gold) swt=0;
                break;
            }
        }

        if(silver==0) swt=0;
        if(swt==0) cout<<"0 0 0"<<endl;
        else cout<<gold<<" "<<silver<<" "<<bronze<<endl;

    }
    return 0;
}