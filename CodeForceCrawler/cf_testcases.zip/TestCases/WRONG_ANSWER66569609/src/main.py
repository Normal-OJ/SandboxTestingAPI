t = int(input())
for _ in range(t):
    s = str(input())
    a = list(s)
    n = len(a)
    flag = 0
    for i in range(n-1):
        if a[i] == a[i+1] and a[i] != "?":
            print(-1)
            flag = 1
            break
    if flag:
        continue
    b=['a','b','c']
    if a[0] == "?" and b[0] != a[1]:
        a[0] = b[0]
    else:
        a[0] = b[1]
    if a[-1] == "?" and b[0] != a[-2]:
        a[-1] = b[0]
    else:
        a[-1] = b[1]
    for i in range(1,n-1):
        if a[i] == "?":
            for j in range(0,3):
                #print(a[i-1],a[i+1])
                #print(b[j],j)
                if a[i-1] != b[j]  and a[i+1] !=b[j] :
                    a[i] = b[j]
                #print(a,b)
                    
    s=""          
    s = "".join(a)
    print(s)
