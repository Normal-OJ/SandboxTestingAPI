#include<bits/stdc++.h>
 
#define lli long long int
#define vi vector<int>
#define vlli vector<lli>
#define plli pair< lli , lli >
#define sz(a) int((a).size())
#define pb push_back
#define all(c) (c).begin(),(c).end()
#define tr(c,i) for(typeof((c)).begin() i = (c).begin(); i != (c).end(); i++)
#define present(c,x) ((c).find(x) != (c).end())
#define cpresent(c,x) (find(all(c),x) != (c).end())
#define f(a,b,c) for(int a=b;a<c;a++)
#define fastio ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0)
using namespace std;

pair< vector<int>, bool > myfunc(unordered_map<int,lli> M,int start)
{
    vector<int> myv;
    myv.pb(start);
    M[start]--;
    lli n = M[0]+M[1]+M[2]+M[3];
    bool myflag = false;
    f(i,0,n-1)
    {
        if(M[myv[i]-1]>0)
        {
            M[myv[i]-1]--;
            myv.pb(myv[i]-1);
        }
        else if(M[myv[i]+1]>0)
        {
            M[myv[i]+1]--;
            myv.pb(myv[i]+1);
        }
        else{
            break;
        }
    }
    if(sz(myv)==n)
    {
        myflag = true;
    }
    return make_pair(myv,myflag);
}
int main()
{
    unordered_map<int,lli> M;
    M[-1]=0;
    M[1]=0;
    M[2]=0;
    M[3]=0;
    M[0]=0;
    M[4]=0;
    cin>>M[0]>>M[1]>>M[2]>>M[3];
    lli n = M[0]+M[1]+M[2]+M[3];
    f(i,0,4)
    {
        pair< vector<int>, bool > mypair = myfunc(M,i);
        if(mypair.second==true)
        {
            cout<<"YES\n";
            f(j,0,sz(mypair.first))
            {
                cout<<mypair.first[j]<<" ";
            }
            return 1;
        }
    }
    cout<<"NO\n";
}