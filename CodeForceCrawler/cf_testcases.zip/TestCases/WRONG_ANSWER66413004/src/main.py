def Beautiful_R_C(inp):
	ans = [0,0,0]
	ls = inp.split(" ")
	i=0
	while(i<(len(ls)//2)-2):
		if(i==0):
			ans[0] = ans[0]+1
			while ls[i]==ls[i+1]:
				ans[0] = ans[0]+1
				i+=1
		if(i==1):
			ans[1] = ans[1]+1
			while ls[i]==ls[i+1]:
				ans[1] = ans[1]+1
				i+=1
		else:
			ans[2]  = ans[2]+1
			i+=1
	if 0 not in ans:
		print(ans)
	else:
		print([0,0,0])
t = int(input())
#t= 5
while t>0:
	n  = input()
	a = input()
	#a = "5 4 4 3 2 2 1 1 1 1 1 1"
	Beautiful_R_C(a)
	t=-1