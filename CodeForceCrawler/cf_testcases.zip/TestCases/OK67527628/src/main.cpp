#include<iostream>
#include<bits/stdc++.h> 
#include<string>
#define UB upper_bound
#define LB lower_bound
#define BS binary_search
#define IN insert
#define PB push_back
#define EB emplace_back
#define MP make_pair
#define NL cout<<endl
#define ll long long int
#define ld long double
#define vl vector<ll>
#define sl set<ll>
#define sc set<char>
#define li list<ll>
#define vp vector<pair<ll, ll> >
#define vs vector<string>
#define ss set<string>
#define REP(i,a,b) for(ll i=a;i<b;i++)
#define REPI(i,a,b) for(ll i=b-1;i>=a;i--)
#define N (ll)pow(2,32)-1
#define mod (ll)1000000007
using namespace std;
ll mypow(ll a,ll b)
{
  ll m=mod;
  ll mul=a,ans=1;
  while(b)
  {
   if(b&1)
   {
    ans*=mul;
    ans%=m;
   }
   mul*=mul;
   mul%=m;
   b/=2;
  }
 return ans%m;
}
ll solve(ll n){
  ll ans=n*(n+1)/2,c=0,x=1,m=n,tmp=0;
  for(ll i=0;i<=63;i++){
    if(x<=n) c++;
    x=x<<1;
  }
  //cout<<"CNT: "<<c<<endl;
  x=1;
  while(m){
    tmp+=(m-m/2)*x;
    x=x<<1;
    m=m>>1;
  }
  ans=ans-c-tmp;
  return (ans);
}
bool comp(string s,string t){
  sort(s.begin(),s.end());
  sort(t.begin(),t.end());
  return s==t;
}
int main()
{
#ifndef ONLINE_JUDGE
freopen("input.txt","r",stdin);
freopen("output.txt","w",stdout);
#endif
ios::sync_with_stdio(0);
cin.tie(0);
ll t=1;
cin>>t;
while(t--){
 string s; cin>>s;
 bool chk=false;
 REP(i,0,s.size()){
  if(i>=1&&s[i]==s[i-1]&&s[i]!='?')
    chk=true;
 }
 if(chk)
  cout<<"-1"<<endl;
 else{
  REP(i,0,s.size()){
    if(s[i]=='?'){
      if(i>=1&&i<s.size()-1){
        if(s[i-1]=='a'){
          if(s[i+1]=='?'||s[i+1]=='c'||s[i+1]=='a') s[i]='b';
          else  s[i]='c';
        }
        else if(s[i-1]=='b'){
          if(s[i+1]=='?'||s[i+1]=='c'||s[i+1]=='b') s[i]='a';
          else  s[i]='c';
        }
        else{
          if(s[i+1]=='?'||s[i+1]=='c'||s[i+1]=='a') s[i]='b';
          else  s[i]='a';
        }
      }
      else if(i==0){
        if(i+1<s.size()&&s[i+1]=='a')
          s[i]='b';
        else if(i+1<s.size()&&s[i+1]=='b')
          s[i]='a';
        else if(i+1<s.size()&&s[i+1]=='c')
          s[i]='a';
        else
          s[i]='a';
      }
      else{
        if(s[i-1]=='a') s[i]='b';
        else if(s[i-1]=='b') s[i]='a';
        else s[i]='a';
      }
    }
  }
  cout<<s<<endl;
 }
}
return 0;
}