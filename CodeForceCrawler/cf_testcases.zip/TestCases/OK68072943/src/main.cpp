#include <bits/stdc++.h>
 
const int MAXN = 1e5 + 5;
 
char str[MAXN];
 
char get(char a, char b) {
	char res = 'a';
	if(res == a) res++;
	if(res == b) res++;
	if(res == a) res++;
	return res;
}
 
void solve() {
	int n;
	scanf("\n%s", str);
	n = strlen(str);
	if(str[0] == '?') str[0] = get(str[1], str[1]); 
	for(int i = 1; i < n; i++) {
		if(str[i] == '?') str[i] = get(str[i - 1], str[i + 1]);
		else if(str[i] == str[i - 1]) return (void)puts("-1");
	}
	puts(str);
}
 
int main() {
	int T;
	scanf("%d", &T);
	while(T--) solve();
	return 0;
} 
 					  	 							  	 	  	  	  	