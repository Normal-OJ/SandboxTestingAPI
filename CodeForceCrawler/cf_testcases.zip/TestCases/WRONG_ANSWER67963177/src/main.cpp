#include <bits/stdc++.h>
#include <unordered_set>
#include <unordered_map>
#define _for(i, a, b) for(int i = a; i < b; ++i)
#define _rep(i, a, b) for(int i = a; i <= b; ++i)
#define closeIO ios::sync_with_stdio(false); cin.tie(0); cout.tie(0)
#define debug cout << "******************" << endl
#define FREE freopen("in.txt", "r", stdin)
#define FREO freopen("out.txt", "w", stdout)
#define ls l, m, rt << 1
#define rs m + 1, r, rt << 1 | 1
using namespace std;
typedef long long LL;
typedef unsigned long long ULL;
typedef pair<int, int> pii;
typedef long double LD;
const int MAXN = 1e6 + 10;
const int MOD = 998244353;
const double eps = 1e-6;
int a[4], b[4];
vector<int> vec;
int main() {
	for (int i = 0; i < 4; ++i) cin >> a[i];
	for (int i = 0; i < 4; ++i) {
		for (int j = 0; j < 4; ++j) b[j] = a[j];
		vec.clear();
		int id = i;
		while (1) {
			if (id > 0 && b[id - 1] > 0) {
				--id;
				--b[id];
				vec.push_back(id);
			}
			else if (id < 4 && b[id + 1] > 0) {
				++id;
				--b[id];
				vec.push_back(id);
			}
			else break;
		}
		if (vec.size() == a[0] + a[1] + a[2] + a[3]) {
			cout << "YES" << endl;
			for (int j = 0; j < vec.size(); ++j)
				cout << vec[j] << " \n"[j == vec.size() - 1];
			return 0;
		}
	}
	cout << "NO" << endl;
	return 0;
}