t = int(input())
def check_if_beautiful(li, val):
    if 1 not in li:
        return False
    li.sort()
    some = 1
    for l in li:
        if some != l:
            return False
        some += 1
    return True

for i in range(t):
    n = int(input())
    num = input().split()
    num2 = []
    for j in num:
        num2.append(int(j))
    num = num2
    output = []
    if 1 in num:
        output.append(1)
    else:
        for j in range(n):
            output.append(0)
        print(output)
        continue
    for j in range(2, n + 1):
        beautiful = False
        l = 0
        r = l + j - 1
        while(r < n + 1):
            beautiful = check_if_beautiful(num[l:r + 1], j)
            l += 1
            r += 1
            if beautiful:
                output.append(1)
                break
        if not beautiful:
            output.append(0)
    print(output)
