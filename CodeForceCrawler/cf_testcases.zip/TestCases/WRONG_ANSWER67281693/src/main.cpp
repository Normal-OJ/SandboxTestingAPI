#include<bits/stdc++.h>
#define ll long long
#define lnode node*2,start,mid
#define rnode node*2+1,mid+1,end
#define rep(i,a,b) for(ll i=a;i<=(b);i+=1)
#define input freopen("in.txt", "r", stdin)
#define out freopen("out.txt", "w", stdout)
#define To_string(num,str) {stringstream ss;ss<<num;ss>>str;}
#define To_num(str,num) {stringstream ss;ss<<str;ss>>num;}
const double pi=acos(-1.0);
const int maxn=(1e5+10);
const int inf=0x3f3f3f3f;
const ll mod=1e9+7;
using namespace std;
int ans[maxn];
int main()
{   cin.tie(0);
    ios::sync_with_stdio(false);
    int a,b,c,d;
    cin>>a>>b>>c>>d;
    int sum0=a,sum1=b,sum2=c,sum3=d;
    ans[0]=-1;
    for(int i=1; ;i+=2)
    {
        if(sum0!=0)
        {
            sum0-=1;
            ans[i]=0;
            continue;
        }
        if(sum2!=0)
        {
            sum2-=1;
            ans[i]=2;
            continue;

        }
        break;
    }
    int swt=1,start;

    if(b>a) start=0;
    else start=2;

    for(int i=start;;i+=2)
    {
        if(sum1!=0)
        {
            sum1-=1;
            ans[i]=1;
            continue;
        }
        if(sum3!=0)
        {
            sum3-=1;
            ans[i]=3;
            continue;
        }
        break;
    }

    if(sum1==1&&ans[1]!=3)
    {
        ans[0]=1;
    }
    else if(sum3==1&&ans[1]==2)
    {
        ans[0]=3;
    }


    int s0=0,s1=0,s2=0,s3=0;
    if(ans[0]==-1)
    {
        for(int i=1;i<=a+b+c+d;i++)
        {
            if(ans[i]==0) s0+=1;
            if(ans[i]==1) s1+=1;
            if(ans[i]==2) s2+=1;
            if(ans[i]==3) s3+=1;
        }
        if(s0==a&&s1==b&&s2==c&&s3==d)
        {   cout<<"YES"<<endl;
            for(int i=1;i<=a+b+c+d;i++)
              cout<<ans[i]<<" ";
        }
        else cout<<"NO";
    }
    else
    {
        for(int i=0;i<a+b+c+d;i++)
        {
            if(ans[i]==0) s0+=1;
            if(ans[i]==1) s1+=1;
            if(ans[i]==2) s2+=1;
            if(ans[i]==3) s3+=1;
        }

        if(s0==a&&s1==b&&s2==c&&s3==d)
        {   cout<<"YES"<<endl;
            for(int i=0;i<a+b+c+d;i++)
              cout<<ans[i]<<" ";
        }
        else cout<<"NO";
    }
    return 0;
}

   	 		 	 	  	 	 		  				 		