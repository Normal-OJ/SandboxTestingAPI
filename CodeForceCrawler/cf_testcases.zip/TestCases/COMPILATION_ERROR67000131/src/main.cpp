#include<iostream>
#include<cstdio>
using namespace std;
long long a[200009];
int wz[200009];

long long sum_(int m) {
	return ((1 + m) * m) / 2;
}

void fun() {
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++) {
		scanf_s("%lld", &a[i]);
		wz[a[i]] = i;
		a[i] = a[i - 1] + a[i];
	}

	int ks, js;
	for (int m = 1; m <= n; m++) {
		if (m == 1) {
			ks = wz[m];
			js = wz[m];
			if (js - ks + 1 == m && a[js] - a[ks - 1] == sum_(m)) {
				printf("1");
			}
			else {
				printf("0");
			}
		}
		else {
			if (ks > wz[m]) {
				ks = wz[m];
			}
			if (js < wz[m]) {
				js = wz[m];
			}
			if (js - ks + 1 == m && a[js] - a[ks - 1] == sum_(m)) {
				printf("1");
			}
			else {
				printf("0");
			}
		}
	}
	printf("\n");
}

int main() {
	int T;
	cin >> T;
	while (T--) {
		fun();
	}
	return 0;
}