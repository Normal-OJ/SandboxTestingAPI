#include<bits/stdc++.h>
using namespace std;
int a,b,c,d,x,y,ff,gg;
int f[2][2][3]={0,0,1,0,1,1,0,1,1,0,0,1};
int g[2][2][3]={1,0,0,1,1,0,1,1,0,1,0,0};
int main(){
scanf("%d%d%d%d",&a,&b,&c,&d);
if(a+b+c+d==1){puts("YES");puts((a==1)?"0 ":((b==1)?"1 ":((c==1)?"2 ":"3 ")));return 0;}
if(!c){if(d)return puts("NO"),0;
else{if(abs(a-b)>1)return puts("NO"),0;
puts("YES");
if(a>b)printf("0 ");
for(int i=1;i<=min(a,b);i++)printf("1 0 ");
if(b>a)printf("1 ");
printf("\n");return 0;}}
if(!b){if(a)return puts("NO"),0;
else{if(abs(c-d)>1)return puts("NO"),0;
puts("YES");
if(d>c)printf("3 ");
for(int i=1;i<=min(c,d);i++)printf("2 3 ");
if(c>d)printf("2 ");
printf("\n");return 0;}}
if(a>b)return puts("NO"),0;
if(c<d)return puts("NO"),0;
x=b-a;y=c-d;
if(abs(x-y)>1)return puts("NO"),0;
puts("YES");
ff=f[(a!=0)][(d!=0)][x-y+1];gg=g[(a!=0)][(d!=0)][x-y+1];
if(ff)printf("1 ");
b-=ff;c-=gg;
for(int i=1;i<=a;i++)printf("0 1 ");
for(int i=1;i<=b-a;i++)printf("2 1 ");
for(int i=1;i<=d;i++)printf("2 3 ");
if(gg)printf("2 ");
printf("\n");
return 0;}
