#include <bits/stdc++.h>
using namespace std;

struct node{
  int data;
  int maxL;
  int indL;
  int reste[4];
  struct node *b[4];
}

struct node* newNode(int data, int reste[4])
{
  struct node* node = new struct node();
  node->data = data;
  node->reste[0] = reste[0];
  node->reste[1] = reste[1];
  node->reste[2] = reste[2];
  node->reste[3] = reste[3];
  node->reste[data] = node->reste[data] - 1;

  int issou[4];
  for (size_t i = 0; i < 4; i++) {
    issou[i] = node->reste[i];
  }
  for (size_t i = 0; i < 4; i++) {
    if (reste[i] == 0)
    {
      node->b[i] = NULL;
    }
    else
    {
      node->b[i] = newNode(i, issou);
    }
  }


  int maxL = 0;
  int indL = -1;
  for (size_t i = 0; i < 4; i++) {
    if (reste[i] != 0 && maxL < node->b[i]->maxL + 1)
    {
        maxL = node->b[i]->maxL + 1;
        indL = i;
    }
  }

  node->maxL = maxL+1;
  node->indL = indL;

  return(node);
}

int main() {
  int reste[4];
  int n = 0;
  for (size_t i = 0; i < 4; i++) {
    cin >> reste[i];
    n = n + reste[i];
  }

  struct node *node[4];
  int indL = -1;
  int maxL = 0;
  for (size_t i = 0; i < 4; i++) {
    node[i] = newNode(i, reste);
    if (maxL < node[i]->maxL)
    {
      indL = i;
      maxL = node[i]->maxL;
    }
  }

  struct node *current = node[maxL];
  if (maxL == n)
  {
    cout << "YES" << endl;
    while (indL != -1)
    {
      cout << indL;
      indL = current->indL;
    }
  }
  else
  {
    cout << "NO" << endl;
  }
  cout << endl;
  return 0;
}
