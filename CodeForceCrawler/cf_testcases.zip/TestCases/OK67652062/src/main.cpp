#include<bits/stdc++.h>
#include<iostream>
#define ll long long
using namespace std;
int main()
{
  int t;
  cin>>t;
  while(t--)
  {
      int n;
      cin>>n;
      int arr[n];
      int v[n+1];
      for(int i=0;i<n;i++)
      {
        cin>>arr[i];
        v[arr[i]]=i;
      }
      int pos_max=v[1];
      int pos_min=v[1];
      if(pos_max-pos_min+1==1)
        cout<<1;
      else
        cout<<0;
      for(int i=2;i<=n;i++)
      {
          pos_max=max(pos_max,v[i]);
          pos_min=min(pos_min,v[i]);
          if(pos_max-pos_min+1==i)
            cout<<1;
          else
            cout<<0;

      }
      cout<<endl;
  }

}
