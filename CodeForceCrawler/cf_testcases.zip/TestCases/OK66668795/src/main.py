def check(n, lst):
    pos_p = [0 for j in range(n)]
    for i in range(n):
        pos_p[lst[i] - 1] = i
    pmin, pmax, s = pos_p[0], pos_p[0], ''
    for i in range(n):
        if pos_p[i] < pmin:
            pmin = pos_p[i]
        if pos_p[i] > pmax:
            pmax = pos_p[i]
        if pmax - pmin != i:
            s += "0"
        else:
            s += "1"
    return s
 
 
for _ in range(int(input())):
    m = int(input())
    p = [int(i) for i in input().split()]
    print(check(m, p))