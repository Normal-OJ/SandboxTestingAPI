#include <cstdio>
#include <iostream>
#include <vector>
#include <map>
#include <cstring>
#define rep(i,a,b) for(int i = (a); i <= (b); ++ i)
#define per(i,a,b) for(int i = (a); i >= (b); -- i)
#define pb push_back
#define VI vector<int>
#define VVI vector<VI>
#define Pii pair<int,int>
#define Pll pair<ll,ll>
#define Pli pair<ll,int>
#define fi first
#define se second

using namespace std;

typedef long long ll;

constexpr int N = 400050;

ll n, p[N], a[N], sum[N];

int main() {
	ios::sync_with_stdio(0); cin.tie(0);
	int T;
	cin >> T;
	while(T --) {
		cin >> n;
		rep(i, 1, n) cin >> p[i], a[i] = 0;
		int cnt = 1; a[cnt] = 1;
		for(int i = 2;i <= n; ++ i) {
			if(p[i] == p[i-1]) ++ a[cnt];
			else ++ cnt, ++ a[cnt];
		}
		rep(i, 1, cnt) {
			sum[i] = sum[i-1] + a[i];
			if(sum[i] > n/2) {
				cnt = i-1;
				break;
			}
		}

		// rep(i, 1, cnt) cout << a[i] << " "; cout << endl;

		int g = 0, b = 0, s = 0;
		auto ck = [&] () {
				return g > 0 && b > 0 && s > 0 &&
				g < s && g < b &&
				g + b + s <= n/2;
		};
		if(cnt >= 3) {
			g = a[1], b = 0, s = 0;
			rep(i, 2, cnt) {
				if(s <= g) s += a[i];
			}
			b = sum[cnt] - g - s;
		}

		if(ck()) cout << g << " " << s << " " << b << '\n';
		else cout << "0 0 0\n";

	}
}
