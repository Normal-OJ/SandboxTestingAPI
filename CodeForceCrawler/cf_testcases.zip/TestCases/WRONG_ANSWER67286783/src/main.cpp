#include <iostream>
#include <cstdio>
#include <vector>
using namespace std;
vector <int> res;
int a[10];

int fSt(){
	for(int i = 0; i < 4; i++){
		if(a[i]){
			if(a[i] % 2){
				if(a[i + 1]){
					res.push_back(i + 1);
					a[i + 1]--;
				}
			}
			return i;
		}
	}
}

void addRes(int v1, int v2, int cot){
	if(cot <= 0) return ;
	while(cot--){
		res.push_back(v1);
		res.push_back(v2);
	}
}

int main(){
	for(int i = 0; i < 4; i++) cin >> a[i];
	int cot = a[0] + a[1] + a[2] + a[3];
	int st = fSt();
	while(st < 4){
		addRes(st, st + 1, a[st]);
		a[st + 1] -= a[st];
		a[st] = 0;
		st++;
		if((st < 3 && a[st] < 0)){
			cout << "NO" << endl;
			return 0;
		}
  		if((st == 3 && (a[st] != 0 && a[st] != -1))){
			cout << "NO" << endl;
			return 0;
		}
		
	}
	printf("YES\n");
	for(int i = 0; i < cot; i++) printf("%d ", res[i]);
	printf("\n");
	return 0;
}
	 	   	 		 		       	 	