numbers = list(map(int, input().split(' ')))


def solve(numbers, x):
	n = sum(numbers)
	a = [None for i in range(n)]
	for i in range(n):
		if not numbers[x]:
			return
		a[i] = x
		numbers[x] -= 1
		# solution is found
		if not sum(numbers):
			break
		if x and numbers[x - 1]:
			x -= 1
		elif x < 3 and numbers[x + 1]:
			x += 1
		else:
			# no solution
			return None

	return a


for i in range(4):
	sol = solve(list(numbers), i)
	if sol:
		print('YES')
		print(' '.join(map(str, sol)))
		exit(0)
print('NO')