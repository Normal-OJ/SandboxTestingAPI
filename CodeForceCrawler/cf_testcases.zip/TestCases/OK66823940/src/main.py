n = int(input())

s = [[] for i in range(n)]

for i in range(n):
    s[i] = input()


for i in range(n):
    t = list(s[i])
    m = len(t)
    for j in range(m):
        if t[j] == '?':
            pool = {'a','b','c'}
            if j > 0:
                pool.discard(t[j-1])
            if j < (m - 1):
                pool.discard(t[j+1])
            t[j] = pool.pop()
    t = ''.join(t)
    if any(t[i] == t[i+1] for i in range(m-1)):
        print(-1)
    else:
        print(t)
