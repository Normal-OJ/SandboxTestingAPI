#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int mod=998244353;
int f[2005][2005];
int g[2005][2005];
char ch[2005];
int n,ans;
int main(){
	scanf("%s",ch+1);n=strlen(ch+1);
	f[0][0]=1;
	for(int i=1;i<=n;i++){
		if(ch[i]==')'){
			for(int j=0;j<=n;j++)
			f[i][j]=f[i-1][j];
		}
		else if(ch[i]=='('){
			for(int j=1;j<=n;j++)
			f[i][j]=f[i-1][j-1];
		}
		else {
			for(int j=0;j<=n;j++)
			f[i][j]=f[i-1][j];
			for(int j=1;j<=n;j++)
			f[i][j]=(f[i][j]+f[i-1][j-1])%mod;
		}
	}
	
	g[n+1][0]=1;
	for(int i=n;i>=1;i--){
		if(ch[i]=='('){
			for(int j=0;j<=n;j++)
			g[i][j]=g[i+1][j];
		}
		else if(ch[i]==')'){
			for(int j=1;j<=n;j++)
			g[i][j]=g[i+1][j-1];
		}
		else {
			for(int j=0;j<=n;j++)
			g[i][j]=g[i+1][j];
			for(int j=1;j<=n;j++)
			g[i][j]=(g[i][j]+g[i+1][j-1])%mod;
		}
	}
	
	for(int i=1;i<=n-1;i++)
	for(int j=1;j<=n;j++)
	ans=(ans+1ll*f[i][j]*g[i+1][j]%mod*j%mod)%mod;
		
	printf("%d",ans);
	return 0;
}