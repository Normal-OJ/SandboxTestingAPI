#include<bits/stdc++.h>
#define si(a) scanf("%d",&a)
#define sl(a) scanf("%lld",&a)
#define sd(a) scanf("%lf",&a)
#define ss(a) scanf("%s",a)
#define ms(a) memset(a,0,sizeof(a))
#define repi(i,a,b) for(register int i=a;i<=b;i++)
#define repd(i,a,b) for(register int i=a;i>=b;i--)
#define reps(s) for(int i=head[s];i;i=e[i].nxt)
#define pb push_back 
#define fi first
#define se second
#define pr(x) cout<<#x<<": "<<x<<endl
#define eps 1e-8
using namespace std;
vector<int> ans;
int a[4],b[4];
int main()
{
	si(a[0]),si(a[1]),si(a[2]),si(a[3]);
	repi(st,0,3){
		repi(i,0,3)	b[i]=a[i];
		int x=st;
		if(!q[x])	continue;
		while(true){
			ans.pb(x),b[x]--;
			if(x&&b[x-1])	x--;
			else if(x!=3&&b[x+1])	x++;
			else break;
		}
		if(!b[0]&&!b[1]&&!b[2]&&!b[3]){
			puts("YES");
			for(auto x:ans)	printf("%d ",x);
			return 0;
		}
	}
	puts("NO");
	return 0;
}