
def solve():
    a,b,c,d = list(map(int,input().split(' ')))
    rp = []
    if c >= d - 1 and d > 0:
        rp = [2 if i%2 else 3 for i in range(2*d - 1)]
        c -= d - 1;
        d = 0
    
    lp = []
    if b >= a - 1 and a > 0:
        lp = [1 if i%2 else 0 for i in range(2*a - 1)]
        b -= a - 1;
        a = 0
    
    if len(lp) and len(rp):
        if abs(b - c) > 1 or min(b,c) == 0:
            print("NO")
        else:
            mp = [1 if i%2 else 2 for i in range(2*min(c,b))]
            if c>b:
                rp = [2] + rp
            elif b>c:
                lp.append(1)
            print("YES")
            arr = [*rp,*mp,*lp];
            print(*rp,*mp,*lp)
    elif len(lp):
        if b > 2:
            print("NO")
        else:
            lp = [*([1] if b else []),*lp,*([1] if b > 1 else [])]
            print("YES")
            print(*lp)
    elif len(rp):
        if c > 2:
            print("NO")
        else:
            rp = [*([2] if c else []),*rp,*([2] if c > 1 else [])]
            print("YES")
            print(*rp)
    else:
        if abs(b - c) > 1:
            print('NO')
        else:
            mp = [1 if i%2 else 2 for i in range(2*min(c,b))]
            if c>b:
                mp.append(2);
            elif b>c:
                mp = [1,*mp];
            print("YES")
            print(*mp)
        
            
# n = int(input())
# for i in range(n):
solve()
