#include<bits/stdc++.h>
#define ll long long
#define lnode node*2,start,mid
#define rnode node*2+1,mid+1,end
#define rep(i,a,b) for(ll i=a;i<=(b);i+=1)
#define input freopen("in.txt", "r", stdin)
#define out freopen("out.txt", "w", stdout)
#define To_string(num,str) {stringstream ss;ss<<num;ss>>str;}
#define To_num(str,num) {stringstream ss;ss<<str;ss>>num;}
const double pi=acos(-1.0);
const int maxn=(1e5+10);
const int inf=0x3f3f3f3f;
const ll mod=1e9+7;
using namespace std;
int ans[maxn];
int main()
{   cin.tie(0);
    ios::sync_with_stdio(false);
    int a,b,c,d;
    cin>>a>>b>>c>>d;
    int sum0=a,sum1=b,sum2=c,sum3=d;
    if(a-b==1&&c==0&&d==0)
    {   cout<<"YES"<<endl;
        for(int i=1;i<=b;i++)
          cout<<"0 1 ";
        cout<<"0";
        return 0;
    }
    if(a==1&&b==1&&c==1&&d==1)
    {   cout<<"YES"<<endl;
        cout<<"0 1 2 3";
        return 0;
    }
    if(a==1&&b==0&&c==0&&d==0)
    {
        cout<<"YES"<<endl;
        cout<<"0";
        return 0;
    }

    if(b==1&&a==0&&c==0&&d==0)
    {
        cout<<"YES"<<endl;
        cout<<"1";
        return 0;
    }

    if(c==1&&a==0&&b==0&&d==0)
    {
        cout<<"YES"<<endl;
        cout<<"2";
        return 0;
    }

    if(d==1&&a==0&&b==0&&c==0)
    {
        cout<<"YES"<<endl;
        cout<<"3";
        return 0;
    }



    if(a==0&&b==0&&d-c==1)
    {   cout<<"YES"<<endl;
        for(int i=1;i<=c;i++)
          cout<<"3 2 ";
        cout<<"3";
        return 0;
    }
    if(a>b)
    {
        cout<<"NO";
        return 0;
    }
    if(d>c)
    {
        cout<<"NO";
        return 0;
    }

    if(b>=c-1-d+a&&b<=c-1-d+a+2) ;
    else
    {
        cout<<"NO";
        return 0;
    }
    for(int i=1;;i+=2)
    {
        if(sum0!=0)
        {
            sum0-=1;
            ans[i]=0;
            continue;
        }
        if(sum2!=0)
        {
            sum2-=1;
            ans[i]=2;
            continue;
        }
        break;
    }
    if(b>=c-1-d+a&&b<=c-1-d+a+2)
    {
        if(b==c-1-d+a||b==c-1-d+a+1)
        {
            for(int i=2;;i+=2)
            {
                if(sum1!=0)
                {   sum1-=1;
                    ans[i]=1;
                    continue;
                }
                if(sum3!=0)
                {
                    sum3-=1;
                    ans[i]=3;
                    continue;
                }
                break;
            }
            cout<<"YES"<<endl;
            for(int i=1;i<=a+b+c+d;i++)
              cout<<ans[i]<<" ";
            return 0;
        }
        else
        {
            for(int i=0;;i+=2)
            {
                if(sum1!=0)
                {
                    sum1-=1;
                    ans[i]=1;
                    continue;
                }
                if(sum3!=0)
                {
                    sum3-=1;
                    ans[i]=3;
                    continue;
                }
                break;
            }

            cout<<"YES"<<endl;
            for(int i=0;i<a+b+c+d;i++)
              cout<<ans[i]<<" ";
            return 0;
        }



    }
    else cout<<"NO";
    return 0;
}
