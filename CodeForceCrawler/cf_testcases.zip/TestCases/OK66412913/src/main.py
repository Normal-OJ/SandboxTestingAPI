def perms(val):
    lst = [int(i) for i in val.split()]
    maxi = 0
    mini = len(lst)

    visited = [0] * len(lst)
    position = [0] * len(lst)

    ordered = sorted(lst)
    beas = [0] * len(lst)

    indexer = 0
    for i in lst:        
        position[i - 1] = indexer
        indexer += 1

    for i in ordered:
        ind = position[i - 1]
        visited[ind] = 1
        if ind < mini:
            mini = ind
        if ind > maxi:
            maxi = ind
        if maxi - mini + 1 == i:
            beas[i - 1] = 1

    strs = ""            
    for i in beas:
        strs += str(i)

    print(strs)

def main():
    total = eval(input())
    for i in range(total):
        n = input()
        val = input()
        perms(val)
        

main()
        
    
