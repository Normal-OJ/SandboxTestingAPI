#include <bits/stdc++.h>
using namespace std;
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	
	int cnt;
	cin >> cnt;
	
	while (cnt--){
		int ncnt, pos, bef,now;
		int g=0, s=0, b=0;
		bool ans = true, det=false;
		
		cin >> ncnt;
		
		cin >> bef;
		for (int i=2; i<=ncnt; i++){
			cin >> now;
			if (det) continue;
			
			if (bef != now){
				if (g == 0){
					g = i-1;
				}else{
					if (s == 0 && i-1-g > g) s = i-1-g;
					else if (b == 0 && i-1-s-g > g) b = i-1-s-g;
				}
				bef = now;
			}
			if (b > 0){
				ans = true;
				det = true;
			}else if (i > ncnt/2){
				ans = false;
				det = true;
			}
		}
		
		if (ans) cout << g << " " << s << " " << b << endl;
		else cout << "0 0 0" << endl;
	}
	return 0;
}
