// #pragma GCC optimize(3)
// #pragma GCC optimize("unroll-loops")
#include<bits/stdc++.h>
#define ALL(x) (x).begin(),(x).end()
#define mem(x,y) memset((x),(y),sizeof(x))
#define Discertize(x) sort(ALL(x)),x.erase(unique(x.begin(),x.end()),x.end());
#define SZ(x) ((int)(x).size())
#define P2(x) ((x)*(x))
#define continue(x) { x; continue; }
#define break(x) { x; break; }
#define P pair<int,int> 
using namespace std;
typedef long long ll;
const int maxn = 4e5 + 10;
const int maxm = 1e6 + 10;
const int mod = 1e9 + 7;
const ll linf = 0x3f3f3f3f3f3f3f3f;
const int inf = 0x3f3f3f3f;
const double eps = 1e-6;
//lowbit---------------------------------------------------------------------
int LobN;//定义长度
inline int lowbit(int x){ return (x&(-x)); }
void add(ll*c, int x, ll v){ while (x <= LobN)c[x] += v, x += lowbit(x); }
ll que(ll*c, int x){ ll res = 0; while (x)res += c[x], x -= lowbit(x); return res; }
//----------------------------------------------------------------------------
template<typename S, typename T> inline bool Min(S &a, const T &b){ return a > b ? a = b, true : false; }

template<typename S, typename T> inline bool Max(S &a, const T &b){ return a < b ? a = b, true : false; }
template<typename S, typename T> inline void Adm(S &a, const T &b){ a = (a + b) % mod; if (a < 0) a += mod; }
template<typename S, typename T> inline void Mum(S &a, const T &b){ a = 1LL * a * b % mod; }
template<typename T> inline T Gcd(T a, T b){ while (b){ T t = b; b = a % b; a = t; }return a; }
template<typename T> inline int BitCnt(T x){ int cnt = 0; while (x)++cnt, x &= x - 1; return cnt; }
template<typename T> inline bool IsPri(T x) { if (x < 2) return false; for (T i = 2; i * i <= x; ++i) if (x % i == 0) return false; return true; }
inline ll qpow(ll a, ll n){ ll t = 1; while (n){ if (n & 1)t = t * a % mod; a = a * a % mod, n >>= 1; }return t%mod; }
int ans[maxn];
int a, b, c, d;

struct de{

	bool check(){
		int flag = 0;
		for (int i = 1; i <= a + c; i++){
			if (i <= a)ans[i * 2 - 1] = 1;
			else ans[i * 2 - 1] = 3;
		}
		for (int i = 1; i <= b + d; i++){
			if (i <= b)ans[i * 2] = 2;
			else ans[i * 2] = 4;
		}
		for (int i = 2; i <= a + b + c + d; ++i)if (abs(ans[i] - ans[i - 1]) != 1){ flag = 1; break; }
		if (!flag){
			printf("YES\n");
			for (int i = 1; i <= a + b + c + d;i++)
				printf("%d ", ans[i] - 1);
			printf("\n");
			return 1;
		}
		return 0;
	}
};

int main(){

	scanf("%d%d%d%d", &a, &b, &c, &d);
	de pp;
	if (pp.check())return 01;
	int flag = 0;
	for (int i = 1; i <= b + d; i++){
		if (i <= b)ans[i * 2 - 1] = 2;
		else ans[i * 2 - 1] = 4;
	}
	for (int i = 1; i <= a + c; i++){
		if (i <= a)ans[i * 2] = 1;
		else ans[i * 2] = 3;
	}
	for (int i = 2; i <= a + b + c + d; ++i)if (abs(ans[i] - ans[i - 1]) != 1){ flag = 1; break; }
	if (!flag){
		printf("YES\n");
		for (int i = 1; i <= a + b + c + d; i++)printf("%d ", ans[i] - 1);
		printf("\n");
		return 0;
	}
	printf("NO\n");


	return 0;
}
