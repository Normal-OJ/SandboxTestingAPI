#include<bits/stdc++.h>
using namespace std;
typedef long long ll ;
string s;
const ll mod= 998244353;
const int N=2010;
ll ny[N],jc[N];
int l[N],r[N],w[N];
ll  C(int n,int m)
{
	if(n<m) return 0ll;
	return ((jc[n]*ny[n-m])%mod*(ny[m]))%mod;
}
int main()
{
	cin>>s;
	int n=s.length();jc[0]=jc[1]=ny[1]=ny[0]=1;
	for(int i=2;i<=n;i++)
	{
		jc[i]=(i*jc[i-1])%mod;
		ny[i]=ny[mod%i]*1ll*(mod-mod/i)%mod;
	}
	for(int i=2;i<=n;i++)
	{
		ny[i]=(ny[i]*ny[i-1])%mod;
	} l[0]=w[0]=r[0]=0;
	for(int i=0;i<n;i++)
	{
		if(i) 
		{
			l[i]=l[i-1];
			r[i]=r[i-1];
			w[i]=w[i-1];
		}
		if(s[i]=='?') w[i]++;
		else if(s[i]=='(') l[i]++;
		else r[i]++;
	} ll ans=0;
	for(int i=0;i<n;i++)
	{
		int  nowl=l[i],nowr=r[n-1]-r[i];
		int  wl=w[i],wr=w[n-1]-w[i];
		for(int j=max(nowl,nowr);j<=n/2;j++)
		{
			(ans+=(1ll*j*C(wr,j-nowr)%mod*C(wl,j-nowl)%mod))%=mod;
		}
	}
	cout<<ans<<endl;
} 
