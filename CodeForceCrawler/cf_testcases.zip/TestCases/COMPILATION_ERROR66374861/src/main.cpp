#include<iostream>
using namespace std;
const int maxn = 1e5 + 5;
char str[maxn];
int main()
{
	int t; cin >> t;
	while (t--) {
		cin >> str;
		int len = strlen(str);
		if (len == 1) {
			if (str[0] != '?')
				cout << str[0] << endl;
			else
				cout << "a" << endl;
			continue;
		}
		int is_ok = 0;
		for (int i = 0; i < len; i++) {
			if (str[i] == str[i + 1] && str[i] != '?') {
				cout << "-1" << endl;
				is_ok = 1;
				break;
			}
		}
		if (is_ok)
			continue;
		for (int i = 1; i < len - 1; i++) {
			if (str[i] == '?') {
				if (str[i - 1] != 'a' && str[i + 1] != 'a')
					str[i] = 'a';
				else if (str[i - 1] != 'b' && str[i + 1] != 'b')
					str[i] = 'b';
				else if (str[i - 1] != 'c' && str[i + 1] != 'c')
					str[i] = 'c';
			}
		}
		if (str[len - 1] == '?') {
			if (str[len - 2] != 'a')
				str[len - 2] = 'a';
			else if (str[len - 2] != 'b')
				str[len - 2] = 'b';
			else if (str[len - 2] != 'c')
				str[len - 2] = 'c';
		}
		cout << str << endl;
	}
	return 0;
}