#include <bits/stdc++.h>
 
using namespace std;
 
 
int main()
{
    int i,j,k,n,t;
    cin>>t;
    for(i=0;i<t;i++)
    {
        cin>>n;
        int  a[n],pos[n+1];
        for(j=0;j<n;j++)
        {
            cin>>a[j];
            pos[a[j]]=j;
        }
        int posmax=pos[1],posmin=pos[1];
        //b[pos[1]]=1;
       /* for(j=2;j<=n;j++)
        {
            cout<<pos[j];
        }
        cout<<" ";*/
        cout<<1;
        for(j=2;j<=n;j++)
        {
            posmax=max(posmax,pos[j]);
            posmin=min(posmin,pos[j]);
            if(posmax-posmin+1==j)
            {
               cout<<1;
            }
            else
            {
                cout<<0;
            }
        }
        /*for(j=0;j<n;j++)
        {
            cout<<b[j];
        }*/
        cout<<endl;
    }
    return 0;
}