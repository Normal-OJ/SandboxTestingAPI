#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define ld long double
#define llu unsigned long long int
#define scll(x) scanf("%lld",&x)
#define scld(x) scanf("%lf",&x)
#define scull(x) scanf("%llu",&x)
#define scch(x) scanf(" %c",&ch)
#define Pi acos(-1.0)
#define MEM(a,b) memset(a,b,sizeof(a))
ll __xor(ll a,ll b){return a^b;}
ll __and(ll a,ll b){return a&b;}
ll __or(ll a,ll b){return a|b;}
#define fast ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
ll ai[10000],pi[1000];
int main()
{
    ll b,c,x,y,z,t,i,j,k,l1,l2,m=0,n,c1=0,c2=0,q;
             ll a[4];
             scll(a[0]);
             scll(a[1]);
             scll(a[2]);
             scll(a[3]);
             while(a[0]!=0&&a[1]!=0)
             {
                 ai[m++]=0;
                 ai[m++]=1;
                 a[0]--;
                 a[1]--;
             }
             if(a[1]>0){
           while(a[2]!=0&&a[1]!=0)
           {
               ai[m++]=2;
               ai[m++]=1;
               a[1]--;
               a[2]--;
           }
             }
                while(a[2]!=0&&a[3]!=0)
                 {
               ai[m++]=2;
               ai[m++]=3;
               a[2]--;
               a[3]--;
                 }
                 if(a[2]>0){
                    ai[m++]=2;
                  a[2]--;
                 }
           if(a[0]==0&&a[1]==0&&a[2]==0&&a[3]==0)
           {cout<<"YES\n";
           for(j=0;j<m;j++)
            cout<<ai[j]<<" ";
           }
           else
            cout<<"NO";
return 0;
}
