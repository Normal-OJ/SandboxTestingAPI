#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdio>
#include <cctype>
#include <vector>
#include <queue>
using namespace std;
typedef long long ll;
const int N = 3e5 + 10;
typedef pair<int, int> P;
char s[N];
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int t; cin >> t; getchar();
	while (t--) {
		int k = 0; s[k++] = 's';
		while (s[k] = getchar(), s[k] != '\n') k++;
		s[k++] = 's';
		bool flag = true;
		for (int i = 1; i < k; i++) {
			if (s[i] == '?') {
				s[i] = 'a';
				while (s[i] == s[i - 1] || s[i] == s[i + 1]) s[i]++;
			}
			if (s[i - 1] == s[i] || s[i] == s[i + 1]) flag = false;
		}
		if (flag) {
			for (int i = 1; i < k - 1; i++) putchar(s[i]); putchar('\n');
		}
		else cout << "-1" << "\n";
	}
	return 0;
}
