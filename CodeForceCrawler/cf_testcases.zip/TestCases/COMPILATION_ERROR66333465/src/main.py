import java.util.Scanner;
public class R711 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        for(int i = 0 ; i < n ; i++){
            String str = input.next();
            System.out.println(R711.setAnswer(str.toCharArray()));
        }
    }
    
    public static String setAnswer(char [] array){
        for(int i = 0 ; i < array.length - 1 ; i++){
            if(array[i] == array[i+1] && array[i] != '?')
                return "-1";
        }
        char [] chars = {'a','b','c'};
        for(int i = 0 ; i < array.length ; i++){
            if(array[i] == '?'){
                for(int j = 0 ; j < chars.length ; j++){
                    if(array[i-1] != chars[j] && array[i+1] != chars[j]){
                        array[i] = chars[j];
                        break;
                    }
                }
            }
        }
        return String.valueOf(array);
    }
}
