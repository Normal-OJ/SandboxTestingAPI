#include<bits/stdc++.h>
using namespace std;
#define ll  long long int
#define mp make_pair
#define fi first
#define se second
#define pii pair<ll,ll>
#define pb push_back
#define io ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL)
#define m 998244353
ll expo(ll a,ll b)
{
	if(b==0)
	return 1;
	if(b%2==0)
	return expo((a%m*a%m)%m,b/2);
	return (expo(a,b-1)%m*a%m)%m;
}
int main()
{
	//io;
	string s;
	cin>>s;
	ll n=s.length();
	ll fact[n+1];
	ll inv_fact[n+1];
	fact[0]=1;
	inv_fact[0]=1;
	for(ll i=1;i<=n;i++)
	{
		fact[i]=(fact[i-1]%m*(i)%m)%m;
		inv_fact[i]=expo(fact[i]%m,m-2)%m;
	}
	ll pre[n];
	ll pre1[n];
	pre[0]=(s[0]=='?');
	pre1[0]=(s[0]=='(');
	for(ll i=1;i<n;i++)
	{
	pre[i]=pre[i-1]+(s[i]=='?');
	pre1[i]=pre1[i-1]+(s[i]=='(');		
	}
	ll post[n+1];
	ll post1[n+1];
	post[n]=0;
	post1[n]=0;
	post1[n-1]=(s[n-1]==')');
	post[n-1]=(s[n-1]=='?');
	for(ll i=n-2;i>=0;i--)
	{
		post[i]=post[i+1]+(s[i]=='?');
		post1[i]=post1[i+1]+(s[i]==')');
	}
	//cout<<"sd";
	ll ans=0;
	for(ll i=0;i<n;i++)
	{
		for(ll c=1;c<=n/2;c++)
		{
			if(max(pre1[i],post1[i+1])>c)
			continue;
			if(pre[i]+pre1[i]<c)
			continue;
			if(post[i+1]+post1[i+1]<c)
			continue;
			//cout<<c<<i<<"->";
			ll tmp=(fact[pre[i]]%m*inv_fact[c-pre1[i]]%m*inv_fact[pre[i]-c+pre1[i]])%m;
			//cout<<tmp<<" ";
			tmp=(tmp%m*fact[post[i+1]]%m*inv_fact[c-post1[i+1]]%m*inv_fact[post[i+1]-c+post1[i+1]]%m)%m;
			//cout<<tmp<<" ";
			tmp=(tmp%m*c%m)%m;
			//cout<<tmp<<" ";
			//cout<<"<-";
			ans=(ans%m+tmp%m)%m;
		}
	}
	cout<<ans;
}