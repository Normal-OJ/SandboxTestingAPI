from sys import stdin
def rl():
    return [int(w) for w in stdin.readline().split()]
 
a,b,c,d = rl()
 
class Fail(Exception): pass
 
def go(x):
    s = [a,b,c,d]
    r = []
    while sum(s) > 0:
        r.append(x)
        s[x] -= 1
        if s[x] < 0:
            return
        if x == 0:
            x = 1
        elif x == 1:
            if s[0] < s[1] or s[0] == 0:
                x = 2
            else:
                x = 0
        elif x == 2:
            if s[3] < s[2] or s[3] == 0:
                x = 1
            else:
                x = 3
        elif x == 3:
            x = 2
    return r
 
for start in range(4):
    r = go(start)
    if r:
        print("YES")
        print(*r)
        break
else:
    print("NO")