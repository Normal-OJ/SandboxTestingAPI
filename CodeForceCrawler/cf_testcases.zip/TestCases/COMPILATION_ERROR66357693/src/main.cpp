#include <bits/stdc++.h>

#define LL long long

using namespace std;

LL Sum(int award[])
{
    return award[0]+award[1]+award[2];
}

bool Check(LL award[],int n)
{
    if(Sum(award)<=n/2 and award[0]>0 and award[1]>0  and award[2]>0 and award[0]<award[1] and award[0]<award[2])
        return true;
    return false;
}


int main()
{

    LL t,n,a,b,c;
    cin>>t;

    while(cin>>n)
    {
        LL arr[n];
        int award[3];
        memset(award,0,sizeof(award));

        for(int i=0; i<n; i++)
        {
            cin>>arr[i];
        }

        if(n<10)
        {
            cout<<"0 0 0"<<endl;
            continue;
        }

        LL idx=0;
        LL lastpos=-1;
        LL lastval=-1;

        for(int i=0; i<n-1; i++)
        {
            if(Sum(award)+1> n/2)
            {
                award[idx]=lastval;
                break;
            }
            if(arr[i]>arr[i+1])
            {

                if((idx==1 and award[0]<=award[1]) or idx==0)
                    award[idx++]++;
                else
                    award[idx]++;

                lastval= award[idx];

            }
            else
            {
                award[idx]++;
            }

            if(Sum(award)>= n/2)
            {
                award[idx]=lastval;
                break;
            }

        }

        if(Check(award,n))
        {
            cout<<award[0]<<" "<<award[1]<<" "<<award[2]<<endl;
        }
        else
            cout<<"0 0 0"<<endl;

    }

    return 0;
}
