a,b,c,d=[int(x) for x in input().split(' ')]
if abs(a+c-b-d) > 1:
    print('NO')
else:
    if d > c:
        if d-c > 1:
            print('NO')
        else:
            if a!=0 or b!=0:
                print('NO')
            else:
                print('YES')
                for i in range(c):
                    print(3,2,sep=' ',end=' ')
                print(3)
    else:    
        if a > b:
            if a-b > 1:
                print('NO')
            else:
                if c!=0 or d!=0:
                    print('NO')
                else:
                    print('YES')
                    for i in range(b):
                        print(0,1,sep=' ',end=' ')
                    print(0)
        else:
            print('YES')
            if a+c>=b+d:
                for i in range(a):
                    print(0,1,sep=' ',end=' ')
                for i in range(b-a):
                    print(2,1,sep=' ',end=' ')
                for i in range(d):
                    print(2,3,sep=' ',end=' ')
                for i in range(a+c-b-d):
                    print(2)
            else:
                print(1,end=' ')
                for i in range(a):
                    print(0,1,sep=' ',end=' ')
                for i in range(b-a-1):
                    print(2,1,sep=' ',end=' ')
                for i in range(d):
                    print(2,3,sep=' ',end=' ')
                
