#include <bits/stdc++.h>
#define NMAX 10
using namespace std;
vector<int> v;
int i;
void dfs(int k , int a , int b, int c, int d);
int a[NMAX];
int main()
{cin>>a[0]>>a[1]>>a[2]>>a[3];
 for(i=1;i<=4;i++)
    {dfs(i,a[0],a[1],a[2],a[3]);
    v.clear();
     }
  cout<<"NO";
    return 0;
}
void dfs(int k , int a , int b, int c, int d)
{v.push_back(k);
 if(k==1)a--;
 if(k==2)b--;
 if(k==3)c--;
 if(k==4)d--;
 if(a==-1 || b==-1 || c==-1 || d==-1)
      return;
 if(!a && !b && !c  && !d)
      {cout<<"YES"<<'\n';
       for(int i=0;i<v.size();i++)
              cout<<v[i]-1<<" ";
       exit(0);
      }
 if(k==1)
    dfs(2,a,b,c,d);
 else
 if(k==2)
 {if(a)
   dfs(1,a,b,c,d);
   else
    dfs(3,a,b,c,d);
 }
 else
  if(k==3)
    {
     if(b)
        dfs(2,a,b,c,d);
       else
        dfs(4,a,b,c,d);
    }
  else
     dfs(3,a,b,c,d);
}

		 	     	 		 	  	 	  	 		  	