#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
struct data{
	int data_;
	int index_;
}a[200055];
bool b[200055];
bool comp(data &a,data &b){
	return a.data_<b.data_;
}
int main(){
	int i,j,k,n,t;
	cin>>t;
	while(t--){
		memset(b,0,sizeof(b));
		int l,r;
		cin>>n;
		for(i=0;i<n;++i){
			cin>>a[i].data_;
			a[i].index_=i;
			if(a[i].data_==1){
				l=r=i;
				b[1]=1;
			}
		}
		sort(a,a+n,comp);
		int now;
		for(i=1;i<n;++i){
			if(l>a[i].index_){
				l=a[i].index_;
				now=l;
			}
			if(r<a[i].index_){
				r=a[i].index_;
				now=r;
			}
			int number=r-l+1;
			if(a[i].data_==number)
				b[a[i].data_]=1;
		}
		for(i=1;i<=n;++i)
			b[i]==1?printf("1"):printf("0");
		printf("\n");
	}
	return 0;
}
 			 	 				 	 		 	 	 	 	  	  	