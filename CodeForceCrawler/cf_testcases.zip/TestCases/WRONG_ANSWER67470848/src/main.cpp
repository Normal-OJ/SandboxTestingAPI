#include<bits/stdc++.h>
#define ff first
#define ss second
#define pb push_back
#define INF (int)1e9+7
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
int main(void){
    ios_base::sync_with_stdio(false); cin.tie(NULL);
    int a,b,c,d; cin>>a>>b>>c>>d;
    deque<int> ans;
    int unu=0;
    if(a>0){
        ans.push_back(0);
        a--;
    }
    if(b>0){
        while(a && b){
            ans.push_back(1);
            ans.push_back(0);
            a--; b--;
        }
        if(a>0){
            cout<<"NO";
            return 0;
        }
    }
    if(c>0){
        while(b && c){
            ans.push_back(1);
            ans.push_back(2);
            b--; c--;
        }
        if(b>0){
            ans.push_front(1);
            b--;
        }
        if(b>0){
            cout<<"NO";
            return 0;
        }        
    }
    if(d>0){
        while(c && d){
            ans.push_back(3);
            ans.push_back(2);
            d--; c--;
        }
        if(c>0 && ans[0]==1){
            ans.push_front(2);
            c--;
        }
        if(d>0){
            ans.push_back(3);
            d--;
        }
        if(d>0 && ans[0]==2){
            ans.push_front(3);
            d--;
        }
        if(c>0 || d>0){
            cout<<"NO";
            return 0;
        }        
    }    
    cout<<"YES"<<'\n';
    for(int x:ans) cout<<x<<" ";
    return 0;
}