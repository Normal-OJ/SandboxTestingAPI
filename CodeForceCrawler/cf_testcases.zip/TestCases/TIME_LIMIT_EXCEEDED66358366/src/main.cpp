#include <bits/stdc++.h>
using namespace std;
#define inf 0x3f3f3f3f;
typedef long long ll;
const int maxn = 1e5+5;
inline int read()
{
	char ch = getchar();
	int p = 1,data = 0;
	while(ch < '0' || ch > '9')
	{
		if(ch == '-')
			p = -1;
		ch = getchar();
	}
	while(ch>='0' && ch <= '9')
	{
		data = (data<<3)+(data<<1)+ch-'0';
		ch = getchar();
	}
	return p*data;
}
int a[4];
int ans[maxn];
bool flag;
void dfs(int pre,int k)
{
	if(flag)
	return;
	if(a[0] == a[1] && a[1] == a[2] && a[2] == a[3] && a[0] == 0 && (!flag))
	{
		printf("YES\n");
		flag = 1;
		for(int i = 0; i < k; i++)
		{
			if(i != k-1)
				printf("%d ",ans[i]);
			else
				printf("%d",ans[i]);
		}
		return;
	}
	for(int i = 0; i < 4; i++)
	{
		if(a[i] && fabs(i-pre) == 1)
		{
			a[i]--;
			ans[k] = i;
			dfs(i,k+1);
			a[i]++;
		}
	}
}
int main()
{
	a[0] = read(),a[1] = read(), a[2] = read(), a[3] = read();
	int cnt = a[0]+a[1]+a[2]+a[3];
	for(int i = 0; i < 4; i++)
	{
		if(flag)
			break;
		if(a[i])
		{
			a[i]--;
			ans[0] = i;
			dfs(i,1);
			a[i]++;
		}
	}
	if(!flag)
		printf("NO");
	return 0;
}