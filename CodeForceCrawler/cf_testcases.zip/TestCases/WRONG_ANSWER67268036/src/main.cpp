#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<cmath>
using namespace std;
#define ll long long
const int maxn=400005;
inline ll read(){
    ll x=0,p=1;char wa=getchar();
    while(!isdigit(wa)){if(wa=='-')p=-1;wa=getchar();}
    while(isdigit(wa)){x=x*10+wa-'0';wa=getchar();}
    return x*p;
}
int a[4],st,ans[maxn],ss;
int main(){
    for(int i=0;i<4;++i)a[i]=read();
    for(st=0;st<4;++st)
        if(a[st]){ans[++ss]=st;--a[st];break;}
    while(1){
        if(st>0&&a[st-1])--a[st-1],--st,ans[++ss]=st;
        else if(st<3&&a[st+1])--a[st+1],++st,ans[++ss]=st;
        else break;
    }
    for(int i=0;i<4;++i)
        if(a[i]){printf("NO\n");return 0;}
    puts("YES");
    for(int i=1;i<=ss;++i)printf("%d ",ans[i]);
    return 0;
}