#pragma GCC optimize(2)
#include<bits/stdc++.h>
using namespace std;
inline int read() {int x=0,f=1;char c=getchar();while(c!='-'&&(c<'0'||c>'9'))c=getchar();if(c=='-')f=-1,c=getchar();while(c>='0'&&c<='9')x=x*10+c-'0',c=getchar();return f*x;}
typedef unsigned long long ll;
const int maxn = 1e6+10;
char a[maxn];
int main()
{
	int t;
	cin>>t;
	while(t--){
		scanf("%s",a);
		int l=strlen(a);
		int flag=1;
		for(int i=0;i<l-1;i++){
			if(a[i]!='?'&&a[i+1]!='?'&&a[i]==a[i+1]){
				printf("-1\n");
				flag=0;
				break;
			}
		}
		if(flag==1){
		if(l==1&&a[0]=='?'){
				a[0]='a';
			}
			else{
				if(a[0]=='?'){
					if(a[1]=='a'||a[1]=='?'){
						a[0]='b';
					}
					else if(a[1]=='b'){
						a[0]='a';
					}
					else if(a[1]=='c'){
						a[0]='b';
					}
				}
				if(a[l-1]=='?'){
					if(a[l-2]=='a'||a[l-2]=='?'){
						a[l-1]='b';
					}
					else if(a[l-2]=='b'){
						a[l-1]='a';
					}
					else if(a[l-2]=='c'){
						a[l-1]='b';
					}
				}
			}
			for(int i=0;i<l-1;i++){
				if(a[i]=='?'){
					if(a[i-1]=='a'){
						if(a[i+1]=='?'||a[i+1]=='a'||a[i+1]=='c'){
							a[i]='b';
						}
						else if(a[i+1]=='b'){
							a[i]='c';
						}
					}
					if(a[i-1]=='b'){
						if(a[i+1]=='?'||a[i+1]=='b'||a[i+1]=='a'){
							a[i]='c';
						}
						else if(a[i+1]=='c'){
							a[i]='a';
						}
					}
					if(a[i-1]=='c'){
						if(a[i+1]=='?'||a[i+1]=='c'||a[i+1]=='b'){
							a[i]='a';
						}
						else if(a[i+1]=='a'){
							a[i]='b';
						}
					}
				}
			}
			
			printf("%s\n",a);
		}	
	}
	return 0;	
} 