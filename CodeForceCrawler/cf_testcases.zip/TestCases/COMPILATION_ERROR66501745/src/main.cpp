#include <iostream>
#include <stdio.h>
#include<algorithm>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include  <stdio.h>
#include   <math.h>
#include   <time.h>
#include   <vector>
#include   <bitset>
#include    <queue>
#include      <map>
#include      <set>
using namespace std;

const int N = 2e5+5;

int t, n, a[N];

int main(){
    scanf("%d", &t);
    while(t--){
        int Max = 1, len = 1, left = 0, right = 0;
        memset(ans, 0, sizeof(ans));
        ans[1] = 1;
        scanf("%d", &n);
        for(int i = 0; i < n; ++i){
            scanf("%d", &a[i]);
            if(a[i] == 1){
                left = right = i;
            }
        }
        while(len <= n){
            len += 1;
            if(left != 0 && (a[left-1] < a[right+1] || right == n-1)){
                left -= 1;
                if(a[left] > Max){
                    Max = a[left];
                }
            }else{
                right += 1;
                if(a[right] > Max){
                    Max = a[right];
                }
            }
            if(Max == len){
                printf("1");
            }else{
                printf("0");
            }
        }
        puts("");
    }
    return 0;
}