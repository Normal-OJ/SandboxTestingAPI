 #include<stdio.h>   
#include<iostream>
using namespace std;
int main()
{
	int t;
	cin>>t;
	while(t--)
	{  int n,a[200],w,v,h;
		cin>>n>>v>>w;
		for(int i=1;i<=n;i++)
		 cin>>a[i];
		 
	 for(int i=1;i<n;i++)
	       for(int l=1;l<n-i;l++)
	       if(a[l]>a[l+1])
	       {
	       	  int p=a[l];a[l]=a[l+1];a[l+1]=p;
		   }
			 double sumld=0.00;
			 if(a[1]>w) printf("0 0.00\n");
		    else  
			{
			for(h=1;h<=n;h++)
		       { if((sumld+a[h])/h<=w)
                    sumld += a[h];
                else{
				   h--;
                    break;}
			   }
			   sumld=sumld/h
	 printf("%d %.2lf\n",v*h,sumld/100);}
	}
	return 0;
 } 
   	 	    		 	 				 		 				