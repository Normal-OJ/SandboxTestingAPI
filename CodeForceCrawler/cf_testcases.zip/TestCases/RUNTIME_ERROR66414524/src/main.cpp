//
//  main.cpp
//  Hello
//
//  Created by Gasser Mamdouh on 29/10/2019.
//  Copyright © 2019 Gasser Mamdouh. All rights reserved.
//

#include <iostream>
#include <map>
#include <utility>
#include<algorithm>
#include<vector>
#include<unordered_map>
#include<unordered_set>
#include <stdlib.h>
#include <string.h>
#include <list>
#include <set>
#include <stdio.h>

using namespace std;
int main(){
    int testCase;
    scanf("%d", &testCase);
    while(testCase--){
        int n;
        scanf("%d", &n);
        vector<int> arr(n), idx(n);
        for(int i = 0; i < n; i++){
            int val;
            scanf("%d", &val);
            idx[val] = i;
        }
        int leftIdx = idx[1], rightIdx = idx[1];
        printf("1");
        for(int i = 2; i <= n; i++){
            leftIdx = min(leftIdx, idx[i]);
            rightIdx = max(rightIdx, idx[i]);
            if(rightIdx - leftIdx + 1 == i){
                printf("1");
            }else{
                printf("0");
            }
        }
        printf("\n");
    }
    return 0;
}
