t=int(input())
while t>0 :
    n=int(input());p=map(int,input().split());p=list(p)
    pos=[0]*(n+5);v=[0]*(n+5);cnt=0
    for i in range(n) : pos[p[i]]=i+1
    for i in range(1,n+1) :
        P=pos[i];v[P]=1;cnt+=v[P-1]+v[P+1]
        if cnt+1==i : print(1,end='')
        else : print(0,end='')
    print();t-=1
