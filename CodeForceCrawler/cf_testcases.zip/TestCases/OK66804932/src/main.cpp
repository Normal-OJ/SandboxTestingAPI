#include <bits/stdc++.h>
using namespace std;
 
#define fr first
#define sc second
#define pii pair<int, int>
//#define int long long
#define szof(s) (int)s.size()
#define all(s) s.begin(), s.end()	
#define prev myyyyrza1
#define y1 myyyyrza2
#define id id1234
#define pb push_back
#define OK() puts("OK")
// shuffle (v.begin(), v.end(), default_random_engine())
 
using namespace std;
 
const int N = (1e6 + 12);
const int MOD = (1e9 + 7);
const int INF = (0x3f3f3f3f);

vector <pair<int, int>> g[N];

int a[5], A[5];


int d(int a, int b) {
	return abs(a - b);
}

void gg() {
	puts("NO");
	exit(0);
}

int nxt(int v) {
	if (v == 0) {
		if (a[1]) {
			return 1;
		} else {
			return -1;
		}
	}
	if (v == 1) {
		if (a[2]) {
			return 2;
		}
		if (a[0]) {
			return 0;
		}
		return -1;
	}
	if (v == 2) {
		if (a[3]) {
			return 3;
		}
		if (a[1]) {
			return 1;
		} 
		return -1;
	}
	if (v == 3) {
		if (a[2]) {
			return 2;
		}
		return -1;
	}
}

void check(int prev) {
	for (int i = 0; i <= 3; i++) {
		a[i] = A[i];
	}
	
	vector <int> ans;
	while (1) {
		if (a[0] == 0 && a[1] == 0 && a[2] == 0 && a[3] == 0) {
			puts("YES");
			for (auto c : ans) {
				cout << c << " ";
			}
			exit(0);
		}
		if (a[prev] > 0) {
			ans.push_back(prev);
			a[prev]--;
			prev = nxt(prev);
		} else {
			return;
		}
	}
}

inline void solve() {
	cin >> a[0] >> a[1] >> a[2] >> a[3];
	for (int i = 0; i <= 3; i++) {
		A[i] = a[i];
	}
	
	for (int i = 0; i <= 3; i++) {
		check(i);
	}
	gg();
}

main()
{
	int Q = 1;
	//cin >> Q;
	while (Q--) {
		solve();
	}
}
