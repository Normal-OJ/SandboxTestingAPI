#include<iostream>
using namespace std;


int main(){
    int m,n,lim;
    cin>>m;
    while(m--){
        cin>>n;
        int sc[n];
        for (int i =0;i<n;i++)
            cin>>sc[i];
        lim=n/2;
        while (sc[lim-1]==sc[lim])
            lim--;
        int g=1,c;
        while(sc[g]==sc[g-1]){
            g++;
        }
        c=g+1
        while(sc[lim-c]==sc[lim-c-1])
            c++;
        if(lim-g-c<=g){
            cout<<"0 0 0"<<endl;
            continue;
        }
         cout<<g<<' '<<lim-c-g<<' '<<c<<endl;
    }
}
