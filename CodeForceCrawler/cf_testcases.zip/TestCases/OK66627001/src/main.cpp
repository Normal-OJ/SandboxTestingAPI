#include <bits/stdc++.h>
#define fi first
#define se second
#define mp make_pair
#define inf 1e18
using namespace std;

const int maxn = 1e6 + 5, mod = 998244353;
typedef long long ll;
ll p[maxn], q[maxn], a[maxn];
ll qpow(ll a, ll n){
    ll y = a, res = 1;
    while(n){
        if(n&1)res = res*y%mod;
        y = y*y%mod;
        n>>=1;
    }
    return res;
}
ll inv(ll n){
    return qpow(n, mod-2);
}

int main(){
    int n;
    cin>>n;
    for(int i = 0; i < n; i++){
        scanf("%lld", &a[i]);
    }
    p[0] = q[0] = 1;
    for(int i = 1; i <= n; i++){
        p[i] = (p[i-1]*100 + a[i-1]*q[i-1])%mod;
        q[i] = (a[i-1]*q[i-1])%mod;
    }
    p[n] = (p[n]+mod-q[n])%mod;
    cout<<(p[n]*inv(q[n]))%mod<<endl;
    return 0;
}

// 1
// 50

// 2

// 3
// 10 20 50

// 112
