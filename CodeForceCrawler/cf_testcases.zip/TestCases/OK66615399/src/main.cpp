#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <limits.h>
#include <math.h>
#include <time.h>
#include <queue>
#include <stdarg.h>
#include <map>
#include <vector>
#include <algorithm>
#include <stack>
#include <iostream>
#include <numeric>
#include <set>
 
#define ll long long
 
using namespace std;

ll mod = 998244353;

ll
inv(ll v) {
  ll ret = 1, t = v, k = mod - 2;
  while (k > 0) {
    if (k & 1) ret = ret * t % mod;
    t = t * t % mod;
    k >>= 1;
  }
  
  return ret;
}
 
void
solve() {
  ll n;
  cin>>n;

  vector<ll> p(n);
  for (int i=0; i<n; i++)
    cin>>p[i], p[i] = p[i] * inv(100) % mod;

  ll a = 1, b = 0;
  for (int i=0; i<n; i++) {
    a = a * inv(p[i]) % mod;
    b = b * inv(p[i]) % mod;
    a = (a + (p[i]-1) * inv(p[i])) % mod;
    b = (b - inv(p[i]) + mod) % mod;
  }

  cout<< (mod - b) * inv(a) % mod <<endl;
}

int 
main() {
  cin.tie(0);
  cout.tie(0);
  ios_base::sync_with_stdio(0);

  int t = 1;
  //cin>>t;

  while (t > 0) {
    t--;
    solve();
  }

  return 0;
}

