def medals(lst):
    lastBronze = len(lst) // 2
    if lastBronze > 1:
        moved = False
        while lastBronze > 0 and lst[lastBronze] == lst[lastBronze + 1]:
            lastBronze -= 1
            moved = True
        if moved:     
            lastBronze += 1                    
    if lastBronze <= 4:
        print(0,0,0)
    else:
        g = 0
        s = 0
        b = 0
        j = 0
        medalist = lst[:lastBronze]
        g += medalist.count(medalist[j])
        j += g
        while s <= g and j < lastBronze:
            temp = medalist.count(medalist[j])
            s += temp
            j += temp
        b += len(medalist[j:])
        if (g < b and b > 0):
            print(g,s,b)
        else:
            print(0,0,0)


def main():
    t = int(input())
    while t > 0:
        n = input()
        a = input().split()
        medals(a)
        t -= 1

b = '45 36 18 18 18 18 17 17 17 6 6 6 6 2 2'.split()
medals(b)            
#main()