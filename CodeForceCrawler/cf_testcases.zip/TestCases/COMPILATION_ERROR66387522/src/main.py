    n=int(input())
    k=0
    while n>0 :
        n-=1
        s1=str()
        s=str(input())
        for k in range(len(s)):
            a.append(s[k])
            for i in range(len(a)-2):
                if(a[i]==a[i+1] and a[i] != "?"):
                    k=-1
                else:
                    if ((a[i])=="a" and (a[i+1])=="?" and (a[i+2])=="c"):
                        (a[i+1])="b"
                    elif ((a[i])=="a" and (a[i+1])=="?" and (a[i+2])=="b"):
                        (a[i+1])="c"
                    elif((a[i])=="b" and (a[i+1])=="?" and (a[i+2])=="a"):
                        (a[i+1])="c"
                    elif((a[i])=="b" and (a[i+1])=="?" and (a[i+2])=="c"):
                        (a[i+1])="a"
                    elif((a[i])=="c" and (a[i+1])=="?" and (a[i+2])=="b"):
                        (a[i+1])="a"
                    elif((a[i])=="c" and (a[i+1])=="?" and (a[i+2])=="a"):
                        (a[i+1])="b"
                    elif ((a[i])=="a" and (a[i+1])=="?" and (a[i+2])=="?"):
                        (a[i+1])="b"
                    elif((a[i])=="b" and (a[i+1])=="?" and (a[i+2])=="?"):
                        (a[i+1])="c"
                    elif((a[i])=="c" and (a[i+1])=="?" and (a[i+2])=="?"):
                        (a[i+1])="b"
                    elif((a[i])=="c" and (a[i+1])=="?" and (a[i+2])=="c"):
                        (a[i+1])="a"
                    elif((a[i])=="b" and (a[i+1])=="?" and (a[i+2])=="b"):
                        (a[i+1])="c"
                    elif((a[i])=="a" and (a[i+1])=="?" and (a[i+2])=="a"):
                        (a[i+1])="b"
                    elif((a[n-1])=="a" and (a[n])=="?"):
                        (a[n])="b"
                    elif((a[n-1])=="b" and (a[n])=="?"):
                        (a[n])="c"
                    elif((a[n-1])=="c" and (a[n])=="?"):
                        (a[n])="a"
        for h in range(len(a)):
            if k==-1:
                print("-1")
            else:
                s1=s1+a[h]
        if k!=-1:        
            print(s1)