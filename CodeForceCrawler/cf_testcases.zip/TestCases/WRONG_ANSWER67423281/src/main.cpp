#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
using namespace std;
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    
    int q;
    cin >> q;

    while (q--){
        int n;
        cin >> n;

        int a[n], one;
        string ans;

        for (int i = 0; i < n; i++){
            cin >> a[i];
            ans += '0';

            if (a[i] == 1)
                one = i;
        }
        
        int l = one, r = one, m = 1, s = 1;
        while (l != 0 && r != n-1){
            if (l == 0){
                r++;
                s++;

                if (a[r] > m)
                    m = a[r];

                if (m == s){
                    ans[s] = '1';
                }
            }
            else if (r == n-1){
                l--;
                s++;

                if (a[l] > m)
                    m = a[l];

                if (m == s){
                    ans[s] = '1';
                }
            }
            else
                if (a[l-1] > a[r+1]){
                    r++;
                    s++;

                    if (a[r] > m)
                        m = a[r];

                    if (m == s){
                        ans[s] = '1';
                    }
            }
            else{
                l--;
                s++;

                if (a[l] > m)
                    m = a[l];

                if (m == s){
                    ans[s] = '1';
                }
            }
        }

        ans[0] = ans[n-1] = '1';
        cout << ans << '\n';
    }
}