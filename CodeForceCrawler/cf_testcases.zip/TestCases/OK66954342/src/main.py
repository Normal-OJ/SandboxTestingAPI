import sys

LETTERS = 'abc'

def solve(s: str):
	n = len(s)
	a = list(s)
	for i in range(n):
		if i + 1 < n and a[i] == a[i+1] and a[i] != '?':
			print(-1)
			return
		if a[i] == '?':
			for l in LETTERS:
				if i > 0 and a[i-1] == l:
					continue
				if i + 1 < n and a[i+1] == l:
					continue
				a[i] = l
				break
	print(''.join(a))


t = int(input())
for i in range(t):
	line = input()
	solve(line)