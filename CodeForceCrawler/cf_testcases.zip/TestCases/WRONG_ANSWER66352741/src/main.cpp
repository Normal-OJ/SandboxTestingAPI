#include<bits/stdc++.h>
#define mes(a, b) memset(a, b, sizeof a)
using namespace std;
typedef long long ll;
const int maxn = 2e3+10;
const ll mod = 998244353;
ll dp[maxn][maxn];
char ch[maxn];
int main(){
    ll ans = 0;
    scanf("%s",ch+1);
    int len = strlen(ch+1);
    for(int i = 1; i <= len; i++){
        ll num = 0;
        for(int j = 0; j <= len; j++){
            if(ch[i] == '?'){
                dp[i][j] = dp[i-1][j+1];
                dp[i][j] += j > 0 ? dp[i-1][j-1] : 0;
                num += dp[i-1][j];
            }
            else if(ch[i] == '('){
                dp[i][j] = j > 0 ? dp[i-1][j-1] : 1;
            }
            else{
                dp[i][j] = dp[i-1][j+1];
                num += dp[i-1][j];
            }
            num %= mod;
            dp[i][j] %= mod;
          //  printf("i = %d, j = %d, dp = %lld\n", i, j, dp[i][j]);
        }
        ans = (ans + num) % mod;
        //printf("ans = %lld\n", ans);
    }
    printf("%lld\n", ans%mod);
    return 0;
}
