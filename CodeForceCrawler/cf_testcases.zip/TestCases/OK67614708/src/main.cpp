#include <bits/stdc++.h>
using namespace std;
const int maxn = 2e3+5;
const int mod = 998244353;
typedef long long ll;
ll dp[maxn][maxn];
char s[maxn];
ll qpow(ll a,int b)
{
    ll res = 1;
    for(int i = 0;b;b>>=1)
    {
        if(b&1)res = res*a%mod;
        a = a*a%mod;
    }
    return res;
}
int cnt[maxn];
int main()
{
    int n;
    //scanf("%d",&n);
    scanf("%s",s+1);
    n = strlen(s+1);
    for(int i = 1;i <= n;++i)
    cnt[i]=cnt[i-1]+(s[i]=='?');
    for(int len = 2;len <= n;++len)
    {
        for(int i = 1;i <= n;++i)
        {
            int j = i+len-1;
            if(j>n)break;
            if(s[i]!='(')dp[i][j]+=dp[i+1][j],dp[i][j]%=mod;
            if(s[j]!=')')dp[i][j]+=dp[i][j-1],dp[i][j]%=mod;
            if(s[i]!='('&&s[j]!=')'){
                dp[i][j]-=dp[i+1][j-1];
                dp[i][j]+=mod;
                dp[i][j]%=mod;
            }
            if(s[i]!=')'&&s[j]!='(')
                dp[i][j]+=dp[i+1][j-1]+qpow(2,cnt[j-1]-cnt[i]);
            dp[i][j]%=mod;
        }
    }
    printf("%lld\n",dp[1][n]);
    return 0;
}
