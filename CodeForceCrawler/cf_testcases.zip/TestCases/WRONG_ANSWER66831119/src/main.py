
def solve():
    a,b,c,d = list(map(int,input().split(' ')))
    rp = []
    if c >= d - 1 and d > 0:
        rp = [2 if i%2 else 3 for i in range(2*d - 1)]
        c -= d - 1;
        d = 0
    
    lp = []
    if b >= a - 1 and a > 0:
        lp = [1 if i%2 else 0 for i in range(2*a - 1)]
        b -= a - 1;
        a = 0
    
    # print(b,c)
    if abs(b - c) > 1 or min(b,c) == 0:
        print('NO')
    else:
        mp = [1 if i%2 else 2 for i in range(2*min(c,b))]
        if c>b:
            rp = [2] + rp
        elif b>c:
            lp.append(1)
        print("YES")
        arr = [*rp,*mp,*lp];
        # print(len(list(filter(lambda x: x== 0,arr))))
        # print(len(list(filter(lambda x: x== 1,arr))))
        # print(len(list(filter(lambda x: x== 2,arr))))
        print(*rp,*mp,*lp)
    # print(b,c)
    # print(rp)
    # print(lp)
    
# n = int(input())
# for i in range(n):
solve()
