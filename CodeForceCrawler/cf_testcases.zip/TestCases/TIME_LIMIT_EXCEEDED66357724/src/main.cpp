#include <bits/stdc++.h>
#define pb push_back
using namespace std;
#define ll long long
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	int a,b,c,d;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	//2消3，2消1
	int fgg=0;
	if(b>=a)
	{
	int fg=0;
	if(b==a&&c)
	a--,fg=1;
	int p=b-a;
	int x1=p;int x3=d;
	if(d>c||c-p!=d)
	{fgg=1;
	goto k;
	}
	printf("YES\n");
//	cout<<"YES"<<endl;
	
	for(int i=0;i<a;i++)
	{
		printf("0 1 ");
	
	}
	
	for(int i=0;i<x3;i++)
	{
		printf("2 3 ");
	}
	for(int i=0;i<x1;i++)
	{
		printf("2 1 ");
	}
	if(fg)
	printf("0");
	}
	else if(b<a)
	{
		if(c||d||a-b!=1)
		{
		//	cout<<"NO"<<endl;
			goto k;
		}
		else
		{
			printf("YES\n");
			for(int i=0;i<b;i++)
			{
				printf("0 1 ");
			}
			printf("0");
		}
	}
	return 0;
	k:;
	swap(d,a);
	swap(b,c);
	fgg=0;
	if(b>=a)
	{
	int fg=0;
	if(b==a&&c)
	a--,fg=1;
	int p=b-a;
	int x1=p;int x3=d;
	if(d>c||c-p!=d)
	{fgg=1;
	goto k;
	}
	printf("YES\n");
//	cout<<"YES"<<endl;
	
	for(int i=0;i<a;i++)
	{
		printf("3 2 ");
	}
	
	for(int i=0;i<x3;i++)
	{
		printf("1 0 ");
	}
	for(int i=0;i<x1;i++)
	{
		printf("1 2 ");
	}
	if(fg)
	printf("3");
	}
	else if(b<a)
	{
		if(c||d||a-b!=1)
		{
			printf("NO");
			return 0;
		}
		else
		{
			printf("YES\n");
			for(int i=0;i<b;i++)
			{
				printf("3 2 ");
			}
			cout<<0;
		}
	}
	return 0;
}