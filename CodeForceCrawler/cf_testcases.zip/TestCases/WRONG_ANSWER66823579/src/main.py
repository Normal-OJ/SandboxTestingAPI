n = int(input())

s = [[] for i in range(n)]

for i in range(n):
    s[i] = input()

for i in range(n):
    t = list(s[i])
    for j in range(len(t)):
        if t[j] == '?':
            pool = {'a','b','c'}
            if j > 0:
                pool.discard(t[j-1])
            if j < (len(s) - 1):
                pool.discard(t[j+1])
            t[j] = pool.pop()
    t = ''.join(t)
    for i in range(len(t)-1):
        if t[i] == t[i+1]:
            print(-1)
            break
    else:
        print(t)