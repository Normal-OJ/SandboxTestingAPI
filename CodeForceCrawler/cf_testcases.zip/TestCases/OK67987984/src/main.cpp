#include <bits/stdc++.h>

using namespace std;

typedef long long LL;

int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(nullptr);

  int T;
  cin >> T;
  for (string s; T-- > 0 && cin >> s;) {
    auto go = [&]() {
      int n = s.size();
      for (int i = 1; i < n; ++i) {
        if (s[i] != '?' && s[i] == s[i - 1]) {
          cout << -1 << '\n';
          return;
        }
      }
      char ch = 'a';
      for (int i = 0; i < n; ++i) {
        if ('?' == s[i]) {
          if (i + 1 >= n || '?' == s[i + 1]) {
            s[i] = ch == 'a' ? 'b' : ch == 'b' ? 'c' : 'a';
          } else {
            if (ch == s[i + 1]) {
              s[i] = ch == 'a' ? 'b' : ch == 'b' ? 'c' : 'a';
            } else {
              s[i] = 'a' + (3 - (ch - 'a') - (s[i + 1] - 'a'));
            }
          }
        }
        ch = s[i];
      }
      cout << s << '\n';
    };
    go();
  }

  return 0;
}
