#include <bits/stdc++.h>

using namespace std;

const int N = (int)2e5 + 2;

int a, b, c, d;

int main ()
{
    scanf ("%d %d %d %d", &a, &b, &c, &d);
    int lasta = a, lastb = b, lastc = c, lastd = d;
    for (int which = 0; which <= 3; ++which)
    {
        a = lasta, b = lastb, c = lastc, d = lastd;
        vector < int > res;
        if (a > 0 && which == 0) res.push_back(0), --a;
        else if (c > 0 && which == 2) res.push_back(2), --c;
        else if (d > 0 && which == 3) res.push_back(3), --d;
        else if (b > 0 && which == 1) res.push_back(1), --b;
        bool bad = false;
        while (1)
        {
            if (a <= 0 && b <= 0 && c <= 0 && d <= 0) break;
            if (res[(int)res.size() - 1] == 0)
            {
                res.push_back(1);
                --b;
            }
            else if (res[(int)res.size() - 1] == 1)
            {
                if (a > 0) res.push_back(0), --a;
                else res.push_back(2), --c;
            }
            else if (res[(int)res.size() - 1] == 2)
            {
                if (b > 0) res.push_back(1), --b;
                else res.push_back(3), --d;
            }
            else if (res[(int)res.size() - 1] == 3)
            {
                res.push_back(2);
                --c;
            }
            if (a < 0 || b < 0 || c < 0 || d < 0)
            {
                bad = true;
                break;
            }
        }
        if (!bad)
        {
            printf ("YES\n");
            for (int to : res) printf ("%d ", to);
            return 0;
        }
    }
    printf ("NO\n");
    return 0;
}
