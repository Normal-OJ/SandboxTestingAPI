t = int(input())
for _ in range(t):
    s = [c for c in input()]
    n = len(s)
    for i in range(n):
        if(s[i]=='?'):
            p = '1' if i==0 else s[i-1]
            ne = '0' if i==n-1 else s[i+1]
            for x in 'abc':
                if (x != p) and (x != ne):
                    s[i] = x
                    break
    q = 1
    o = ''
    for i in range(n-1):
        o+=s[i]
        if s[i]==s[i+1]:
            q = 0
            break
    o+=s[n-1]
    if q:
        print(o)
    else:
        print(-1)
