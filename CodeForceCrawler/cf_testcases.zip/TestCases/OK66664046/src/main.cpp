#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define mp make_pair
#define fi first
#define se second
#define io ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL)
#define pb push_back
#define pii pair<ll,ll>
#define mod 998244353
ll expo(ll a,ll b){ll r=1;a=a%mod;while(b){if(b%2)r=(r*a)%mod;a=(a*a)%mod;b=b/2;}
return r;}
int main(){
	io;
	int n;
	cin>>n;
	ll a[n+1];
	for(int i=1;i<=n;i++){
		cin>>a[i];
		a[i]=(a[i]*expo(100,mod-2))%mod;
	}
	ll sm=1,p=1;
	for(int i=1;i<n;i++){
		p=(p*a[i])%mod;
		sm=(sm+p)%mod;
	}
	p=(p*a[n])%mod;
	sm=(sm*expo(p,mod-2))%mod;
	cout<<sm;
	return 0;
}
