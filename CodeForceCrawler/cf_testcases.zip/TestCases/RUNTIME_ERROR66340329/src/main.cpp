# include <iostream>
# include <cstring>
# include <algorithm>
using namespace std;

int A[200005];
int p[200005];

int main()
{
	int T;
	cin >>T;
	ios::sync_with_stdio(0);
	while(T--)
	{
		int n, l, r;
		cin >>n;
		memset(p, 0, sizeof(p));
		for(int i = 1; i <= n; i++)
		{
			cin >>A[i];
			p[A[i]] = i;
		}
		
		l = r = p[1];
		
		for(int i = 1; i <= n; i++)
		{
			l = min(l, p[i]);
			r = max(r, p[i]);
			
			if(r-l+1 == i)
				cout<<'1';
			else
				cout<<'0';
		}
		 
		cout<< endl;
	}
}