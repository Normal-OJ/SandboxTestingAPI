t=int(input())
for i in range(t):
	n=int(input())
	a=list(map(int,input().split()))
	if(len(a)<5):
		print("0 0 0")
	else:
		x=n//2-1
		val=a[x+1]
		a=a[:x+1]

		if(val==a[x]):
			while(a[-1]==val):
				a=a[:-1]
		final=len(a)
		wr=False
		if(len(a)<5):
			wr=True
		else:
			g_ctr=0
			g=a[0]
			g_ctr+=1
			a=a[1:]
			while(len(a)>=1 and a[0]==g):
				g_ctr+=1
				a=a[1:]
			if(len(a)<2*(g_ctr+1)):
				wr=True
			else:
				s_ctr=0
				s=a[0]
				s_ctr+=1
				a=a[1:]
				while(len(a)>=1 and a[0]==s):
					s_ctr+=1
					a=a[1:]
				while(s_ctr<(g_ctr+1)):
					s_ctr+=1
					a=a[1:]
				if(len(a)<(g_ctr+1)):
					wr=True
		if(wr):
			print("0 0 0")
		else:
			print(g_ctr,s_ctr,final-(g_ctr+s_ctr))



