/*
ID: blackha5
TASK: test
LANG: C++
*/
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>

#define ff first
#define ss second
#define Maxn 200003
#define ll long long
#define pb push_back
#define Inf 998244353
#define ppb() pop_back()
#define pii pair <ll , ll>
#define mid(x, y) (x + y) / 2
#define all(x) x.begin(),x.end()
#define llInf 1000000000000000009
#define tr(i, c) for(__typeof(c).begin() i = (c).begin() ; i != (c).end() ; i++)
using namespace std;
using namespace __gnu_pbds;
typedef tree <int, null_type, less <int>, rb_tree_tag, tree_order_statistics_node_update> order;

int n;
ll p, ans;

ll bigmod (ll a, ll b) {
	if (!b)
		return 1;
	
	ll res = bigmod (a, b / 2);
	res = res * res % Inf;

	if (b & 1)
		res = res * a % Inf;

	return res;	
}

int main () {
	//freopen ("file.in", "r", stdin);
	//freopen ("file.out", "w", stdout);

 	//srand ((unsigned) time ( NULL ));
	//int randomNumber = rand() % 10 + 1;
		
	scanf ("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf ("%I64d", &p);
		
		p = 100 * bigmod (p, Inf - 2) % Inf;
		ans = (ans + 1) * p % Inf;
	}
	
	printf ("%I64d\n", ans);
	return 0;
}
