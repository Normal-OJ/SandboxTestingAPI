#beautiful_numbers
t = int(input())
tests = []
for i in range(t):
	input()
	tests.append(list(map(int, input().split())))

checked = []

def ok(sub, x):
	global checked
	if max(sub) <= x:
		checked.extend(sub)
		return True
	return False

def beautiful(perm, x):
	i2 = perm.index(x)
	for i in range(1, x):
		if i in checked:
			continue
		i1 = perm.index(i)
		sub = (perm[i1:i2] if i1 < i2 else perm[i2:i1])
		if not ok(sub, x):
			return False
	return True

for perm in tests:
	ans = [0] * len(perm)
	for i in range(1, len(ans) + 1):
		if beautiful(perm, i):
			ans[i - 1] = "1"
		else:
			ans[i - 1] = "0"
	print("".join(ans))
