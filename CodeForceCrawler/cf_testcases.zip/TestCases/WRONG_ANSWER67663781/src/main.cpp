#include<bits/stdc++.h>
#include<string.h>
using namespace std;

int main()
{
	int n;
	cin>>n;
	while(n--)
	{
		string a;
		cin>>a;
		int x=a.length();
		if(x==1)
		{
		
		if(a[0]=='?')
		a[0]='a';
		cout<<a;
		continue;
		}
		for(int i=1;i<n;i++)
		{
			if(a[i]==a[i-1] && a[i]!='?')
			{
				cout<<"-1\n";
				continue;
			}
		}
		for(int i=0;i<x;i++)
		{
			if(i%2==0)
			a[i]='a';
			else
			a[i]='b';
		}
		cout<<a<<"\n";
	}
}
