
#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define inf 0x3f3f3f3f
#define mem(a,b) memset(a,b,sizeof(a))
 
int main()
{
	int t,n,i;
	string a;
	cin>>t;
	while(t--)
	{
		int flag=0;
		cin>>a;
		for(i=0;i<a.length();i++)
		{
			if(a[i]=='?')
			{
				if(i!=0)
					a[i]=(a[i-1]-'a'+1)%3+'a';
				else
					a[i]='a';
				if(a[i+1]!='?')
					if(a[i]==a[i+1])
						a[i]=(a[i+1]-'a'+1)%3+'a';
			}
		}
		for(i=0;i<a.length();i++)
		{
			if(a[i]==a[i+1])
			{
				flag=1;
				break;
			}
		}
		if(flag)
			cout<<"-1"<<endl;
		else
			cout<<a<<endl;
	}
	return 0;
}
			      	 	 	   		 	 	 		 	 	