def naive_string_matcher(T,P):
    n = len(T)
    m = len(P)
    for i in range(n - m + 1):
        if P == T[i:i+m]:
            return True
    return False

# a????????????с?b
t = int(input())
setts = {"a","c","b"}
for i in range(t):
     s = input()
     if naive_string_matcher(s,"aa") or naive_string_matcher(s,"cc") or naive_string_matcher(s,"bb"):
         print("-1")
     elif s == "?":
         print("a")
     else:
         s1 = list(s)
         for i in range(len(s1)):
             if s1[i] == "?":
                 if i == 0:
                     c = list(setts - {s1[i+1]})
                     s1[i] = c[0]
                 elif i == len(s1) - 1:
                     c = list(setts - {s1[i-1]})
                     s1[i] = c[0]
                 else:
                    c = list(setts - {s1[i-1],s1[i+1]})
                    s1[i] = c[0]

         for i in s1:
             print(i,end="")
         print("")
