#include<bits/stdc++.h>
using namespace std;

const int M = 2e5+5, mod = 998244353;

int n;
int fac[M];

int mul(int x, int y){
    return 1ll * x * y % mod;
}
void inc(int& x, int y){
    x += y;
    if(x >= mod) x -=mod;
}
int pow(int p,int q){
    int res = 1;
    while(q){
        if(q&1) res= mul(res, p);
        p = mul(p , p);
        q >>= 1;
    }
    return res;
}


int main(){
    scanf("%d", &n);
    fac[0] = 1;
    for(int i = 1; i <= n; i ++){
        scanf("%d", &fac[i]);
        fac[i] = mul(fac[i-1], fac[i]);
    }
    int ans = 0;
    for(int i = 0; i < n; i ++){
        inc(ans, mul(fac[i], pow(100, n-i)));
    }
    ans = mul(ans, pow(fac[n], mod-2));
    printf("%d\n", ans);
}
