#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int,int> PII;
typedef pair<ll,ll> Pll;
typedef vector<int> VI;
typedef vector<PII> VII;
typedef pair<ll,ll>P;
#define N  1000000+10
#define M  4000000+10
#define INF 1e9
#define fi first
#define se second
#define MP make_pair
#define pb push_back
#define pi acos(-1)
#define mem(a,b) memset(a,b,sizeof(a))
#define rep(i,a,b) for(int i=(int)a;i<=(int)b;i++)
#define per(i,a,b) for(int i=(int)a;i>=(int)b;i--)
#define lowbit(x) x&(-x)
#define Rand (rand()*(1<<16)+rand())
#define id(x) ((x)<=B?(x):m-n/(x)+1)
#define ls p<<1
#define rs p<<1|1
#define fors(i) for(auto i:e[x]) if(i!=p)

const int MOD=1e9+7,inv2=(MOD+1)/2;
      //int p=1e4+7;
      //double eps=1e-6;
      int dx[4]={-1,1,0,0};
      int dy[4]={0,0,-1,1};

int a[N],c[N],S[N];

int read()
{
   int v=0,f=1;
   char c=getchar();
   while(c<48||57<c) {if(c=='-') f=-1; c=getchar();}
   while(48<=c&&c<=57) v=(v<<3)+v+v+c-48,c=getchar();
   return v*f;
}

ll readll()
{
   ll v=0,f=1;
   char c=getchar();
   while(c<48||57<c) {if(c=='-') f=-1; c=getchar();}
   while(48<=c&&c<=57) v=(v<<3)+v+v+c-48,c=getchar();
   return v*f;
}

int main()
{
    //freopen("1.in","r",stdin);
    //freopen("1.out","w",stdout);
    int cas=read();
    while(cas--)
    {
        int n=read();
        rep(i,1,n) a[i]=read();
        int m=1; c[1]=1;
        rep(i,2,n)
         if(a[i]==a[i-1]) c[m]++;
          else m++,c[m]=1;
        //printf("m=%d\n",m);
        //rep(i,1,m) printf("%d ",c[i]);
        //printf("\n");
        if(m<=3)
        {
            printf("0 0 0\n");
            continue;
        }
        S[0]=0;
        rep(i,1,m) S[i]=S[i-1]+c[i];
        int ans=0,s1=0,s2=0,s3=0;
        int g=0,s,b,k=m,sum=0;
        rep(i,1,m)
        {
            sum+=c[i];
            if(sum>(n/2)){k=i-1; break;}
        }
        //printf("k=%d\n",k);
        g=c[1];
        rep(i,2,k-1)
        {
            s=S[i]-S[1],b=S[k]-S[i];
            //printf("g=%d s=%d b=%d\n",g,s,b);
            if(s<=0||b<=0) continue;
            if(g>=s||g>=b) continue;
            //if(c[2]==c[1]||c[i]==c[i+1]) continue;
            if(g+s+b>(n/2)) continue;
            if(g+s+b>ans)
            {
                ans=g+s+b;
                s1=g,s2=s,s3=b;
            }
        }
        printf("%d %d %d\n",s1,s2,s3);

    }
    return 0;
}
