#include<bits/stdc++.h>
using namespace std;
#define ll long long int 
#define mod 1000000007
int main()
{
  int t;
  cin>>t;
  while(t--)
  {
    int n;
    cin>>n;
    ll a[n];
    for(int i=0;i<n;i++)
    cin>>a[i];
    vector<int> v;
    int c=0;
    ll x=a[0];
    for(int i=0;i<n;i++)
    {
        if(x==a[i])
        c++;
        else
        {
            v.push_back(c);
            c=1;
            x=a[i];
        }
    }
    v.push_back(c);
    int g=0,s=0,b=0;
    g=v[0];
    int m=v.size();
    int p=1;
    while(p<m&&s<=g)
    {
        s+=v[p];
        p++;
    }
    for(int i=p;i<m;i++)
    {
        if(g+s+b+v[i]<=n/2)
        b+=v[i];
        else
        break;
    }
    if(g==0||s==0||b==0||g>=s||g>=b||(g+s+b)>n/2)
    cout<<0<<" "<<0<<" "<<0<<endl;
    else
    cout<<g<<" "<<s<<" "<<b<<endl;
  }
}