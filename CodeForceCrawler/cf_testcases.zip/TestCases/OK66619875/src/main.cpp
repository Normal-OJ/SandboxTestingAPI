#include <iostream>

#define ll long long

using namespace std;

const ll MOD = 998244353;
const int N = 2e5+5;

int n;
int p[N];

ll fastpow(ll a, ll b)
{
    if (b == 0) return 1;
    if (b == 1) return a;
    ll tmp = fastpow(a, b>>1);
    tmp = (tmp*tmp) % MOD;
    if (b&1)
        return (tmp*a) % MOD;
    else
        return tmp;
}

ll add(ll a, ll b) {return (a+b) % MOD;}
ll mul(ll a, ll b) {return (a*b)%MOD;}

int main()
{
    cin >> n;
    for(int i = 1; i <= n; i++) cin >> p[i];

    int inv100 = fastpow(100, MOD-2);
    ll res = 1;
    ll tmp = 1;
    for(int i = 1; i <= n; i++)
    {
        tmp = mul(tmp, p[i]);
        tmp = mul(tmp, inv100);

        res = add(res, tmp);
    }

    for(int i = 1; i <= n; i++)
    {
        res = mul(res, 100);
        res = mul(res, fastpow(p[i], MOD-2));
    }

    cout << res-1;
    return 0;
}
