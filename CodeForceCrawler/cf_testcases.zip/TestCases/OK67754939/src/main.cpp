#include <bits/stdc++.h>
using namespace std;
int main() {
   int t; cin>> t;
   while(t--){
       string s;
       cin >>s;
       for(int i=0; i< s.length(); i++){
           if(s[i]=='?'){
               if(i>0 && i<s.length()-1){
                   if(s[i-1] != 'a' && s[i+1]!= 'a') s[i]= 'a';
                    else if(s[i-1] != 'b' && s[i+1]!= 'b') s[i]= 'b';
                    else if(s[i-1] != 'c' && s[i+1]!= 'c') s[i]= 'c';
               }
               else if(i == 0){
                   if(s[1]!= 'a') s[0] = 'a';
                   else s[0] = 'b';
               }else if(i == s.length()-1){
                   if(s[s.length()-2]!= 'a') s[s.length()-1] = 'a';
                   else s[s.length()-1] = 'b';
               }
           }
       }
       int cnt =0;
       for(int i=0; i< s.length()-1; i++){
           if(s[i]==s[i+1]){
               cnt =1;
               break;
            }
        }
        if(cnt ==1) cout << "-1" <<endl;
        else cout << s << endl;
    }
}
 
 