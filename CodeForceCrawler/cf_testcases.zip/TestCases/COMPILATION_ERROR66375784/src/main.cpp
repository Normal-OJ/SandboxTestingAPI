#include <bits/stdc++.h>
using namespace std;
#define FOR(z,l,n) for(int z=l;z<n;z++)
#define pii pair<int,int>
#define mp make_pair
#define ll long long int
#define pll pair<long long,long long>
const bool debug = true;
template<typename T>
void printl(vector<T>& args){
    if(debug){
        for(auto it = args.begin();it!=args.end();it++){
            cout<<*it<<" ";
        }
        cout<<endl;
    }
}
void printl(const list<double>& args){
    if(debug){
        for(auto it = args.begin();it!=args.end();it++){
            cout<<*it<<" ";
        }
        cout<<endl;
    }
}
void printl(const list<string>& args){
    if(debug){
        for(auto it = args.begin();it!=args.end();it++){
            cout<<*it<< " ";
        }
        cout<<endl;
    }
}
char next(char ch){
    if(ch=='a')return 'b';
    if(ch=='b')return 'c';
    return 'a';
}
int main(){
    int t=0;
    cin>>t;
    while(t--){
        string s;
        cin>>s;
        bool poss=true;
        FOR(z,0,s.length()-1){
            if(s[z]==s[z+1] && s[z]!='?'){
                cout<<-1<<endl;
                poss=false;
                break;
            }
        }
        if(poss){
            FOR(z,0,s.length()){
                if(s[z]=='?'){
                    if(z==s.length()-1){
                        s[z]=next(s[z-1]);
                    }
                    else if(s[z+1]=='?'){
                        if(z==0)s[z]='a';
                        else s[z]=next(s[z-1]);
                    }
                    else{
                        if(Z==0 || s[z-1]==s[z+1])s[z]=next(s[z+1]);
                        else s[z]='a'+'b'+'c'-s[z-1]-s[z+1];
                    }
                }
            }
            cout<<s<<endl;
        }
    }
}