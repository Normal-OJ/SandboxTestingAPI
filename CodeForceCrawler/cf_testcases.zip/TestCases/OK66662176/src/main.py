
def solve():
    s = input()
    if 'aa' in s or 'bb' in s or 'cc' in s:
        print(-1)
        return
    syms = s + '@'
    ans = ['@']
    for i, sym in enumerate(s):
        if sym != '?':
            ans.append(sym)
            continue
        for x in 'abc':
            if x != ans[-1] and x != syms[i + 1]:
                ans.append(x)
                break
    print(''.join(ans[1:]))
 
 
if __name__ == '__main__':
    for _ in range(int(input())):
        solve()