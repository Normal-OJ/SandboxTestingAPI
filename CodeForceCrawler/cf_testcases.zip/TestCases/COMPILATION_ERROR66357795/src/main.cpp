#include <bits/stdc++.h>
#define ll long long
using namespace std;
 
void win() {
    string s;
    cin >> s;
    for(int i = 0; i < s.size() ; i++)
    { 
	   if(s[i] == s[i + 1] && s[i] != '?')
	   {
	   	cout << -1 << endl;
	   	return;
	   }
    }
    for(int i = 0; i < s.size() ; i++){
    	
		if(s[i] == '?'){
		
	
	   if(s[i - 1] == 'a') 
	      {
	      	if(s[i + 1] == 'b')  s[i] = 'c';
	      	   else s[i] = 'b';
		  }
	   else {
	   	    if(s[i - 1] == 'b') 
	      {
	      	if(s[i + 1] == 'c')  s[i] = 'a';
	      	   else s[i] = 'c';
		  }
		    else {
		    	 
	      
	      	if(s[i + 1] == 'a')  s[i] = 'b';
	      	   else s[i] = 'a';
		  }
			}
	   }	       
															  
    }}
	
	cout << s << endl;
}
int main()
{
	int m ;
	cin >> m;
	while(m--)
	{
		win();
	}
	
}
