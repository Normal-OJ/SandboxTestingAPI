def Beautiful_R_C(inp):
	ans = [0,0,0]
	ls = inp.split(" ")
	for i in range(0,len(inp)//2-1):
		if(i==0):
			ans[0] = ans[0]+1
		elif(i==1):
			ans[1] = ans[1]+1
		else:
			ans[2]  = ans[2]+1
	if(ans[0]>ans[1]>ans[2]):
		print(ans)
	else:
		print([0,0,0])
t = int(input())
while t>0:
	n = input()
	a = input()
	Beautiful_R_C(a)
	t=-1