#include <iostream>
using namespace std;
int t,n,mx,mn,a[4000005],b[4000005];
int main()
{
	cin>>t;
	while(t--)
	{
		cin>>n;
		for(int i=1;i<=n;i++)
		{
			cin>>a[i];
			b[a[i]]=i;
		}
		mn=1e8;
		mx=0;
		for(int i=1;i<=n;i++)
		{
			mx=max(mx,b[i]);
			mn=min(mn,b[i]);
			if(mx-mn+1=i)
			cout<<1;
			else cout<<0;
		}
	}
	return 0;
} 
