#include<bits/stdc++.h>
using namespace std;

int main()
{
	int n,j,flag,flag1,flag2,i,t1,t2,t,b[100009];
	scanf("%d",&n);
    while(n--)
    {
    	char a[100009];
    	scanf("%s",&a);
    	j=0;
    	flag=1;
    	t1=-1;t2=-1;
    	t=strlen(a);
    	if ((a[0]==a[1]&&a[0]!='?')||(a[t-1]==a[t-2]&&a[t-1]!='?')) 
		{
			printf("-1\n");
			continue;
		}
    	if (a[0]=='?')
    	{
    		if (a[1]!='a') a[0]='a';
    		else a[0]='b';
		}
		if (a[t-1]=='?')
    	{
    		if (a[t-2]!='a') a[t-1]='a';
    		else a[t-1]='b';
		}
    	for(i=1;i<strlen(a)-1;i++)
    	{
    		if (a[i]=='?') 
			{
				if (a[i-1]=='a')
				{
					if (a[i+1]!='b') a[i]='b';
					else a[i]=c;
				}
				else 
				{
					if (a[i+1]!='a') a[i]='a';
					else if (a[i-1]=='b') a[i]=c;
					else a[i]=b;
				}
//				while(a[i]==a[i+1]||a[i]==a[i-1])
//				{
//					a[i]=a[i]+1;
//				}
			}
			else
			{
				if (a[i]==a[i-1]||a[i]==a[i+1]) 
				{
					printf("-1\n");
					flag=0;
					break;
				}
			}
		}
		if (flag==1) printf("%s\n",a);
	}
}
/*
??b?c
??b??b??c?a?b?b?b
*/ 