#include<bits/stdc++.h>
using namespace std;
int main(void)
{
	int a,b,c,d;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	if(b<a||c<d) printf("NO\n");
	else
	{
		printf("YES\n");
		int f=1;
		while(a||b)
		{
			if(f)
			{
				printf("0 ");
				a--;
			}
			else
			{
				printf("1 ");
				b--;
			}
			f=f^1;
		}
		f=1;
		while(c||d)
		{
			if(f)
			{
				printf("2 ");
				c--;
			}
			else
			{
				printf("3 ");
				d--;
			}
			f=f^1;
		}
	}
}