#include <map>
#include <set>
#include <list>
#include <ctime>
#include <cmath>
#include <stack>
#include <queue>
#include <cfloat>
#include <string>
#include <vector>
#include <cstdio>
#include <bitset>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#define  lowbit(x)  x & (-x)
#define  mes(a, b)  memset(a, b, sizeof a)
#define  fi         first
#define  se         second
#define  pb         push_back
#define  pii        pair<int, int>
#define  INOPEN     freopen("in.txt", "r", stdin)
#define  OUTOPEN    freopen("out.txt", "w", stdout)

typedef unsigned long long int ull;
typedef long long int ll;
const int    maxn = 2e5 + 10;
const int    maxm = 1e5 + 10;
const ll     mod  = 998244353;
const ll     INF  = 1e18 + 100;
const int    inf  = 0x3f3f3f3f;
const double pi   = acos(-1.0);
const double eps  = 1e-8;
using namespace std;

int n, m;
int cas, tol, T;

int p[maxn];

ll fpow(ll a, ll b) {
	ll ans = 1;
	while(b) {
		if(b&1)	ans = ans*a%mod;
		 a = a*a%mod;
		 b >>= 1;
	}
	return ans;
}

int main() {
	ll M = fpow(100ll, mod-2);
	scanf("%d", &n);
	for(int i=1; i<=n; i++) {
		scanf("%d", &p[i]);
	}
	ll b = 0, c = 0;
	ll tmpb = 1;
	for(int i=1; i<=n; i++) {
		b += tmpb*(100ll-p[i])%mod*M%mod;
		c += tmpb;
		tmpb *= p[i]*M%mod;
		b %= mod, c %=mod, tmpb %= mod;
	}
	b = mod-b+1;
	b = (b%mod+mod)%mod;
	ll ans = c*fpow(b, mod-2)%mod;
	printf("%lld\n", ans);
	return 0;
}