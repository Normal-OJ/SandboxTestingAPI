#include<bits/stdc++.h>
#define ll long long
using namespace std;

const int maxn = 2 * 1e5+5;
const ll mod = 998244353;
ll dp[maxn];

ll power ( ll a, ll b ){
   if ( b == 0 )return 1;
   if ( b == 1 )return a;
   if ( b % 2 )return (power ( a,b-1 )*a)%mod;
   ll T = power ( a,b/2LL );
   return (T*T)%mod;
}

int main(){

    ios_base::sync_with_stdio(0);
    cin.tie(0);

   // freopen ( "a.in", "r", stdin );

    int n;
    cin>>n;

    for ( int i = 1; i <= n; i++ ){
         ll pi; cin>>pi;
        // cout<<power( pi,mod-2 );
         dp[i] = ( ( dp[i-1] + 1 ) * ( (100LL * power ( pi, mod-2 ) )%mod ) )%mod;

    }

    //cout<<n<<'\n';

    cout<<dp[n];


return 0;
}
