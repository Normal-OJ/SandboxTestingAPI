for _ in range(int(input())):
	n = int(input())
	a = input().split()
	l=r=a.index('1')
	for i in range(1,n):
		b=1
		while b==1:
			b=0
			if l>0 and int(a[l-1])<=i:
				l-=1
				b=1
			if r<n-1 and int(a[r+1])<=i:
				r+=1
				b=1
		if (r-l+1)==i:
			print("1",end="")
		else:
			print("0",end="")
	print("1")