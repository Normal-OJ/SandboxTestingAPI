#!/usr/bin/env python
# coding: utf-8

# In[ ]:


t = int(input())
for j in range(t):
    n = int(input())
    A = [int(s) for s in input().split(" ")]
    L = [0]*n
    for i , x  in enumerate(A) :
        num = x
        L[x-1] = i
    
    l=r=L[0]
    m = []
    for k, elm in enumerate(L) :
        if elm < l :
            l = elm
        elif elm > r :
            r = elm
        m.append('1' if r-l == k else '0')
    print(''.join(m))
    
                
            
            
        
   
    
    

