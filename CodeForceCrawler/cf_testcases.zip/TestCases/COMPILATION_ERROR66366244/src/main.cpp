#include "bits/stdc++.h"
#define _ ios_base::sync_with_stdio(false);cout.tie(0);cin.tie(0);
using namespace std;
template<class T> vector<T> iarr(int n) {vector<T> a; while (n--) {T _v; cin >> _v, a.push_back(_v);} return a;}
template<class T> vector<vector<T>> imat(int n, int m) {vector<vector<T>> ma(n, vector<T>(m)); for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) cin >> ma[i][j]; return ma;}
 
bool check(string &s, int i, int j) {
 
    char l = i == 0 ? 'z' : s[i-1];
    char r = i == s.length()-1 || s[i+1] == '?' ? 'z' : s[i+1];
    return char('a'+j) != l && char('a'+j) != r;   
}
 
void solve() {
    string s; cin >> s;
    int n = s.length();
 
    for (int i = 0; i < n; i++) {
        if (s[i] == '?') {
            for (int j = 0; j < 3; j++) {
                if (check(s, i, j)) {
                    s[i] = 'a'+j;
                    break;
                }
            }
        }
    }
    for (int i = 0; i < n; i++) {
        if (s[i] == '?') {
            cout << "-1" << "\n";
            return;
        }
    }
    for (int i = 1; i < n-1; i++) {
        if (s[i] == s[i-1] || s[i] == s[i+1]) {
            cout << "-1" << "\n";
            return;
        }
    }
    cout << s << "\n";
}
 
int main() { _
    int t; cin >> t;
    for (int i = 0; i < t; i++) {
        solve();
    }
    return 0;
}