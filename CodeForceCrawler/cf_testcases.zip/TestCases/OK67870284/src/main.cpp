#include <iostream>
using namespace std;

int main(){
    int t=0, flag=0;
    string s, s_0;

    for (cin >> t; t--; ) {
        s_0.clear();
        cin >> s;
        s = '?' + s + '?';
        for (int i = 1; i < s.length() - 1; i++) {
            if (s[i] == s[i+1] && s[i] != '?') {
                flag = 1;
                break;
            } else if ('?' == s[i]) {
                s[i] = 'a';
                while (s[i] == s[i-1] || s[i] == s[i+1]) {
                    s[i]++;
                }
            }

        }
        for (int j = 1; j < s.length()-1; j++) {
            s_0 += s[j];
        }
        if (0 == flag){
            cout << s_0 << endl;
        } else cout << -1 << endl;
        flag = 0;
    }

    return 0;
}