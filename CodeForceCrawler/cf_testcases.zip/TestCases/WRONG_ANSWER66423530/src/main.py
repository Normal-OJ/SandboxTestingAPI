# nmax = 4 * (10 ** 5) + 1
if __name__ == '__main__':
    n = int(input())
    # arr = [0 for _ in range(nmax)]

    while n > 0:
        q = int(input())
        x = list(map(lambda x: int(x), input().split(' ')))
        if q < 6:
            print(0, 0, 0)
            n -= 1
            continue

        mid = int(q / 2)
        # print(mid)
        if x[mid] == x[mid + 1]:
            while x[mid] == x[mid + 1]:
                mid -= 1
        else:
            mid -= 1
        # print("X", mid)
        if mid < 2:
            print("0 0 0")
        else:
            meds = {
                'g': 1,
                's': 0,
                'b': 0
            }
            prev = x[0]
            cur = 'g'
            # print(x[1/:right + 1])
            # print(x, "->", x[1:mid+1])
            for i in x[1:mid + 1]:
                if cur == 'b':
                    meds['b'] += 1
                else:
                    if i != prev:
                        if cur == 'g':
                            cur = 's'
                        elif meds['g'] < meds['s']:
                            cur = 'b'
                    meds[cur] += 1
            g, s, b = meds['g'], meds['s'], meds['b']
            # print(meds)
            if g < s and g < b:
                print(g, s, b)
            else:
                print("0 0 0")
        n -= 1
