#include <cstdio>
#include<iostream>
#include <map>

#define MAX 100000
int arr[MAX];

int main(void)
{

    std::map<int,int> _num;
    int total = 0;
    for (int i = 0; i < 4; i++)
    {
        scanf("%d", &_num[i]);
        total += _num[i];
    }

    bool ok = true;
    int idx;
    for (int j = 0; j < 4; j++)
    {
        if(!_num[j]) continue;
        int cur = j;
        idx=0;
        ok=true;
        auto num = _num;
        while (true)
        {
            //save
            arr[idx++] = cur;
            num[cur]--;
            if (idx == total){
                ok=true; break;
            }
            //next target
            switch (cur)
            {
            case 0:
                if (!num[++cur])
                    ok = false;
                break;
            case 1:
            case 2:
                if (num[cur - 1])
                {
                    cur--;
                    break;
                }
                if (num[cur + 1])
                {
                    cur++;
                    break;
                }
                
                ok = false;
                break;
            case 3:
                if (!num[--cur])
                    ok = false;
            }
            
            if (!ok)
            {
                break;
            }
        }
        if(ok) break;
    }
    if(!ok){
        printf("NO"); return 0;
    }
    printf("YES\n");
    for (int i = 0; i < idx; i++)
    {
        std::cout << arr[i] << " \n"[i == total -1];
    }
    return 0;
}