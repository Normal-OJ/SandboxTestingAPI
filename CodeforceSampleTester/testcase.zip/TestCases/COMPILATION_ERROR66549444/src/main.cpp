#include<bits/stdc++.h>
using namespace std;
bool com(int x,int y)
{
    return x>y;
}

void change(int num[],int n,vector<int>&num2)
{

    sort(num,num+n,com);
    for(int i=0;i<n;i++)
    {
        while(num[i]==num[i+1])
            i++;
        num2.push_back(num[i]);
    }
}


int main()
{
      int a,b,c,d;
      cin>>a>>b>>c>>d;
      int arr[a+b+c+d];
      int n=a+b+c+d;
      bool ok=true;
        if(a>b)
            ok=false;
        int f=0,s=1;
        int x=(a+c-b-1),y=x+1;
        cout<<x<<y<<d;
        if(d==x||d==y)
            cout<<"ok"<<n;
        else if((d==y||d==y+1)&&(a<b||a==0))
        {
            swap(f,s);
            swap(a,b);
            swap(c,d);
        }
        else
            ok=false;
       
        if(ok)
        {
            for(int i=0;i<n;i+=2)
                if(a)
                {
                arr[i]=f;
                a--;
                }
                else
                    arr[i]=f+2;
            for(int i=1;i<n;i+=2)
                if(b)
            {
                arr[i]=b;
                b--;
            }
            else
                arr[i]=b+2;
            cout<<yes<<endl;
            for(int i=0;i<n;i++)
                cout<<arr[i]<<" ";
            cout<<endl;
        }
        else 
            cout<<"NO"<<endl;
}



