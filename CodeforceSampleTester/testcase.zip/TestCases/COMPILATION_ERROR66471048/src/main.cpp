using namespace std;
#include<bits/stdc++.h>
#define ll long long int
ll t,n;
ll p[400001];
ll pd[400001];
int main()
{
    cin>>t;
    while(t--)
    {
        cin>>n;
        for(ll i=1;i<=n;i++)
        cin>>p[i];
        memset(pd,0,sizeof(pd));
        pd[n]=1;
        for(ll i=n-1;i>0;i--)
        {
        	if(p[i]==p[i+1])
        	{
        		pd[i]=pd[i+1]+1;
			}
			else
			{
				pd[i]=1;
			}
		}
        if(n<10)
        cout<<0<<" "<<0<<" "<<0<<endl;
        else
        {
            ll g=1,s=0,b=0;
            ll index = n;
            for(ll i=2;i<=n;i++)
            {
                if(p[i]!=p[1])
                break;
                else
                g++;
            }
            for(ll i=n-1;i>0;i--)
            {
                if(p[i]!=p[n])
                break;
                else
                index--;
            }
            ll re = index-g-1;
            if(re<2*(g+1))
            cout<<0<<" "<<0<<" "<<0<<endl;
            else
            {
                s=g+1;
                ll i;
                for(i=2*g+2;i<index;i++)
                {
                    if(p[i]==p[2*g+1])
                    s++;
                    else
                    break;
                }
                if(index-i<g+1)
                {
                    cout<<0<<" "<<0<<" "<<0<<endl;
                }
                else
                {
                b=g+1;
                i=i+b;
                ll j=i-1;
                for(i;i<=n;i++)
                {
                	if(p[i]==p[j])
                	b++;
                	else
                	break;
				}
				if(g+s+b>n/2)
				{
				    cout<<0<<" "<<0<<" "<<0<<endl;
				}
                else if(g<b && g<s && b>0 && s>0 && (g+s+b)<n/2)
                {
                	for(i;i<index;i++)
                	{
                		if(b+pd[i]+g+s<=n/2)
                		b++;
						else
						break;
				    }   
                	cout<<g<<" "<<s<<" "<<b<<endl;
				}
				else if(g<b && g<s && b>0 && s>0 && (g+s+b)==n/2)
                cout<<g<<" "<<s<<" "<<b<<endl;        
            }
        }
    }
}