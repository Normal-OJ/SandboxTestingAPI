for _ in range(int(input())):
    n = int(input())
    a = list(map(int, input().split()))
    r = [0] * n

    for i, x in enumerate(a):
        r[x - 1] = i

    i_min = i_max = r[0]
    ans = []

    for m, i in enumerate(r):
        i_min = min(i, i_min)
        i_max = max(i, i_max)

        ans.append(1 if i_max - i_min == m else 0)

    print(*ans, sep='')
