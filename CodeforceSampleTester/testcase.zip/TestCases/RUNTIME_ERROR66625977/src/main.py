def glub(a):
    n=len(a)
    kol=0
    ik=0
    gl=0
    for i in range(n):
        if a[i]=='(':
            dl=i-ik-1
            glt = min(dl, kol)
            gl=max(gl, glt)
            kol+=1
            ik=i
    dl=n-ik-1
    glt = min(dl, kol)
    gl=max(gl, glt)
    return gl


def rec(idx):
    global rz
    if idx==n :
        for j in range(len(spi)):
            sk[spi[j]]=a[j]
        rz+=glub(sk)
        return
    for i in range(1, 3):
        if i==1:
            a[idx]='('
        else:
            a[idx]=')'
        rec(idx+1)

b=str(input())
spi=[]
n=0
sk=[]
for i in range(len(b)):
    if b[i]=='?':
        n+=1
        spi+=[i]
        sk+=b[i]
    else:
        sk+=b[i]

rz=0
rec(0)
print(rz%998244353)

