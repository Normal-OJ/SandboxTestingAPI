T = int(input(''))
for _ in range(T):
    n = int(input(''))
    p = list(map(int,input('').split(' ')))
    l = [0]*(n+1)
    for i in range(n):
        l[p[i]] = i
    mn = l[1]
    mx = l[1]
    for i in range(1,n+1,1):
        if(mx-mn+1 == i):
            print('1',end = '')
        else:
            print('0',end = '')
        if(i<n):
            if(l[i+1] < mn):
                mn = l[i+1]
            if(l[i+1] > mx):
                mx = l[i+1]
    print('')