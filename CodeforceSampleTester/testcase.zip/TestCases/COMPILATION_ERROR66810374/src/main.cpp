            #include <unordered_map>
            #include <set>
            #include <utility>
            #include <string>
            #include <iostream>
            #include <vector>
             using namespace std;
            void printBeatifulNumStr(std::vector<int>& perm) {
                std::vector<int> idxmap;
                int n = perm.size();
                idxmap.resize(n);
            //    std::unordered_set<int, std::pair<int, std::pair<int, int>> > idxmap;
                for (int i = 0 ; i < n; ++i) {
                    idxmap[perm[i] - 1] = i;
                }
                std::vector<std::pair<int, int>> lbpair;
                lbpair.resize(n);
                int minidx = n + 1;
                int maxidx = -1;
                for (int i = 0; i < n; ++i) {
                    if (idxmap[i] < minidx) {
                        minidx = idxmap[i];
                    }
                    if (idxmap[i] > maxidx) {
                        maxidx = idxmap[i];
                    }
                    lbpair[i] = std::make_pair(minidx, maxidx);
                }
                
                std::string sol;
                sol.resize(n);
                std::set<int> idxset;
                for (int i = n - 1; i > 0; --i) {
                    idxset.insert(idxmap[i]);
                    auto lb = lbpair[i - 1];
                    if ((lb.second - lb.first) != i ) {
                        sol[i - 1] = '0';
                        continue;
                    }
                    auto lit = idxset.lower_bound(lb.second);
                    auto uit = idxset.upper_bound(lb.first);
                    if (((lit != idxset.end()) && (*lit > lb.first)) || ((uit != idxset.end()) && (*uit < lb.second)) {
                        sol[i - 1] = '0';
                    } else {
                        sol[i - 1] = '1';
                    }
                }
                sol[0] = '1';
                sol[n - 1] = '1';
                std::cout << sol << std::endl;
            }
            
            
            int main() {
                int t;
                cin >> t;
                while(t--) {
                    int n;
                    cin >> n;
                    vector<int> nums;
                    while(n--) {
                        int val;
                        cin >> val;
                        nums.push_back(val);
                    }
                    printBeautifulNumStr(val);
                }
            }