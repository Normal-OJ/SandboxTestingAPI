#include<bits/stdc++.h>
using namespace std;
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("input.txt" ,"r", stdin);
    freopen("output.txt" ,"w", stdout);
    #endif
    
    int n;
    cin>>n;
   
    
    while(n--)
    {
        string s;
        cin>>s;
        int ok=0; 
        for(int i=0; i<s.length(); i++)
        {
            if(s[i]=='?')
            {
                if(i==0)
                {
                    if('a'!=s[i+1])
                    {
                        s[i]='a';
                    }
                    else if('b'!=s[i+1])
                    {
                        s[i]='b';
                    }
                    else if('c'!=s[i+1])
                    {
                        s[i]='c';
                    }
                }
                else
                {
                    if('a'!=s[i+1] && 'a'!=s[i-1])
                    {
                        s[i]='a';
                    }
                    else if('b'!=s[i+1] && 'b'!=s[i-1])
                    {
                        s[i]='b';
                    }
                    else if('c'!=s[i+1] && 'c'!=s[i-1])
                    {
                        s[i]='c';
                    }
                }
            }
        }
        
        for(int i=0; i<s.length()-1; i++)
        {
            if(s[i]==s[i+1])
            {
                cout<<-1<<"\n";
                ok=1;
                break;
            }
        }
        if(ok==0)
        {
            cout<<s<<"\n";
        }
    }
return 0;
}