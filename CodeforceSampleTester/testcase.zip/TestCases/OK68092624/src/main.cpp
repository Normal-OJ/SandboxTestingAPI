#pragma GCC optimize(2)
#include<bits/stdc++.h>
using namespace std;
inline int read() {int x=0,f=1;char c=getchar();while(c!='-'&&(c<'0'||c>'9'))c=getchar();if(c=='-')f=-1,c=getchar();while(c>='0'&&c<='9')x=x*10+c-'0',c=getchar();return f*x;}
typedef unsigned long long ll;
const int maxn = 1e6+10;
int a[maxn];
int main()
{
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        int k;
        for(int i=1;i<=n;i++){
            cin>>k;
            a[k]=i;
        }
        int l,r;
        l=r=a[1];
        cout<<1;
        for(int i=2;i<=n;i++){
            l=min(l,a[i]);
            r=max(r,a[i]);
            if(r-l+1==i){
                cout<<1;
            }
            else{
                cout<<0;
            }
        }
        cout<<endl;
    }
    return 0;
}
