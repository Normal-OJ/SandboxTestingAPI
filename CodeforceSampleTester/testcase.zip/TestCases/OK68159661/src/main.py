a, b, c, d = [int(x) for x in input().split()]
res = [0 for _ in range(a)]
res+= [2 for _ in range(c)]
 
if a+c<b+d:
    ind=0
else:
    ind=1
while (b>0):
    res.insert(ind, 1)
    ind+=2
    b-=1
while (d>0):
    res.insert(ind, 3)
    ind+=2
    d-=1
tr = True
for i in range(1, len(res)):
    if abs(res[i-1]-res[i])!=1:
        print ('NO')
        tr = False
        break
if tr:
    print ('YES')
    print (*res)