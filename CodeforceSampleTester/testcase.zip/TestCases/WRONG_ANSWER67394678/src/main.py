D = list(map(int, input().split()))
if 0 < D[0] <= D[1] and D[2] >= D[3] > 0 and 0 <= D[1] + D[3] - D[0] - D[2] <= 1:
    print('YES')
    if D[0] < D[1]:
        print('1', end = ' ')
    print(' '.join(['0', '1'] * D[0]), end = ' ')
    if D[1] + D[3] - D[0] - D[2] == 1 and D[2] != D[3]:
        print('2 1', end = ' ')
    print(' '.join(['2', '3'] * D[3]), end = ' ')
    if D[0] + D[2] - D[1] - D[3] >= 0:
        print('2')
elif D[0] == 0 and D[2] <= D[1] + D[3]:
    print('YES')
    if D[1] + D[3] > D[2]:
        print('1', end = ' ')
    print(' '.join(['2', '1'] * (D[2]-D[3])), ' '.join(['2', '3'] * D[3]))
elif D[3] == 0 and D[1] <= D[0] + D[2]:
    print('YES')
    if D[0] + D[2] > D[1]:
        print('0', end = ' ')
    print(' '.join(['1', '0'] * (D[1]-D[2])), ' '.join(['1', '2'] * D[2]))
else:
    print('NO')