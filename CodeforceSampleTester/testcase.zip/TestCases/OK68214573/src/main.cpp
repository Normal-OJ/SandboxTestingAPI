#include <bits/stdc++.h>
#define all(x) (x).begin(), (x).end()
#define For(i,n) for (int i=0;i<n;i++)
#define fst first
#define scd second
#define pb push_back
using namespace std;
using ll=long long int;
using vll=vector<ll>;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    //cout<<setprecision(15)<<fixed;
    //ifstream cin(""); ofstream cout("");
    int t; cin >> t;
    for (int k = 0; k < t; k++)
    {
        int n; cin >> n;
        vll in(n);
        for (int i = 0; i < n; i++)
            cin >> in[i];
        vll positions(n + 1);
        for (int i = 0; i < n; i++)
        {
            positions[in[i]] = i;
        }
        ll max_pos = positions[1], min_pos = positions[1];
        for (int i = 1; i < n + 1; i++)
        {
            if (max_pos < positions[i]) max_pos = positions[i];
            if (min_pos > positions[i]) min_pos = positions[i];
            if (max_pos - min_pos + 1 == i) cout<<1;
            else cout << 0;
        }
        cout<<endl;
    }
}