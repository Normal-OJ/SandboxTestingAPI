import random

def beautify_string():
    string = input()

    if 'aa' in string or 'bb' in string or 'cc' in string:
        return -1

    letters = [x for x in string]

    for i in range(len(letters)):
        if letters[i] == '?':
            poss_letters = ['a', 'b', 'c']

            if not i == 0:
                if letters[i-1] in poss_letters:
                    poss_letters.remove(letters[i-1])

            if not i == len(letters) - 1:
                if letters[i+1] in poss_letters:
                    poss_letters.remove(letters[i+1])

            letters[i] = random.choice(poss_letters)

    return ''.join(letters)

for i in range(int(input())):
    print(beautify_string())