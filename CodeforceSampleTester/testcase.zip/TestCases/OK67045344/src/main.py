from sys import stdin
from collections import deque
mod = 10**9 + 7
# def rl():
#     return [int(w) for w in stdin.readline().split()]
from bisect import bisect_right
from bisect import bisect_left
from collections import defaultdict
from math import sqrt,factorial,gcd,log2,inf,ceil
# map(int,input().split())
# # l = list(map(int,input().split()))
# from itertools import permutations

# a = int(input())
# b = int(input())
# c = int(input())
# d = int(input())
# e = int(input())
# f = int(input())
# ans = 0
#
# for i in range(d+1):
#     c = e*(min(i,a)) + f*(min(d-i,c,b))
#     ans = max(c,ans)
#     print(c,i,a)
#
# print(ans)
# ans1 = 0
# ans2 = 0
# def bfs(n):
#     global ans1
#     boo1[n] = True
#     queue = [n]
#
#     while queue:
#
#         z = queue.pop(0)
#         if len(hash[z]) == 0:
#             ans1+=1
#         for i in hash[z]:
#
#             if not boo1[i]:
#                 queue.append(i)
#                 boo1[i] = True
#
# def bfs1(n):
#     global ans2
#     boo2[n] = True
#     queue = [n]
#
#     while queue:
#
#         z = queue.pop(0)
#         if len(hash1[z]) == 0:
#             ans2+=1
#         for i in hash1[z]:
#
#             if not boo2[i]:
#                 queue.append(i)
#                 boo2[i] = True
#
#
#
#
#
#
#
#
#
# hash = defaultdict(list)
# hash1 = defaultdict(list)
# n,m = map(int,input().split())
#
# for i in range(m):
#     a,b = map(int,input().split())
#     hash[a].append(b)
#     hash1[b].append(a)
#
#
#
# boo1 = defaultdict(bool)
# boo2 = defaultdict(bool)
#
# for i in range(1,n+1):
#     if boo1[i] == False:
#         bfs(i)
#     if boo2[i] == False:
#         bfs1(i)
#
#
# print(max(ans1,ans2))
#
#
#
#

a,b,c,d = map(int,input().split())
n = a+b+c+d
g = [a,b,c,d]
g.sort()
if g[0] == 0 and g[1] == 0 and g[2] == 0 and g[3]!=1:
    print('NO')
    exit()
if n == 1:
    print('YES')
    print(*[0*a+1*b+2*c+3*d])
    exit()
ans = []
if a == 0 and b == 0 and abs(c-d) == 1:
    if c>=d:
        for i in range(n):
            if i%2 == 0:
                ans.append(2)
            else:
                ans.append(3)
    else:
        for i in range(n):
            if i%2 == 0:
                ans.append(3)
            else:
                ans.append(2)
    print('YES')
    print(*ans)
    exit()

if c == 0 and d == 0 and abs(a-b) == 1:
    if a>=b:
        for i in range(n):
            if i%2 == 0:
                ans.append(0)
            else:
                ans.append(1)
    else:
        for i in range(n):
            if i%2 == 0:
                ans.append(1)
            else:
                ans.append(0)
    print('YES')
    print(*ans)
    exit()




if a>=0:

    if a == b:
        ans = []
        for i in range(2*a):
            if i%2 == 0:
                ans.append(0)
            else:
                ans.append(1)
        b-=a
        cnt = 0

        while True:
            if c == 0 or d == 0:
                break
            if cnt%2 == 0:
                ans.append(2)
                c-=1
            else:
                ans.append(3)
                d-=1

            cnt+=1

        if ans[-1] == 3 :
            if c == 1:
             c-=1
             ans.append(2)
        if ans[-1] == 2 :
            if d == 1:
             ans.append(3)
             d-=1

        if ans[-1] == 1 and c!=0:
            c-=1
            ans.append(2)

        if c == 0 and d == 0:
            print('YES')
            print(*ans)

        else:
            print('NO')


    elif b>a:

        ans = [1]
        b-=1
        for i in range(2*a):
            if i%2 == 0:
                ans.append(0)
            else:
                ans.append(1)


        b-=a
        cnt = 0

        while True:
            if b == 0 or c == 0:
                break
            if cnt%2 == 0:
                    ans.append(2)
                    c-=1
            if cnt%2!=0:
                    ans.append(1)
                    b-=1
            cnt+=1

        if ans[-1] == 1 and c == 0 and b == 0:
            if d!=0 :
                print('NO')
                exit()
            print('YES')
            print(*ans)

        elif ans[-1] == 1 and b == 0:
            cnt = 0

            while True:
             if c == 0 or d == 0:
                break
             if cnt%2 == 0:
                ans.append(2)
                c-=1
             else:
                ans.append(3)
                d-=1
             cnt+=1

            if c == 0 and d == 0 :
                 print('YES')
                 print(*ans)
            elif c == 1 and d == 0 :
                 print('YES')
                 print(*([2] + ans))
            elif  c == 2 and d == 0 :
                print('YES')
                print(*([2] + ans + [2]))


            elif c == 0 and d == 1 :
                print('YES')
                print(*(ans + [3]))
            else:
                print('NO')

        elif ans[-1] == 2 and b == 1 and d!=0:
            print('NO')

        elif ans[-1] == 2 and b == 1 and d == 0:
            print('YES')
            print(*(ans + [1]))

        elif ans[-1] == 2 and b == 0:
            cnt = 0

            while True:
                if c == 0 or d == 0:
                    break
                if cnt%2 != 0:
                    ans.append(2)
                    c-=1
                else:
                    ans.append(3)
                    d-=1
                cnt+=1

            if c == 0 and d == 0:
                    print('YES')
                    print(*ans)
            elif c == 1 and d == 0:
                    print('YES')
                    print(*([2] + ans))

            elif c == 0 and d == 1:
                print('YES')
                print(*(ans + [3]))
            elif  c == 2 and d == 0:
                print('YES')
                print(*([2] + ans + [2]))
            else:
                print('NO')
        else:
            print('NO')
    else:

        if b == 1 and a == 2 and c == 0 and d == 0:
            print('YES')
            print(*[0,1,0])
        else:
            print('NO')


