#include<iostream>
#include<cstdio>
using namespace std;
int p[200010];
int wz[200010];
bool book[200010] = { 0 };
char a[200010];
int ks, js;
bool ok() {
	for (int i = ks; i <= js; i++) {
		if (book[i] == 0) {
			return 0;
		}
	}
	return 1;
}
int main() {
	int T;
	cin >> T;
	while (T--) {
		memset(a, '0', sizeof(a));
		memset(book, 0, sizeof(book));
		int n;
		cin >> n;
		a[n] = '\0';
		for (int i = 1; i <= n; i++) {
			scanf_s("%d", &p[i]);
			wz[p[i]] = i;
		}
		for (int c = 1; c <= n; c++) {
			if (c == 1) {
				book[wz[c]] = 1;
				ks = wz[c];
				js = wz[c];
				if (ok()) {
					a[js - ks] = '1';
				}
			}
			else {
				book[wz[c]] = 1;
				if (wz[c] > js) {
					js = wz[c];
				}
				if (wz[c] < ks) {
					ks = wz[c];
				}
				if (ok()) {
					a[js - ks] = '1';
				}
			}
		}
		cout << a << endl;
	}
	return 0;
}