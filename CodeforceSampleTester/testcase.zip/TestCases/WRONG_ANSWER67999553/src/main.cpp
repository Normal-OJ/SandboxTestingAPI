#include <bits/stdc++.h>

#pragma GCC optimize "-O3"

#define endl "\n"
#define trace(x) cerr << #x << " = " << x << endl

using namespace std;

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	int testCasesCount;
	cin >> testCasesCount;

	while (testCasesCount--) {
		int n;
		cin >> n;
		map<int, int> p;
		for (int i = 0; i < n; i++) {
			int v;
			cin >> v;

			p[v]++;
		}

		if ((int)p.size() <= 2) {
			cout << "0 0 0\n";
			continue;
		}

		vector<int> medals = {p.rbegin()->second, 0, 0};
		int ptr = 1;
		for (auto it = next(p.rbegin()); it != p.rend() && ptr < 3; it++) {
			medals[ptr] += it->second;
			if (medals[ptr] > medals[0]) {
				ptr++;
			}
		}

		if (medals[1] > medals[0] && medals[2] > medals[0] && (medals[0] + medals[1] + medals[2]) <= (n >> 1)) {
			cout << medals[0] << ' ' << medals[1] << ' ' << medals[2] << endl;
		} else {
			cout << "0 0 0\n";
		}
	}

	return EXIT_SUCCESS;
}