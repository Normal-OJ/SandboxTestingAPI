#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;cin>>n;
	string s;
	for(int i=0;i<n;i++){
		cin>>s;
		for(int j=0;j<s.size();j++){
			if(s[j]=='?' && s[j+1]=='?' && j!=s.size()-1){
				s[j]=char(s[j-1]+1);
				if(s[j]=='d')s[j]='a';
			}
			else if(s[j]=='?' && j!=s.size()-1){
				s[j]=char(s[j-1]+1);
				if(s[j]=='d')s[j]='a';
				if(s[j]==s[j+1])s[j]++;
				if(s[j]=='d')s[j]='a';
			}
			else if(s[j]=='?'){
				s[j]=char(s[j-1]+1);
				if(s[j]=='d')s[j]='a';
			}
			else if(s[j]==s[j-1] && j>0){
				cout<<"-1";
				break;
			}
			if(j==s.size()-1)cout<<s;
		}
	}
}