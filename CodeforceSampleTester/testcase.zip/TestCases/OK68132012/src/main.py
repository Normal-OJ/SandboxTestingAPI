for i in range(int(input())):
    s=input()
    p=''
    c=0
    for j in range(len(s)):
        k=['a','b','c']
        if s[j]=='?':
            if len(p)>0 and p[j-1] in k:k.remove(p[j-1])
            if j<len(s)-1 and s[j+1] in k:k.remove(s[j+1])
            p+=k[0]
        else:
            if j<len(s)-1:
                if s[j]==s[j+1]:c+=1;break
                else:p+=s[j]
            else:p+=s[j]
    
    if c==0:print(p)
    else:print('-1')

