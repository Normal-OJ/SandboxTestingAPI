#include <bits/stdc++.h>

using namespace std;

typedef long long LL;

int main(void) {
  ios_base::sync_with_stdio(false);
  cin.tie(nullptr);

  int T = 1;
  cin >> T;
  for (int n; T-- > 0 && cin >> n; ) {
    vector<int> a(n);
    for (int i = 0; i < n; ++i) {
      cin >> a[i];
    }
    string b(n, '0');
    for (int i = 0, j = n, x = n; i < j; ) {
      --x;
      b[x] = '1';
      while (j - i > x) {
        if (a[i] > a[j - 1]) {
          x = min(x, a[i++] - 1);
        } else {
          x = min(x, a[--j] - 1);
        }
      }
      // cout << "=> " << i << ' ' << j << ' ' << x << '\n';
    }
    cout << b << '\n';
  }

  return 0;
}
