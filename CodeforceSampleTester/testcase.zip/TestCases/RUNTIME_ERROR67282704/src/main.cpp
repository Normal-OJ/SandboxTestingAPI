#include <cstdio>
#include <algorithm>
#include <iostream>
#include <map>
#include <string>
#include <cstring>
#include <queue>
#include <stack>
#include <cmath>
#define int long long
#define Mod 1000000007
#define pi (acos(-1))
#define INF 0x3f3f3f3f3f
#define Maxn 100005
using namespace std;

int a[Maxn];

int istrue(int n){
	int flag=1;
	for(int i = 2 ; i <= n && flag; i ++ ){
		if(a[i]-a[i-1]!=1&&a[i-1]-a[i]!=1)
		flag=0;
	}
//	printf("*****\n");
	return flag;
}


signed main(){
	int n;
	int x,b,c,d;
	scanf("%lld%lld%lld%lld",&x,&b,&c,&d);
	n=x+b+c+d;
//	printf("%lld",n);
	for(int i = 0 ; i < Maxn ; i ++ )
	a[i]=10;
		
		int l1=0,l2=0,l3=0;
		int MM=0,MMa=0;
		for(int i = 1 , k = 1 ; k <= x ; i += 2 , k ++ ){
			a[i]=0;
			l1=i;
		}
		for(int i = 2 , k = 1 ; k <= b ; i += 2 , k ++ ){
			a[i]=1;
			l2=i;
		}
		MM=min(l1,l2);
		l3=MM;
		MMa=max(l1,l2);
		if(a[MM+1]==10)
		for(int i = MM+1 , k = 1 ; k <= c ; i += 2 , k ++ ){
			a[i]=2;
			l3=i;
		}
		else if(a[MM+2]==10)
		for(int i = MM+2 , k = 1 ; k <= c ; i += 2 , k ++ ){
			a[i]=2;
			l3=i;
		}
		else if(a[MM+3]==10)
		for(int i = MM+2 , k = 1 ; k <= c ; i += 2 , k ++ ){
			a[i]=2;
			l3=i;
		}
		
		MM=min(l3,MMa);
		if(a[MM+1]==10)
		for(int i = MM+1 , k = 1 ; k <= d ; i += 2 , k ++ ) a[i]=3;
		else if(a[MM+2]==10)
		for(int i = MM+2 , k = 1 ; k <= d ; i += 2 , k ++ ) a[i]=3;
		else if(a[MM+3]==10)
		for(int i = MM+2 , k = 1 ; k <= d ; i += 2 , k ++ ) a[i]=3;
//		printf("%lld\n",istrue(x+b+c+d));
		
		if(istrue(x+b+c+d)) {
			
			printf("YES\n");
			for(int i = 1 ; i <= n ; i ++ )
			printf("%lld%c",a[i],i==n?'\n':' ');
			return 0;
		}
		
		for(int i = 2 , k = 1 ; k <= x ; i += 2 , k ++ ){
			a[i]=0;
			l1=i;
		}
		for(int i = 1 , k = 1 ; k <= b ; i += 2 , k ++ ){
			a[i]=1;
			l2=i;
		}
		MM=min(l1,l2);
		l3=MM;
		MMa=max(l1,l2);
		if(a[MM+1]==10)
		for(int i = MM+1 , k = 1 ; k <= c ; i += 2 , k ++ ){
			a[i]=2;
			l3=i;
		}
		else if(a[MM+2]==10)
		for(int i = MM+2 , k = 1 ; k <= c ; i += 2 , k ++ ){
			a[i]=2;
			l3=i;
		}
		else if(a[MM+3]==10)
		for(int i = MM+2 , k = 1 ; k <= c ; i += 2 , k ++ ){
			a[i]=2;
			l3=i;
		}
		
		MM=min(l3,MMa);
		if(a[MM+1]==10)
		for(int i = MM+1 , k = 1 ; k <= d ; i += 2 , k ++ ) a[i]=3;
		else if(a[MM+2]==10)
		for(int i = MM+2 , k = 1 ; k <= d ; i += 2 , k ++ ) a[i]=3;
		else if(a[MM+3]==10)
		for(int i = MM+2 , k = 1 ; k <= d ; i += 2 , k ++ ) a[i]=3;
//		printf("%lld\n",istrue(x+b+c+d));
		
		if(istrue(x+b+c+d)) {
			printf("YES\n");
			for(int i = 1 ; i <= n ; i ++ )
			printf("%lld%c",a[i],i==n?'\n':' ');
			return 0;
		
	}printf("NO");
	return 0;
}

				 	     		 			 	     		   	