#include <cstdio>
#include <iostream>
using namespace std;
char st[1005][1005];
int main(){
	int t;
	cin>>t;
	for(int i=1;i<=t;i++){
		for(int h=1;h<=t;h++){
			cin>>st[i][h];
		}
	}
	for(int i=1;i<=t;i++){
		for(int h=1;h<=t;h++){
			if(h==1&&st[i][h]=='?'){
				if(st[i][h+1]=='a'){
					st[i][h]='b';
				}else if(st[i][h+1]=='b'){
					st[i][h]='c';
				}else if(st[i][h+1]=='c'){
					st[i][h]='a';
				}else if(st[i][h+1]=='?'){
					st[i][h]='a';
				}
			}else if(h==t&&st[i][h]=='?'){
				if(st[i][h-1]=='a'){
					st[i][h]='b';
				}else if(st[i][h-1]=='b'){
					st[i][h]='c';
				}else if(st[i][h-1]=='c'){
					st[i][h]='a';
				}
			}else{
				if(st[i][h]=='?'){
					if(st[i][h-1]==st[i][h+1]&&st[i][h+1]!='?'){
						if(st[i][h+1]=='a'){
							st[i][h]='b';
						}else if(st[i][h+1]=='b'){
							st[i][h]='c';
						}else if(st[i][h+1]=='c'){
							st[i][h]='a';
						}
					}else if(st[i][h+1]=='?'){
						if(st[i][h-1]=='a'){
							st[i][h]='b';
						}else if(st[i][h-1]=='b'){
							st[i][h]='c';
						}else if(st[i][h-1]=='c'){
							st[i][h]='a';
						}
					}
					else if(st[i][h-1]!=st[i][h+1]){
						st[i][h]='a'+'b'+'c'-st[i][h-1]-st[i][h+1];
					}
				}
			}
		}
	}
	for(int i=1;i<=t;i++){
		for(int h=1;h<=t;h++){
			printf("%c",st[i][h]);
		}
		printf("\n");
	}
	return 0;
}
		 			  				 						   	 		  	 	