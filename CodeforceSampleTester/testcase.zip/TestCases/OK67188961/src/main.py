a,b,c,d = map(int,input().split())
n = a+b+c+d
if(n==1 and a==1):
    print("YES")
    print(0)
elif(n==2 and b==2):
    print("NO")

elif (a == 0 and b==0):
    if(c==0):
        if(d==1):
            print("YES")
            print(3)
        else:
            print("NO")
    elif(d==c-1 or d==c or d ==c+1):
        print("YES")
        if(d==c+1):
            print(3,end=" ")
            n = n-1
        for i in range(n):
            if(i%2==0):
                print(2,end=" ")
            else:
                print(3,end=" ")
    else:
        print("NO")
    
elif(d>c):
    print("NO")
elif(d==0 and c==0):
    if(b<a-1 or b >a+1):
        print("NO")
    else:
        print("YES")
        if(b==a+1):
            print(1,end=" ")
            n= n-1
        for i in range(n):
            if(i%2==0):
                print(0,end=" ")
            else:
                print(1,end=" ")


else:
    nee = a + max(0,c-d-1)
    if(b<nee or b>nee+2):
        print("NO")
    elif(b<a):
        print("NO")
    else:
        
        print("YES")
        if(nee+2==b or b== nee+1):
            print(1,end=" ")
            b=b-1
            for i in range(n-1):
                if(i%2==0 and a!=0):
                    print(0,end=" ")
                    a-=1
                elif(i%2==0 and c!=0):
                    print(2,end=" ")
                    c-=1
                elif(b!=0):
                    print(1,end=" ")
                    b-=1
                else:
                    print(3,end=" ")
        else:
            for i in range(n):
                if(i%2==0 and a!=0):
                    print(0,end=" ")
                    a-=1
                elif(i%2==0 and c!=0):
                    print(2,end=" ")
                    c-=1
                elif(b!=0):
                    print(1,end=" ")
                    b-=1
                else:
                    print(3,end=" ")
        