#include <cstdio>
const int MAXN=220000;
const int P=998244353;
const int INV100=828542813;
void exgcd(int a, int b, int& x, int& y)
{
	if (b==0) x=1, y=0;
	else exgcd(b, a%b, y, x), y-=a/b*x;
}
inline int inv(int a)
{
	int x, y;
	exgcd(a, P, x, y);
	return (x%P+P)%P;
}
int p[MAXN];
int main()
{
//	freopen("CF1265E.in", "r", stdin);
//	freopen("CF1265E.out", "w", stdout);
	int n;
	scanf("%d", &n);
	for (int i=1; i<=n; i++)
	{
		scanf("%d", &p[i]);
		p[i]=1ll*p[i]*INV100%P;
	}
	int ans=0, s=1;
	for (int i=1; i<=n; i++)
	{
		ans=(ans+s)%P;
		s=1ll*s*p[i]%P;
	}
	ans=1ll*ans*inv(s)%P;
	printf("%d\n", ans);
	return 0;
}