#include <bits/stdc++.h>

using namespace std;

#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define FORd(i,a,b) for(int i=a;i>=b;i--)
#define ll long long
#define fi first
#define se second

const int maxn=2e5+10;
const ll maxN=1e18+10;

int n,a[maxn],L[maxn],R[maxn];

set <int> s;

void xuli() {
	deque <int> d;
	FOR(i,1,n) {
		while (!d.empty()&&a[d.back()]<=a[i]) d.pop_back();
		d.empty() ? L[i]=1: L[i]=d.back()+1;
		d.push_back(i);
	}
	d.clear();
	FORd(i,n,1) {
		while (!d.empty()&&a[d.front()]<=a[i]) d.pop_front();
		d.empty() ? R[i]=n : R[i]=d.front()-1;
		d.push_front(i);
	}
	FOR(i,1,n) s.insert(R[i]-L[i]+1);
}

void Print() {
	FOR(i,1,n)
	  if (s.find(i)!=s.end()) cout << 1;
	  else cout << 0;
	 cout << endl;
	FOR(i,1,n) cout << L[i] << " ";
	cout << endl;
	FOR(i,1,n) cout << R[i] << " ";
	 s.clear();
}

int main()
{
  ios_base::sync_with_stdio(0);
  cin.tie(NULL);
  cout.tie(NULL);
  int t;
  cin >> t;
  FOR(h,1,t) {
  	cin >> n;
  	FOR(i,1,n) cin >> a[i];
  	xuli();
  	Print();
  }
}