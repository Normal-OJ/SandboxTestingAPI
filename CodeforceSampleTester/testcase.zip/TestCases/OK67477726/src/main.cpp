#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
const int maxn=200000+10;
const int MOD=998244353;
int p[maxn];
inline int inv(int x){
    int r=1,t=x,k=MOD-2;
    while(k){
        if(k&1) 
			r=1ll*r*t%MOD;
		t=1ll*t*t%MOD;
        k>>=1;
    }
    return r;
}
int main(){
	//freopen("a.in","r",stdin);
	//freopen("a.out","w",stdout);
    int n;
	scanf("%d",&n);
    for(int i=1;i<=n;i++){
		scanf("%d",&p[i]);
		p[i]=1ll*p[i]*inv(100)%MOD;
	}
    int a=1,b=0;
    for(int i=n;i>=1;i--){
        a=1ll*a*inv(p[i])%MOD;
		b=(b+a)%MOD;
    }
    printf("%d\n",b);
return 0;
}