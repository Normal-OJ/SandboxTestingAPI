#include <bits/stdc++.h>
#include <unordered_set>
#include <unordered_map>
#define _for(i, a, b) for(int i = a; i < b; ++i)
#define _rep(i, a, b) for(int i = a; i <= b; ++i)
#define closeIO ios::sync_with_stdio(false); cin.tie(0); cout.tie(0)
#define debug cout << "******************" << endl
#define FREE freopen("in.txt", "r", stdin)
#define FREO freopen("out.txt", "w", stdout)
#define ls l, m, rt << 1
#define rs m + 1, r, rt << 1 | 1
using namespace std;
typedef long long LL;
typedef unsigned long long ULL;
typedef pair<int, int> pii;
typedef long double LD;
const int MAXN = 2e3 + 10;
const int MOD = 998244353;
const double eps = 1e-6;
LL QuickPow(LL a, LL n) {
    LL ans = 1;
    while (n) {
        if (n&1) ans = ans*a%MOD;
        a = a*a%MOD;
        n >>= 1;
    }
    return ans;
}
char s[MAXN];
LL dp[MAXN][MAXN], sum[MAXN];
int main() {
    scanf("%s", s + 1);
    int n = strlen(s + 1);
    memset(sum, 0, sizeof(sum));
    memset(dp, 0, sizeof(dp));
    for (int i = 1; i <= n; ++i) sum[i] = sum[i - 1] + (s[i] == '?');
    for (int len = 2; len <= n; ++len) {
        for (int l = 1, r = l + len - 1; r <= n; ++l, ++r) {
            if (s[l] != '(') dp[l][r] = (dp[l][r] + dp[l + 1][r])%MOD;
            if (s[r] != ')') dp[l][r] = (dp[l][r] + dp[l][r - 1])%MOD;
            if (s[l] != '(' && s[r] != ')') dp[l][r] = (dp[l][r] - dp[l + 1][r - 1] + MOD)%MOD;
            if (s[l] != ')' && s[r] != '(') dp[l][r] = (dp[l][r] + dp[l + 1][r - 1] + QuickPow(2, sum[r - 1] - sum[l]))%MOD;
        }
    }
    printf("%lld\n", dp[1][n]);
    return 0;
}