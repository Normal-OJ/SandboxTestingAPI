#include <bits/stdc++.h>
using namespace std;

const int N = 200000;
const long long P = 998244353;

long long inv(long long x){
    long long res = 1;
    int n = P - 2; x %= P;
    while (n){
        if (n & 1) res = res * x % P;
        x = x * x % P; n >>= 1;
    }
    return res;
}

int a[N+5];
long long p[N+5];

int main(){
    int n; scanf("%d", &n);
    for (int i = 1; i <= n; ++i){
        scanf("%d", a+i);
        p[i] = 100 * inv(a[i]) % P;
    }
    long long ans = 0, tmp = 1;
    for (int i = n; i >= 1; --i){
        tmp = tmp * p[i] % P;
        ans = (ans + tmp) % P;
    }
    printf("%d\n", (int)((ans + P) % P));
    return 0;
}