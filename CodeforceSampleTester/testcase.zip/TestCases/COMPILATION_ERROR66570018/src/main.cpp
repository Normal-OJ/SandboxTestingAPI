package com.company;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        // write your code here
        Scanner sc = new Scanner(System.in);
        int T=sc.nextInt();
        int n;
        for(int i=0;i<T;i++)
        {
            n=sc.nextInt();
            int[] arr=new int[n];
            int[] bucket=new int[n];
            for(int j=0;j<n;j++)
            {
                arr[j]=sc.nextInt();
            }
            int k=0;
            for(int j=0;j<n;j++)
            {

                if(j==0 || arr[j]==arr[j-1])
                {
                    bucket[k]++;
                }
                else
                {
                    k++;
                    bucket[k]++;
                }
            }
            /*for(int j=0;j<=k;j++)
            {
                System.out.print(bucket[j]+" ");
            }*/

            int half=n-n/2,s=0;
            int j;
            for(j=k;j>=0;j--)
            {
                s+=bucket[j];
                if(s>=half) break;
            }

            if(j<3)
            {
                System.out.println("0 0 0");
            }
            else{


                int b=0;
                for(int m=2;m<j;m++)
                {
                    b+=bucket[m];
                }

                System.out.println(bucket[0]+" "+bucket[1]+" "+b);
            }
        }
    }
}
