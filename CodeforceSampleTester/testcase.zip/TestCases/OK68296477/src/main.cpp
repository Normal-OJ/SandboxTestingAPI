#include<iostream>
#include<string.h>
#include<cstdio>
using namespace std;
int t,f;
string s;
int main(){
	
	cin>>t;
	while(t--){
		cin>>s;
		f=1;
		if(s[0]=='?'){
			if(s[1]!='a')s[0]='a';else
			if(s[1]!='b')s[0]='b';else
			if(s[1]!='c')s[0]='c';
		}
		for(int i=0;i<s.length();i++){
			if(s[i]=='?'){
				if(s[i+1]!='a'&&s[i-1]!='a')s[i]='a';else
				if(s[i+1]!='b'&&s[i-1]!='b')s[i]='b';else
				if(s[i+1]!='c'&&s[i-1]!='c')s[i]='c';
			}else
			if(s[i]==s[i+1]){f=0;break;}
		}
		if(f)cout<<s<<"\n";else printf("-1\n");
	}
	
}

  	 	 		 	 	  						 	 	 					