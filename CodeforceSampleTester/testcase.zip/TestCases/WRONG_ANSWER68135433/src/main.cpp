#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <unordered_map>
#include <map>
#include <unordered_set>
#include <set>
 
using namespace std;
 
#define _ ios_base::sync_with_stdio(0);cin.tie(0);
 
const long long INF = 0x3f3f3f3f;
 
int main() { _

	int t;

	cin >> t;

	while(t) {

		int n;

		cin >> n;
		int m = n/2;

		map<int, int> count;
		for(int i = 0; i < n; i++) {

			int num;
			cin >> num;
			count[num] += 1;
		}

		if (m < 5) {

			printf("0 0 0\n");
		}
		else {

			int maxi = (count.rbegin())->first;
			int x = count[maxi];
			count.erase(maxi);
			if((m - x)/2 <= x) {

				printf("0 0 0\n");
			}
			else {

				maxi = (count.rbegin())->first;
				int y = count[maxi];
				count.erase(maxi);
				if((m - x - y) <= 0) {

					printf("0 0 0\n");
				}
				else {

					maxi = (count.rbegin())->first;
					int z = count[maxi];
					count.erase(maxi);
					if(m < x + y + z) {

						printf("0 0 0\n");
					}
					else {

						int k = z;
						while(m > x + y + z) {

							k = z;
							maxi = (count.rbegin())->first;
							z += count[maxi];
							count.erase(maxi);
							if(x + y + z == m) {
								k = z;
								break;
							}
						}
						printf("%d %d %d\n", x, y, k);
					}
				}
			}
		}

		t--;
	}

	return 0;
}