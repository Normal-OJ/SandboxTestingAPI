#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>
#include <set>
 
using namespace std;
 
#define _ ios_base::sync_with_stdio(0);cin.tie(0);
 
const long long INF = 0x3f3f3f3f;
 
int main() { _
 
	int t;

	cin >> t;

	while(t) {

		int n;
		cin >> n;

		vector<int> v(n), pos(n + 1);
		string s(n, '0');
		s[0] = '1';
		s[n - 1] = '1';
		for(int i = 0; i < n; i++) {

			cin >> v[i];
			pos[v[i]] = i;
		}

		int mini = pos[1], maxi = pos[1];
		set<int> numbers;
		numbers.insert(1);
		for(int i = 2; i <= n - 1; i++) {
			if (numbers.find(i) != numbers.end()) continue;
			if (pos[i] > maxi) {

				for (int j = maxi + 1; j <= pos[i]; j++) {

					numbers.insert(v[j]);
				}
			}
			else if (pos[i] < mini) {

				for (int j = pos[i]; j < mini; j++) {

					numbers.insert(v[j]);
				}
			}
			int num = *numbers.rbegin();
			if (num == numbers.size()) {

				s[num - 1] = '1';
			}
			maxi = max(maxi, pos[i]);
			mini = min(mini, pos[i]);
		}

		cout << s << endl;

		t--;
	}
 
	return 0;
}