#include <iostream>
#include <vector>
#include <numeric>
using namespace std;

int main(int argc, char *argv[]) {
	int arr[4], temp[4];
	vector<int> numbers;
	bool end = false;
	cin >> arr[0] >> arr[1] >> arr[2] >> arr[3];
	copy(arr,arr+4,temp);
	int i = 0;
	while(!end) {
		if(arr[i] > 0) {
			arr[i]--;
			numbers.push_back(i);
			if(i > 0 && arr[i-1] > 0)
				i--;
			else if(i < 3 && arr[i + 1] > 0)
				i++;
			else
				end = true;
		}
	}
	if(accumulate(arr,arr+4,0) > 0) {
		numbers.clear();
		copy(temp,temp+4,arr);
		i = 1;
		end = false;
		while(!end) {
			if(arr[i] > 0) {
				arr[i]--;
				numbers.push_back(i);
				if(i > 0 && arr[i-1] > 0)
					i--;
				else if(i < 3 && arr[i + 1] > 0)
					i++;
				else
					end = true;
			}
		}
	}
	if(accumulate(arr,arr+4,0) == 0) {
		cout << "YES" << endl;
		for(int i = 0; i < numbers.size(); ++i)
			cout << numbers[i] << ' ';
		cout << endl;
	} else {
		cout << "NO" << endl;
	}
	return 0;
}

