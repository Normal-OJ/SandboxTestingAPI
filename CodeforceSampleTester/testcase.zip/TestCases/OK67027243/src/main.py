if __name__ == "__main__":
    
    t = int(input())
    while t:
        n = int(input())
        arr = [int(x) for x in input().split()]
        ans = ""
        p = [0] * n
        for i in range(n):
            p[arr[i]-1] = i

        l = n + 1
        r = -1
        for i in range(n):
            l = min(l, p[i])
            r = max(r, p[i])
            if r - l == i:
                ans += "1"
            else:
                ans += "0"
        print(ans)
        t -= 1