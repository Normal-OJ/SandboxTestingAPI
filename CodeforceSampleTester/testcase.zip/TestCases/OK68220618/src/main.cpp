#include<bits/stdc++.h>
#define LL long long
using namespace std;
const int N=1e5+10;
const int mod=10000007;
int n,m,k,T,t,now,len;
string s;
char s1[3]={'a','b','c'};
void solve(){
    cin>>s;
    vector<int>v;
    len=s.size();
    for(int i=0;i<len;i++){
        if(s[i]==s[i+1]&&s[i]!='?'){cout<<-1<<endl;return;}
        if(s[i]!='?')v.push_back(i);
    }
    if(v.size()==0){
        for(int i=0;i<len;i++){
            s[i]=s1[i%3];
        }
        cout<<s<<endl;return;
    }
    len=v.size();
    if(v[0]>0){
        now=s[v[0]]-'a'+1;
        t=v[0]-1;
        while(t>=0)s[t]=s1[now%3],now++,t--;
    }
    for(int i=0;i<len-1;i++){
        if(v[i]-v[i+1]==-1)continue;
        if(s[v[i]]==s[v[i+1]]){
            now=s[v[i]]-'a';
            for(int j=v[i]+1;j<=v[i+1]-1;j++){
                if(s1[now%3]==s[v[i]])now++;
                s[j]=s1[now%3];
                now++;
            }
        }else {
            char c;
            now=1;
            for(int j=0;j<3;j++)if(s1[j]!=s[v[i]]&&s1[j]!=s[v[i+1]])c=s1[j];
            for(int j=v[i]+1;j<=v[i+1]-1;j++){
                if(now%2)s[j]=c;
                else s[j]=s[v[i]];
                now++;
            }
        }
    }
    m=s.size()-1;
    if(v[len-1]!=m){
        now=s[v[len-1]]-'a'+1;
        t=v[len-1]+1;
        while(t<=m)s[t]=s1[now%3],now++,t++;
    }
    cout<<s<<endl;
}
int main(){
    scanf("%d",&T);
    while(T--){
        solve();
    }
    return 0;
}
