#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N = 2e5+10;
const int mod = 998244353;
int a[N];
int ksm(int a,int b)
{
	int ret = 1;
	a %= mod;
	while( b )
	{
		if( b & 1 )
			ret = 1ll*ret*a%mod;
		b >>= 1;
		a = 1ll*a*a%mod;
	}
	return ret % mod;
}
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	LL ans = 0;
	for(int i=1;i<=n;i++)
		ans = 1ll*100*(ans+1)*(1ll*ksm(a[i],mod-2)%mod);
	printf("%lld\n",ans);
	return 0;
}