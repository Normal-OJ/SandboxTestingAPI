#include <iostream>
#define MAX 100500000

using namespace std;

int n, len, num[MAX], point, out[MAX];

void izq (int start)
{
    int maxi = 1;

    while (start >= 0)
    {
        if ( num[start] > maxi )
        {
            maxi = num[start];
            out[ num[start] - 1 ] = 1;
        }
        else
            out[ num[start] - 1 ] = 0;

        start--;
    }

    return;
}

void der (int start)
{
    int maxi = 1;

    while ( start < len )
    {
        if ( num[start] > maxi )
        {
            maxi = num[start];
            out [ num[start] - 1 ] = 1;
        }
        else
            out [ num[start] - 1 ] = 0;

        start++;
    }

    return;
}

int main()
{
    cin >> n;
    out[0] = 1;

    for (int i = 0; i < n; i++)
    {
        cin >> len;
        for (int j = 0; j < len; j++)
        {
            cin >> num[j];
            if ( num[j] == 1 )
                point = j;
        }

        izq (point - 1);
        der (point + 1);

        for (int j = 0; j < len; j++)
        {
            cout << out[j];
        }
        cout << endl;
    }
    return 0;
}
