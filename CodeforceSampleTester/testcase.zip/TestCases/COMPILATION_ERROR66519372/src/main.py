'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''
lens = int(input())
arr = []
for i in range(lens):
    v = input()
    arr.append(v)

ans = []
trys = ['a', 'b','c']
for strs in arr:
    prev = ""
    n = len(strs)
    vt = ""
    for i in range(n):
        if strs[i] != "?":
            vt += strs[i]
            prev = strs[i]
            if i + 1 != n:
                if strs[i] == strs[i + 1]:
                    vt = "-1"
                    break
        else:
            if i + 1 == n:
                for u in trys:
                    if u != strs[i]:
                        prev = u
                        vt += u
                        break
            elif i == 0 and strs[i + 1] != '?':
                for u in trys:
                    if u != strs[i + 1]:
                        prev = u
                        vt += u
                        break
            elif i == 0 and strs[i + 1] == '?':
                vt += 'a'
                prev = 'a'
            elif strs[i + 1] == '?':
                for u in trys:
                    if u != prev:
                        prev = u
                        vt += u
                        break
            else:
                for u in trys:
                    if u != prev and u != strs[i + 1]:
                        prev = u
                        vt += u
                        break
    ans.append(vt)

    
return ans
                
                
                
                
    