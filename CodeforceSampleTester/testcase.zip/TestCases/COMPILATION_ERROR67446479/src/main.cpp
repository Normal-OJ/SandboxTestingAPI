#include<bits/stdc++.h>
using namespace std;
int main()
{
	int t,l=0;
	cin>>t;
	string s;
	for(int i=0;i<t;i++){
	cin>>s;
	l=0;
	for(char c='a';c<='c';c++)
			if((s[j-1]!=c)&&(s[j+1]!=c))
			s[j]=c;
		}}
	cout<<s<<"\n";
	else
	cout<<-1<<"\n";
}
return 0;
}
