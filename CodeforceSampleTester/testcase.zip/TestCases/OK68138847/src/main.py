for h in range (int(input())):
	a = int(input())
	l1 = list(map(int, input().split()))
	arr = [0] * a
	for i in range (a):
		arr[l1[i] - 1] = i
	l = a
	r = 0
	s = ""
	for i in range (a):
		l = min(l, arr[i])
		r = max(r, arr[i])
		if r - l == i:
			s += "1"
		else:
			s += "0"
	print(s)

