#include<bits/stdc++.h>
 
using namespace std;
 
#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i )
#define inv(x) power(x, Mod - 2)
#define int long long
 
const int maxn = 2e5 + 10;
const int Mod = 998244353;
 
int n, f[maxn];
 
inline int power(int a, int b)
{
	int r = 1;
	while ( b ) { if ( b & 1 ) r = r * a % Mod; a = a * a % Mod; b >>= 1; }
	return r;
}
 
signed main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	scanf("%I64d", &n);
	REP(i, 1, n)
	{
		int x; scanf("%I64d", &x);
		x = x * inv(100) % Mod;
		f[i] = (f[i - 1] + 1) * inv(x) % Mod;
	}
	printf("%I64d\n", f[n]);
	return 0;
}