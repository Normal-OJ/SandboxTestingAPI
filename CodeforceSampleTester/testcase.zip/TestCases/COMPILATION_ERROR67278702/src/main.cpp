#include <iostream>
#include <cstdio>

using namespace std;
const int INF = 1e9;
const int Size = 2e5 + 5;
int a[Size];
int ans[Size];
bool f[Size];

int main(){
	int T;
	cin >> T;
	while(T--){
		scanf("%d", &n);
		for(int i = 1; i <= n; i++) scanf("%d", a + i);
		a[0] = a[n + 1] = INF;
		int op = fOne();
		while(1){
			judge(op);
		}
		
	}
	return 0;
}
 	  		 		 	 			 		     	 	 	 	