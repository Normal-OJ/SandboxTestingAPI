#include<stdio.h>
#include<string.h>
#include<stdlib.h>
char str[100000];
int main(){
	int n;
	int len,flag;
	scanf("%d",&n);
	while(n--){
		flag=1;
		scanf("%s",str);
		len=strlen(str);
		if(str[0]=='?'){
			if(str[1]!='a') str[0]='a';
			else if(str[1]!='b') str[0]='b';
			else if(str[1]!='c') str[0]='c';
		}
        for(int i=0;i<len-1;i++)
        {
            if(str[i]!='?' && str[i]==str[i+1])
            {
                flag=0;
                break;
            }
        }
        if(!flag)
        {
            printf("-1\n");
            continue;
        }
		for(int i=0;i<len;i++){
			if(str[i]=='?'){
                // printf("%d %c %c\n",i,str[i-1],str[i+1]);
				     if(str[i-1]!='a'&&str[i+1]!='a') str[i]='a';
				else if(str[i-1]!='b'&&str[i+1]!='b') str[i]='b';
				else if(str[i-1]!='c'&&str[i+1]!='c') str[i]='c';
			}
			else{
				if(str[i]==str[i+1]){
					flag=0;break;
				}
			}
		}
		if(flag)
		printf("%s\n",str);
		else
		printf("-1\n");
	}
	return 0;
}
