for _ in range(int(input())):
    n = int(input())
    arr = list(map(int, input().split()))
    mark = [0] * n
    out = ''
    for i in range(n):
        a = arr.index(i + 1)
        mark[a] = 1
        flag1 = 0
        flag2=0
        for j in range(n - 1):
            if flag1==0 and mark[j] == 1:
                flag1 = 1
            elif flag1==1 and mark[j]==1:
                if mark[j-1]==0:
                    flag2=1
                    break
        if flag1 == 1 and flag2==1:
            out += '0'
        else:
            out += '1'
    print(out)
