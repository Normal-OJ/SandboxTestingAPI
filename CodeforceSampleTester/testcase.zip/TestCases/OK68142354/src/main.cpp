#include<iostream>
#define N 400010
using namespace std;

int A[N],B[N];

int main() {
	int t,x,n,k;
	scanf("%d",&t);
	while(t--) {
		scanf("%d",&n);
		int j=0;
		for(x=0;x<n;x++) {
			scanf("%d",&k);
			if(x==0) 
				A[j]=k,B[j]=1;
			else {
				if(k == A[j])
					B[j]++;
				else
					A[j+1]=k,B[++j]=1;
			}
		}
		for(x=1;x<=j;x++) 
			B[x]+=B[x-1];
		int g=0,s=1,b;
		int last_g=0,last_b=0,last_s=0;
		for(;s<j && B[s]-B[0] <= B[0];s++);
		
		for(b=s+1;B[b]-B[s] <= B[0];b++);
		
		if(B[b] <=n/2)
			last_g=B[g],last_s=B[s]-B[g],last_b=B[b]-B[s];
		for(;B[b]<=n/2 && b<j;b++) 
			last_b=B[b]-B[s];
		printf("%d %d %d\n",last_g,last_s,last_b);
	}
	return 0;
}