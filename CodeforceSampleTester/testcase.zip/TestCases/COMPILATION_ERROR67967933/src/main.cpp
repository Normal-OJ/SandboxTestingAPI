//do u need something? 
#include <bits/stdc++.h>
/*
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/t_policy.hpp>
using namespace __gnu_pbds;
//*/
/*
#pragma GCC target ("avx2")
#pragma GCC optimization ("O3")
#pragma GCC optimization ("unroll-loops")
//*/

std::mt19937 rng(std::chrono::system_clock::now().time_since_epoch().count());
using namespace std;
#define IO ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0)
#define y1 asjfkgasj
#define all(v) (v).begin(),(v).end()
#define pb push_back
#define F first
#define S second
#define endl '\n'
#define flsh '\n'<<flush
#define mp make_pair
#define mt make_tuple
#define sz size
#define pii pair<int,int>
#define pll pair<long long,long long>
#define vi vector<int>
#define vll vector<long long>
#define deb(x) cout<< #x <<'='<< x <<flsh;
#define iii int,int,int
#define ull unsigned long long
#define intt long long
#define ll long long
#define ld long double
#define dd double
#define OK cout<<"OK\n"<<flsh;
#define setpre(x) fixed<<setprecision(x)
#define mmset(x,y) memset(x,y,sizeof(x))
ll dis[1001][1001],c[1001];
vector<set<int>>g;

void dfs(int v)
{
	c[v]=1;
	for(int u : g[v]) if(!c[u]) dfs(u);
}

map<ll,vector<int>>m;
int n,ans;
pii a[1000];
main()
{
	IO;
	cin>>n;
	g.resize(n+1);
	for(int i=1;i<=n;i++)
		cin>>a[i].F>>a[i].S;
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			dis[i][j]=dis[j][i]=
				(a[i].F-a[j].F)*(a[i].F-a[j].F)
				+
				(a[i].S-a[j].S)*(a[i].S-a[j].S);
	for(int i=1;i<=n;i++)
	{
		for(int j=i;j<=n;j++)
			cout<<dis[i][j]<<"   ";
		cout<<endl;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(i!=j)
				m[dis[i][j]].pb(j);
		}
	}
	for(pair<ll,vector<int>> v : m)
	{
		for(int x=0;x<v.S.size();x++)
			for(int y=x+1;y<v.S.size();y++)
			{
				g[v.S[x]].insert(v.S[y]);
				g[v.S[y]].insert(v.S[x]);
			}
	}
	//*
	for(int i=1;i<=n;i++)
	{
		cout<<i<<":"<<endl;
		for(int u : g[i]) cout<<u<<' ';
		cout<<endl;
	}
	//*/
	dfs(1);
	for(int i=1;i<=n;i++)
		if(c[i]) ans++;
	cout<<ans<<endl;
	for(int i=1;i<=n;i++)
		if(c[i]) cout<<i<<' ';
	return 0;
}asefawe

