#include<bits/stdc++.h>
#include<fstream>
//ofstream mycout("C:/Users/Sevenenen/Desktop/a.txt",ios::app);
using namespace std;
#define N 400005

int main()
{
	int num[4]={};
	cin>>num[0]>>num[1]>>num[2]>>num[3];
	if(num[0]>num[1]+1-(num[2]>0)||num[1]>num[0]+num[2]+1||
	num[2]>num[1]+num[3]+1||num[3]>num[2]+1-(num[1]>0)||(num[1]==0&&num[2]==0&&num[0]!=0&&num[3]!=0))
	{
		cout<<"NO"<<endl;
		return 0;
	}
	int flag=0;
	if(num[1]>num[0])
		flag=1;
	if(num[2]>num[flag])
		flag=2;
	if(num[3]>num[flag])
		flag=3;
	num[flag]--;
	cout<<"YES"<<endl;
	cout<<flag<<" ";
	int fx=-1;
	while(num[0]+num[1]+num[2]+num[3])
	{
		if(flag-1>=0&&num[flag-1]&&fx=-1)
		{
			flag--;
			cout<<flag<<" ";
			num[flag]--;
		}
		else
		{
			if(flag==3)
			{
				fx=-1;
				continue;
			}
			fx=1;
			flag++;
			cout<<flag<<" ";
			num[flag]--;
		}
	}
	return 0;
}