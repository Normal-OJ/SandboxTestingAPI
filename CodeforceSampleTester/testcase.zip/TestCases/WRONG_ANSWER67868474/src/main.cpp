#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
int a,b,c,d;
vector<int>ans;
int main()
{
    //freopen(".in","r",stdin);
    //freopen(".out","w",stdout);
    ios::sync_with_stdio(0),cin.tie(0);
    int i,j,len;
    cin>>a>>b>>c>>d;
    len=a+c;
    if(b+d>a+c+1||b+d<a+c-1||a&&b==0||d&&c==0||d>c&&b)
    {
        cout<<"NO";
        return 0;
    }
    if(b+d==a+c-1&&d>=c)
    {
        cout<<"NO";
        return 0;
    }
    if(b+d>=a+c)
    {
        while(a||b||c||d)
        {
            if(d>0)
            {
                ans.push_back(3);
                ans.push_back(2);
                d--,c--;
                continue;
            }
            if(b>0)
            {
                ans.push_back(1);
                b--;
                if(c>0)
                {
                    ans.push_back(2);
                    c--;
                }
                else
                {
                    ans.push_back(0);
                    a--;
                }
                continue;
            }
            if(c>0)
            {
                ans.push_back(2);
            }
            else if(a>0)
                ans.push_back(0);
        }
    }
    if(b+d==a+c-1)
    {
        while(a||b||c||d)
        {
            if(c>0)
            {
                ans.push_back(2);
                c--;
                if(d>0)
                {
                    ans.push_back(3);
                    d--;
                }
                else if(b>0)
                {
                    ans.push_back(1);
                    b--;
                }
                continue;
            }
            if(a>0)
            {
                ans.push_back(0);
                a--;
                if(b>0)
                {
                    ans.push_back(1);
                    b--;
                }
                continue;
            }
            if(c>0)
            {
                ans.push_back(2);
            }
            else if(a>0)
                ans.push_back(0);
        }
    }
    for(i=ans.size()-1;i>=0;i--)
        cout<<ans[i]<<' ';
    return 0;
}
