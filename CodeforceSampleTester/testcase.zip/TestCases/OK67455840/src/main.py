for _ in range(int(input())):
    s = input()

    if len(s) == 1:
        print('a' if s is '?' else s)
        continue

    ans = []

    if s[0] is '?':
        ans.append('b' if s[1] is 'a' else 'a')
    else:
        ans.append(s[0])

    for c in s[1:]:
        if ans[-1] is '?':
            for b in 'abc':
                if ans[-2] != b and c != b:
                    ans[-1] = b
                    break
        else:
            if ans[-1] is c:
                ans = None
                break
        ans.append(c)

    if ans is None:
        print(-1)
    else:
        if ans[-1] is '?':
            for b in 'abc':
                if ans[-2] != b:
                    ans[-1] = b
                    break
        print(*ans, sep='')
