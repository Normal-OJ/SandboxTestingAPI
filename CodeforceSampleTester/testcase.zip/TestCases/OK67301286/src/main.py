import math

T = int(input())
anwer = ""

for t in range(T):
	
	n = int(input())
	gotten = list(map(int, input().split(' ')))

	p = [0] * n

	i = 0
	for g in gotten:
		p[g-1] = i
		i += 1

	minI = n
	maxI = 0

	ans = ""

	for i in range(n):

		minI = min(minI, p[i])
		maxI = max(maxI, p[i])

		if maxI - minI == i:
			ans += "1"
		else:
			ans += "0"

	anwer += ans + '\n'

print(anwer)