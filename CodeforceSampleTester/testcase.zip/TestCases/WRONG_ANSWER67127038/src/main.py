T = int(input())
for I in range(T):
    N = int(input())
    P = list(map(int, input().split()))
    for J in range(1,N+1):
        F = 0
        MIN = P.index(J)-J
        MAX =  P.index(J)+J
        if MIN<0:
            MIN = 0
        if MAX>N-1:
            MAX = 0
        for K in range(MIN, MAX):
            if max(P[K:J+K]) == J:
                F = 1
                print(1, end='')
                break
        if F == 0:
            print(0, end='')
    print()