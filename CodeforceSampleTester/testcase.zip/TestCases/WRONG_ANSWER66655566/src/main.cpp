#include <string.h>
#include <assert.h>
#include <cassert>
#include <unordered_map>

#include <sstream>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <bitset>
#include <algorithm>
#include <iostream>
#include <stack>
#include <queue>
#include <set>

#include <map>
#include <vector>
#include <string>
#include <stdlib.h>
#include <cassert>

#define ll long long
#define clr(x) memset(x,0,sizeof(x))
#define _clr(x) memset(x,-1,sizeof(x))
#define fr(i,a,b) for(int i = a; i < b; ++i)
#define frr(i,a,b) for(int i = a; i > b; --i)
#define pb push_back
#define sf scanf

#define pf printf
#define mp make_pair
#define N 300000

const int mod = 998244353;

using namespace std;

int n;
ll dp[N];
ll p[N];

ll pw(ll a,int b) {
    ll ret = 1;
    while(b>0) {
        if(b&1) ret = (ret * a)%mod;
        a = (a*a)%mod;
        b >>=1;
    }
    return ret;
}

int main() {
    cin>>n;
    fr(i,1,n+1) cin>>p[i];
    fr(i,1,n+1) {
        p[i] = (100*pw(p[i],mod-2))%mod;
    }
    dp[0] = 0;
    for(int i = 1; i <=n; ++i) {
        dp[i] = (dp[i-1]+1)*(p[i]);
    }
    cout<<dp[n]<<endl;
}