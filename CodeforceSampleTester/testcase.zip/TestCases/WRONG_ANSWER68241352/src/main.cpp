#include<stdio.h>
#include<string.h>
int main()
{
	char str[100001];
	int zhen;
	int i,k,n;
	scanf("%d",&n);
	for(k=1;k<=n;k++)
	{
		scanf("%s",&str);
		zhen=1;
		for(i=0;str[i]!='\0';i++)
		{
			if(str[i]=='?')
			{	
				if(i==0)
				{
					if(str[1]!='a') str[0]='a';
					else if(str[1]!='b') str[0]='b';
					else if(str[i]!='c') str[0]='c';
				}
				else
				{
					if(str[i-1]!='a' && str[i-1]!='a') str[i]='a';
					else if(str[i-1]!='b' && str[i-1]!='b') str[i]='b';
					else if(str[i-1]!='c' && str[i-1]!='c') str[i]='c';
				}
			}
			else if(str[i]==str[i+1])
				zhen=0;
		}
		if(zhen==0) printf("-1\n");
		else printf("%s\n",str);
	}
}
	  	  			 		  	  				  			 	 	