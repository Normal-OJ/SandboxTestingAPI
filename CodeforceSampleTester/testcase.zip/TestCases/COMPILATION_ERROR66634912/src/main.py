#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main(){
ll t;
cin>>t;
while(t--){
    string s;
    cin>>s;
    ll flag=0,i=0;
    if(s.length()==1&&s[0]=='?')
    cout<<s<<endl;
    else{
        for(i=0;i<s.length()-1;i++){
            if(s[i]!='?'&&s[i]==s[i+1]){
                flag=1;
                break;
            }
        }
        if(flag==1){
            cout<<"-1"<<endl;
        }
        else{
          for(ll i=0;i<s.length();i++){
            if(s[i]=='?'){
                s[i]='a';
                if(s[i]==s[i+1]||s[i]==s[i-1]){
                    s[i]=s[i]+1;
                    if(s[i]==s[i+1]||s[i]==s[i-1]){
                        s[i]=s[i]+1;
                    }
                }
            }
          }
          cout<<s<<endl;
        }
    }
}}
