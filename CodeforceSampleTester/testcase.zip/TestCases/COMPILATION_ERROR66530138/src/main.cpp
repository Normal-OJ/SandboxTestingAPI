#include<bits/stdc++.h>
using namespace std;

#define pi              2*acos(0.0)
#define all(v)          v.begin(),v.end()
#define ff              first
#define se              second
#define pb              push_back
#define mp              make_pair
#define Sort(a)         sort(all(a))
#define RSort(a)        Sort(a), reverse(all(a))
#define sz(x)           (int)x.size()
#define max3(a,b,c)     max(a, max(b, c))
#define min3(a,b,c)     min(a, min(b, c))
#define sq(a)           ((a) * (a))
#define abs(x)          (((x)<0)?-(x):(x))
#define precision(x)    cout << setprecision(x) << fixed
#define mem(a,v)        memset(a, v, sizeof(a))
#define gf              << ' ' <<
#define nl              << '\n'
#define faster        ios_base::sync_with_stdio(false);cin.tie(NULL)
#define TestCases       int cases, tc; sfi(tc); for(cases=1; cases<=tc; cases++)

/**------- ShortCuts----------*/
typedef long long             ll;
typedef pair<int, int>        pii;
typedef pair<ll, ll>          pll;
typedef pair<int, pii>        iii;
typedef vector<int>           vi;
typedef vector<ll>            vl;
typedef vector<pii>           vii;
typedef vector<iii>           viii;
typedef vector<vi>            vvi;
typedef map<int, int>         mapii;
typedef map<int, bool>        mapib;
typedef map<int, string>      mapis;
typedef set<int>              seti;

/**------- Scanf----------*/

#define sfst(a)            scanf("%[^\n]",a);
#define sf64(a)            scanf("%I64d", &a);

/**------- Printf----------*/

#define pfnl               printf("\n")
#define cog(a)             cout<<a<<" "
#define co(a)              cout<<a<<endl
#define conl               cout<<endl


int dr1[] = {1, 1, 0, -1, -1, -1, 0, 1};
int dc1[] = {0, 1, 1, 1, 0, -1, -1, -1};
int dr[] = {1,-1,0,0};
int dc[] = {0,0,1,-1};
/**--------Loops--------------*/
#define frab(i, a, b)      for(__typeof(b) i=(a); i<=(b); i++)
#define fr0(i, n)          frab(i, 0, n-1)
#define fr1(i, n)          frab(i, 1, n)
#define rfrab(i, a, b)     for(__typeof(b) i=(b); i>=a; i--)
#define rfr0(i, n)         rfrab(i, (n)-1, 0)
#define rfr1(i, n)         rfrab(i, n, 1)
#define MAX 1000005

/**----------------------Graph Moves----------------*/
const int fx[] = {+1,-1,+0,+0};                         /// 4 X directions
const int fy[] = {+0,+0,+1,-1};                         /// 4 Y directions
const int fx8[] = {+0,+0,+1,-1,-1,+1,-1,+1};            /// King X Moves
const int fy8[] = {-1,+1,+0,+0,+1,+1,-1,-1};            /// King Y Moves
const int kx[] = {-2, -2, -1, -1,  1,  1,  2,  2};      /// Knight X Moves
const int ky[] = {-1,  1, -2,  2, -2,  2, -1,  1};      /// Knight Y Moves


/**-----------------------Bitmask------------------*/
int  Set    (int N,int pos) {return N=N | (1<<pos);}    /// turn a bit on
int  reset  (int N,int pos) {return N= N & ~(1<<pos);}  /// turn a bit off
bool check  (int N,int pos) {return (bool)(N & (1<<pos));} /// check, if a bit is on or not

/**               Sort function
bool compare(const pair<int, int>&i, const pair<int, int>&j)
{
    return i.second < j.second;
}
vector< pair<int, int> >v;

sort(v.begin(),v.end(),compare);

*/

ll x[MAX];
int y[MAX];
//int z[MAX][MAX];
ll freq[MAX];
vi adj[201];
int vis[MAX];
int color[MAX];


int main()
{
    ll a,b,c,d,g,c,x,y,m= 0,n=0,ans=0,an=0,t,i,j=0;
    string s;vi v;mapii mp;
    cin>>t;
    while(t--)
    {
      cin>>a;
    x= a>>1;  ///a/2;
    seti st;
    fr0(i,a)
    {
       cin>>x[i];
       mp[x[i]]++;//co(c);
       if(mp[x[i]]==1) v.pb(x[i]);
    }
    if(a<12)
    {
      cout<<"0 0 0"<<endl;continue;
    }
    fr0(i,v.size())
    {

    }
    /*fr0(i,v.size())
      co(mp[v[i]]);*/
    }


   return 0;
}
