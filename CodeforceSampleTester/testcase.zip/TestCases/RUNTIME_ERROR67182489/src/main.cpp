#include<bits/stdc++.h>
#include<string>
using namespace std;
int main(){
ios_base::sync_with_stdio(false);
cin.tie(NULL);
cout.tie(NULL);
int T,N,C,MIN,MAX,I,J,X;
char S[N];
vector <int> P(N);
cin>>T;
for(X=0;X<T;X++){
cin>>N;
for(I=0;I<N;I++)
cin>>P[I];
for(I=0;I<N;I++){
C=1;
MIN=I-P[I];
MAX=I+P[I];
if(MIN<-1)MIN=-1;
if(MAX > N)MAX=N;
for(J=I-1;J>MIN;J--){
if(P[J]<P[I])C+=1;
else break;}
for(J=I+1;J<MAX;J++){
if(P[J]<P[I])C+=1;
else break;}
if(C==P[I])S[P[I]-1]='1';
else S[P[I]-1]='0';}
cout<<((string)S).substr(0, N)<<'\n';}}