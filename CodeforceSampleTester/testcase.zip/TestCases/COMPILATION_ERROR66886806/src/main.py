

def isBeautiful(word):
	for x in range(0,len(word)-1):
		if word[x] == word[x+1] :
			return False
	return True

def fillGaps(word):
	mylist = list(word)
	for index in  range(0,len(word)):
		if index == len(word)-1:
			if word[index] == "?":
				mylist[index] = getChar(word[index-1],word[index-1])
		elif index == 0:
			if word[index] == "?":
				mylist[index] = getChar(word[index+1],word[index+1])
		else:
			if word[index] == "?":
				mylist[index] = getChar(word[index-1],word[index+1])
	return mylist





def getChar(a,b):
	mychars = ["a","b","c"]
	given = list(set(a,b))
	for char in mychars :
		if char not in given :
			return char

	return "#" #denotes Error

num_test = input()
for x in range(0,num_test):
	word = input()
	output = fillGaps(word)
	if "#" in output:
		print("-1")
	else:
		print str(output)