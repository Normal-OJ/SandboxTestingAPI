#include <bits/stdc++.h>
#define ll long long
#define endl '\n'
using namespace std;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    int q;
    int a, b, c, d;
    bool ok = true;
    cin >> a >> b >> c >> d;
    if (!a && !b && !c)
        ok = false;
    if (!a && !c && !d)
        ok = false;
    if (!a && !b && !d)
        ok = false;
    if (!b && !c && !d)
        ok = false;
    if (a && !b && !c && d)
        ok = false;
    if (b && !c && d)
        ok = false;
    if (a && !b && c)
        ok = false;
    if (!ok)
    {
        cout << "NO" << endl;
        return 0;
    }
    vector<int> pos(a + c);
    int i = a;
    while (d > 0 && i < a + c)
    {
        pos[i] = 3;
        i++;
        d--;
    }
    for (int i = 0; i < a + c && b > 0; i++)
        if (!pos[i])
        {
            pos[i] = 1;
            b--;
        }
    if (d || b > 1)
    {
        cout << "NO" << endl;
        return 0;
    }
    for (int i = 0; i < a + c - 1; i++)
        if (!pos[i])
        {
            cout << "NO" << endl;
            return 0;
        }
    cout << "YES" << endl;
    if (b == 1)
        cout << 1 << ' ';
    for (int i = 0; i < a; i++)
    {

        cout << 0 << ' ';
        if (i != a + c - 1)
            cout << pos[i] << ' ';
    }
    for (int i = a; i < a + c; i++)
    {
        cout << 2 << ' ';
        if (i != a + c - 1)
            cout << pos[i] << ' ';
    }
    if (pos[a + c - 1])
        cout << pos[a + c - 1];
    cout << endl;
    return 0;
}
