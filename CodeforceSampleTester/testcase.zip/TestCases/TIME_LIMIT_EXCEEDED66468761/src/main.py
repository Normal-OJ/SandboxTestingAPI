# nmax = 4 * (10 ** 5) + 1
import sys

if __name__ == '__main__':
    poses = list(map(lambda x: int(x), input().split(' ')))
    a = sum(poses)
    ans = []
    get_from = -1
    for i, v in enumerate(poses):
        if v != 0:
            get_from = i
            ans = [i]
            a -= 1
            break
    if get_from != -1:
        poses[get_from] -= 1
    else:
        print("NO")
        sys.exit(0)
    # print("p", poses)
    while a:
        f = ans[0]
        p = ans[-1]
        # print(f, p, ans)

        if f != 3 and poses[f + 1] > 0:

            ans.insert(0, f + 1)
            a -= 1
            poses[f + 1] -= 1
            continue
        if f != 0 and poses[f - 1] > 0:
            ans.insert(0, f - 1)
            a -= 1
            poses[f - 1] -= 1
            continue
        if p != 3 and poses[p + 1] > 0:
            ans.append(p + 1)
            a -= 1
            poses[p + 1] -= 1
            continue
        if p != 0 and poses[p - 1] > 0:
            ans.append(p - 1)
            a -= 1
            poses[p - 1] -= 1
            continue

        print("NO")
        sys.exit(0)

    print("YES")
    print(' '.join(str(i) for i in ans))
