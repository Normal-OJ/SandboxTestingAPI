import sys
Input = sys.stdin.readline
for i in range(int(Input())):
    s = ' '.join(Input()).split()
    n = len(s)
    s = ['0'] + s + ['0']
    j = 1
    while j < n+1:
        if s[j] == '?':
            for x in 'abc':
                if x != s[j - 1] and x != s[j + 1]:
                    s[j] = x
                    break
        else:
            j += 1
    s = ''.join(s[1:len(s) - 1])
    print(-1 if 'aa' in s or 'bb' in s or 'cc' in s else s)

# FMZJMSOMPMSL
# Ravens ;)
# Codeforcesian
# کل الگوریتم رو تو زدی
# خوب شد ؟
# این نامه رو فقط علیرضا بخواند
# ♥
