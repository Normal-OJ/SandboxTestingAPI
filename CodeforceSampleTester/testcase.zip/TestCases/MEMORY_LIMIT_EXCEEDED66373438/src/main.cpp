#include<bits/stdc++.h>
using namespace std;
#define inf 0x3f3f3f3f
#define ll long long
const int N=200005;
const int mod=1e9+7;
const double eps=1e-8;
const double PI = acos(-1.0);
#define lowbit(x) (x&(-x))
ll p[N],q[N];
int main()
{
    std::ios::sync_with_stdio(false);
    cin>>p[0]>>p[1]>>p[2]>>p[3];
    for(int i=0; i<4; i++)
    {
        for(int j=0; j<4; j++)
            q[j]=p[j];
        for(int x=0; x<4; x++)
        {
            vector<int> ans;
            q[x]--;
            ans.push_back(x);
            while(1)
            {
                if(x&&q[x-1])
                    --x,q[x]--,ans.push_back(x);
                else if(x!=3&&q[x+1])
                    ++x,q[x]--,ans.push_back(x);
                else
                    break;
            }
            if(!q[0]&&!q[1]&&!q[2]&&!q[3])
            {
                cout<<"YES"<<endl;
                for(int it:ans)
                {
                    cout<<it<<" ";
                }
                cout<<endl;
                return 0;
            }
        }
    }
    cout<<"NO"<<endl;
    return 0;
}
