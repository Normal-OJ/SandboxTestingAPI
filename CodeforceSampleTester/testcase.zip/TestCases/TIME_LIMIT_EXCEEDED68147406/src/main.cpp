                        #include<iostream>
                        using namespace std;
                        int main()
                        {string s;int k;
                              int n;
                              cin>>n;
                              while(n--)
                              {
                                   
                                    cin>>s;
                                    int l=s.length();
                                    for(int i=0;i<l;i++)
                                    {if(s[i]==s[i+1] && s[i]!='?'){k=0;break;}
                                    k=1;
                                       if(s[i]=='?')
                                       {
                                             s[i]=='a';
                                             int j=0;
                                             while(s[i]==s[i-1]||s[i]==s[i+1])
                                             {if(j==0)
                                                   s[i]='b';
                                                 else if(j==1){
                                                       s[i]='c';j++;}
                                              
                                             }
                                    }
                              if(k==0)cout<<-1<<endl;
                              else cout<<s<<endl;}
                        }}