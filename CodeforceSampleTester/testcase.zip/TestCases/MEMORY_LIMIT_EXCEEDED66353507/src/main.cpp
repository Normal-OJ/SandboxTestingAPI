#include<stdio.h>

int b[100005];
int c[100005];
int a[1000][100005];

int main()
{
	int n;
	
	
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		int m,max,min,e;
		
		scanf("%d",&m);
		for(int j=0;j<m;j++)
		{
			scanf("%d",&c[j]);
			b[c[j]-1]=j;
		}
		for(int j=0;j<m;j++)
		{
			max=b[0];
			min=b[0];
			for(int k=0;k<=j;k++)
			{
				if(max<b[k])
				{
					max=b[k];
				
				}
				if(min>b[k])
				{
					min=b[k];
					
				}
					
			}
			if(max-min==j)
			{
				a[i][j]=1;
			}
			else
			{
				a[i][j]=0;
			}
			e=j;
		}
		a[i][e+1]=2;
	}
	for(int i=0;i<n;i++)
	{
		int p=0;
		while(a[i][p]!=2)
		{
			printf("%d",a[i][p]);
			p++;
		}
		printf("\n");
	}
	return 0;
}
