#include <bits/stdc++.h>
using namespace std;

typedef long long ll;


int main() {
    #ifdef sayedalmahdi
        freopen("in.txt", "r", stdin);
        freopen("out.txt", "w", stdout);
    #endif // sayedalmahdi

    ios_base::sync_with_stdio(0); cin.tie(0);
    
    int t, n, v;
    cin >> t;
    
    while (t--) {
        cin >> n;
        
        vector <int> idx(n + 1), ans(n + 1);
        
        for (int i=1; i <= n; i++) {
            cin >> v; idx[v] = i;
        }
        
        int l = INT_MAX, r = INT_MIN;
        for (int i=1; i <= n; i++) {
            l = min(l, idx[i]);
            r = max(r, idx[i]);
            
            // cout << i << " " << idx[i] << " " << l << " " << r << "\n";
            ans[i] = int((r - l + 1 == i));
        }
        
        for (int i=1; i <= n; i++) cout << ans[i]; cout << "\n";
    }
    
    return 0;
}
			   								  	 	 			 		