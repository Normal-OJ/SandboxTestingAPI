#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t,i;
    long n,j,l,r,k;
    cin>>t;
    for(i=0;i<t;i++)
    {
        cin>>n;
        long a[n];
        int b[n];
        for(j=0;j<n;j++)
            cin>>a[j];
        
        b[0]=1;
        b[n-1]=1;
        
        for(j=0;j<n;j++)
        {
            if(a[j]!=1 || a[j]!=n)
            {
                k=j-1;
                
                while(k>=0)
                {
                    if(a[k]>a[j])
                    {
                        break;
                    }
                    else
                        k--;
                }
                l=k;
                k=j+1;
                
                while(k<n)
                {
                    if(a[k]>a[j])
                    {
                        break;
                    }
                    else
                        k++;
                }
                r=k;
                
                if((r-l-1)>=a[j])
                    b[a[j]-1]=1;
                else
                    b[a[j]-1]=0;
            }
        }
        for(j=0;j<n;j++)
            cout<<b[j]<<;
        
        cout<<"\n";    
        
    }
    return 0;
}