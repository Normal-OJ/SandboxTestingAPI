t = int(input())

for x in range(t):
	n = int(input())
	a = list(map(int, input().split(' ')))
	index = [None for i in range(n)]
	for i in range(n):
		index[a[i] - 1] = i

	ans = ['0' for i in range(n)]
	min_index = n+1
	max_index = -1
	for m in range(n):
		if index[m] > max_index:
			max_index = index[m]
		if index[m] < min_index:
			min_index = index[m]
		if max_index - min_index == m:
			ans[m] = '1'

	print(''.join(ans))
