#include <iostream>
using namespace std;

bool judge(char a, char b, char c) {
    if (a == b)
        return false;
    else if (b == c)
        return false;
    return true;
}

char getResult(char a, char b, char c) {
    if (b != '?' && !judge(a, b, c))
        return 'd';
    if (judge(a, 'a', c))
        return 'a';
    else if (judge(a, 'b', c))
        return 'b';
    else if (judge(a, 'c', c))
        return 'c';
    else
        return 'd';
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        string s;
        cin >> s;
        int i;
        for (i = 0; i < s.length(); i++) {
            if (i == 0 && s[i] == '?') {
                if (i + 1 == s.length())
                    s[i] = 'a';
                else if (i + 1 < s.length()) {
                    char c = getResult('?', s[i], s[i + 1]);
                    if (c == 'd')
                        break;
                    s[i] = c;
                }
            } else if (s[i] == '?') {
                if (i + 1 == s.length()) {
                    s[i] = getResult(s[i - 1], '?', '?');
                } else {
                    char c = getResult(s[i - 1], '?', s[i + 1]);
                    if (c == 'd')
                        break;
                    s[i] = c;
                }
            } else {
                char c = getResult(s[i - 1], s[i], s[i + 1]);
                if (c == 'd')
                    break;
            }
        }
        if (i == s.length()) {
            cout << s << endl;
        } else
            cout << "-1" << endl;
    }
    system("pause");
    return 0;
}

 			  			  		   	 	 					 				