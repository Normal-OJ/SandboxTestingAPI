#include<bits/stdc++.h>
typedef long long ll  ;
using namespace std   ;
const long long INF64 = ( long long)(1e18) + 100 ;
const int sizee = 4e5 + 5 ;
int main()
{
    ios::sync_with_stdio() ;
    cin.tie(0)   ;
    cout.tie(0)  ;
    int t ;
    cin >> t ;
    while( t-- )
    {
        ll n ;
        cin >> n ;
        vector< ll > v ;
        ll prev = 0, cnt = 0 , q = 0 ;
        for ( int i = 1 ; i <= n ; i ++ )
        {
            cin >> q ;
            if(!q){cnt = 0 , continue ; }
            if( prev == 0 || q == prev )
            {
                ++cnt ;
                prev = q ;
            }
            else
            {
                v.push_back( cnt ) ;
                cnt = 1  ;
                prev = q ;
            }
        }
        if( cnt  ) v.push_back( cnt ) ;
        vector < ll > v_bin ;
        for(int i = 0 ; i < v.size() ; i ++ )
        {
            v_bin.push_back(v[i]) ;
        }
        for( int i = 1 ; i < v_bin.size() ; i ++ )
        {
            v_bin[i] = v_bin[i] + v_bin[i-1] ;
        }
        ll L = 0 , R = v_bin.size() - 1 , mid = 0 ;
        ll delim = 0 , K = n / 2 ;
        while( L <= R )
        {
            mid = ( L + R ) / 2 ;
            if( v_bin[mid] > K ) R = mid - 1 ;
            else if ( v_bin[mid] <= K )
            {
                delim = max( delim , mid ) ;
                L = mid + 1 ;
            }
        }
        if( delim <= 2 )
        {
            cout << 0 << " " << 0 << " "  << 0 << '\n' ;
        }
        else
        {
            ll g = v[0] ;
            ll S = v[1] + v[2] ;
            ll B = 0 ;
            for( int i = 3 ;  i <= delim ; i ++ )
            {
                B += v[i] ;
            }
            if ( g < S && g < B )
            {
                cout << g << " " << S << " " << B << '\n' ;
            }
            else
            {
                cout << 0 << " " << 0 << " "  << 0 << '\n' ;
            }
        }
    }
    return 0     ;
}
