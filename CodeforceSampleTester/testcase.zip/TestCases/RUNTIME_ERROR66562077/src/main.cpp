#include <bits/stdc++.h>
using namespace std;

int t;
int n;
const int maxn = 4e5 + 107;
int A[maxn];

int main()
{
    ios_base::sync_with_stdio(0);cin.tie(0);
    freopen("a.in","r",stdin);

    cin>>t;
    while(t--){
        cin>>n;
        for(int i=1;i<=n;i++){
            cin>>A[i];
        }
        A[0]=A[1];

        int g=0;
        int s=0;
        int b=0;

        int j=1;

        while(A[j]==A[j-1]){
            g++;
            j++;
        }
        s++;
        j++;
        while( (A[j]==A[j-1] || s<=g) && j<n/2 ){
            s++;
            j++;
        }
        //cout<<g+s<<" "<<j<<" ";

        int mark;
        for(int i=n/2+1;i>0;i--){
            if(A[i]!=A[i-1]){
                mark=i;
                break;
            }
        }
        b = mark - j;

        if(b>g){
            cout<<g<<' '<<s<<' '<<b<<'\n';
        }else{
            cout<<'0'<<' '<<'0'<<' '<<'0'<<'\n';
        }

    }

    return 0;
}
