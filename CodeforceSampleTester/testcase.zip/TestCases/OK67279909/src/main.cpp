#include<iostream>
#include<algorithm>
#include<string>
#include<stack>
using namespace std;
const int maxn=1e5+5;
const int MOD = 998244353;
const int yzh = 998244353;
typedef long long ll;

ll quick_pow(ll a, ll b) {
    int ans = 1;
    while (b) {
        if (b&1) ans = ans*a%MOD;
        b >>= 1;
		a = a*a%MOD;   
    }
    return ans;
}

ll inv(ll a)
{
	return quick_pow(a,MOD-2)%MOD;
}

ll n;
ll anss;
ll p;
ll ans;
int main()
{
	cin>>n;
	for(ll i=0;i<n;i++)
	{
		cin>>p;
        ans = (ans+1)%MOD;
        ans = ans*100%MOD*inv(p)%MOD;
        //ans = ans*100%MOD*quick_pow(p, MOD-2)%MOD;
	}
	cout<<ans<<endl;
}
  		  	 						 	 	    		  	 	