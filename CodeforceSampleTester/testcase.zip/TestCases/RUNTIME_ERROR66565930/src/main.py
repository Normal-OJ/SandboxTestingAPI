import sys
sys.setrecursionlimit(5000)

memo = {'a': dict(), 'b': dict(), 'c': dict(), 'd': dict()}
memo['a'][0, 0, 0, 0] = True
memo['b'][0, 0, 0, 0] = True
memo['c'][0, 0, 0, 0] = True
memo['d'][0, 0, 0, 0] = True


def solvable(a, b, c, d, p):
    if (a, b, c, d) in memo[p]:
        return memo[p][a, b, c, d]

    if any(x < 0 for x in (a, b, c, d)):
        return False

    if a > b + 2 or d > c + 2:
        return False

    if b > a + c + 1 or c > b + d + 1:
        return False

    res = False
    if a == 1 and b == 0 and c == 0 and d == 0 and p == "b":
        res = True
    elif a == 0 and b == 1 and c == 0 and d == 0 and p in "ac":
        res = True
    elif a == 0 and b == 0 and c == 1 and d == 0 and p in "bd":
        res = True
    elif a == 0 and b == 0 and c == 0 and d == 1 and p == "c":
        res = True

    if res:
        memo[p][a, b, c, d] = True
        return res

    if p == "b" and solvable(a - 1, b, c, d, "a"):
        res = True
    elif p in "ac" and solvable(a, b - 1, c, d, "b"):
        res = True
    elif p in "bd" and solvable(a, b, c - 1, d, "c"):
        res = True
    elif p == "c" and solvable(a, b, c, d - 1, "d"):
        res = True

    memo[p][a, b, c, d] = res
    return res


def backwards(a, b, c, d, p):
    if a == 0 and b == 0 and c == 0 and d == 0:
        return []
    if p == "a":
        if b > 0 and memo['b'][a, b - 1, c, d]:
            return [1] + backwards(a, b - 1, c, d, 'b')
    if p == "b":
        if a > 0 and memo['a'][a - 1, b, c, d]:
            return [0] + backwards(a - 1, b, c, d, 'a')
        if c > 0 and memo['c'][a, b, c - 1, d]:
            return [2] + backwards(a, b, c - 1, d, 'c')
    if p == "c":
        if b > 0 and memo['b'][a, b - 1, c, d]:
            return [1] + backwards(a, b - 1, c, d, 'b')
        if d > 0 and memo['d'][a, b, c, d - 1]:
            return [3] + backwards(a, b, c, d - 1, 'd')
    if p == "d":
        if c > 0 and memo['c'][a, b, c - 1, d]:
            return [2] + backwards(a, b, c - 1, d, 'c')


def solve(a, b, c, d):
    if a > b + 2 or d > c + 2:
        return None

    if b > a + c + 1 or c > b + d + 1:
        return None

    if solvable(a, b, c, d, "a"):
        return backwards(a, b, c, d, "a")
    if solvable(a, b, c, d, "b"):
        return backwards(a, b, c, d, "b")
    if solvable(a, b, c, d, "c"):
        return backwards(a, b, c, d, "c")
    if solvable(a, b, c, d, "d"):
        return backwards(a, b, c, d, "d")

    return None


a, b, c, d = map(int, input().split())
ans = solve(a, b, c, d)

if ans:
    print("YES")
    print(" ".join(map(str, ans)))
else:
    print("NO")
