for i in range(int(input())):
	s = [c for c in input()]
	i = 0
	n = len(s)
	while i < n:
		if s[i] == '?':
			prv = 'd' if i == 0 else s[i-1]
			nxt = 'e' if i+1 >= n else s[i+1]
			for x in ['a', 'b', 'c']:
				if prv != x and nxt != x:
					s[i] = x
					break
		else: 
			i += 1

	# check whether it is not beutiful
	ok = True
	for i in range(n-1):
		if s[i] == s[i+1]:
			ok = False
			break
	if ok == True:
		print("".join(s))
	else:
		print(-1)
