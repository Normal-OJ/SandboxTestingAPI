from sortedcontainers import SortedList
for _ in range(int(input())) :
	n = int(input())
	arr = list(map(int,input().split()))
	res = SortedList()
	track = dict()
	j = 1
	sum = 0
	ans = ""
	for i in arr :
		track[i] = j
		j+=1
 

	for i in range(n) :
		po = track[i+1]
		sum+=po
		k = i + 1
		res.add(po)
		# print(res)
		a = res[0]
		s = 2*a + (k-1)
		sn = (s*k)//2
		if sn == sum :
			ans+='1'
		else :
			ans+='0'
 
	print(ans)
