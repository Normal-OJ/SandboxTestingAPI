n = int(input())
ret = 0
inputs = input().split()
for i in inputs:
    b = int(i)
    b = 100/b
    ret*=b
    ret+=b

print(int(ret)%998244353)
    
