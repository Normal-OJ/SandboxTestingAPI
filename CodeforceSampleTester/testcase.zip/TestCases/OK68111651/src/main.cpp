#include <bits/stdc++.h>
#define ll long long
#define endl '\n'
using namespace std;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    int q;
    cin >> q;
    while (q--)
    {
        int n;
        cin >> n;
        vector<int> a(n);
        for (int i = 0; i < n; i++)
        {
            cin >> a[i];
            a[i]--;
        }
        vector<int> pos(n);
        for (int i = 0; i < n; i++)
            pos[a[i]] = i;
        vector<bool> ans(n, false);
        int mn = n + 1, mx= -1;
        for (int i = 0; i < n; i++)
        {
            mx = max(mx, pos[i]);
            mn = min(mn, pos[i]);
            if (mx - mn == i)
                ans[i] = true;
        }
        for (bool i : ans)
            cout << i;
        cout << endl;
    }
    return 0;
}
