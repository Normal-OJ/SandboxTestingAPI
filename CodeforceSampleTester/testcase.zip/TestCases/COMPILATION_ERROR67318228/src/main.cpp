#include <bits/stdc++.h>
using namespace std;
#define FOR(z,l,n) for(int z=l;z<n;z++)
#define pii pair<int,int>
#define mp make_pair
#define ll long long int
#define pll pair<long long,long long>
const bool debug = true;
void printl(auto itb, auto ite){
    if(debug){
        for(auto it = itb;it!=ite;it++){
            cout<<*it<<" ";
        }
        cout<<endl;
    }
}

int dp[2001][2001];
int cnt[2001];
int M=998244353;
int pow(int n){
    if(n==0)return 1;
    if(n==1)return 2;
    long long int x = pow(n/2);
    int ans = (((x*x)%M)*pow(n&1))%M;
}
bool iseq(char a , char b){
    return a==b || a=='?';
}
int get_dep(string& s, int l,int r){
    if(l>=r)return 0;
    if(dp[l][r]!=-1)return dp[l][r];
    long long int ans = 0;
    if(iseq(s[l-1],')') && iseq(s[r-1],')'))
        ans += get_dep(s,l+1,r);
    if(iseq(s[l-1],'(') && iseq(s[r-1],'('))
        ans += get_dep(s,l,r-1);
    if(iseq(s[l-1],'(') && iseq(s[r-1],')'))
        ans += (get_dep(s,l+1,r-1) + pow(cnt[r-1]-cnt[l]));
    if(iseq(s[l-1],')') && iseq(s[r-1],'('))
        ans += get_dep(s,l+1,r-1);
    ans=ans%M;
    dp[l][r]=ans;
    //cout<<l<<" "<<r<<" "<<ans<<endl;
    return ans;
}
int main(){
    {
        string s;
        cin>>s;
        int n=s.length();
        for(int i=0;i<=n;i++)
            for(int j=i+1;j<=n;j++)
                dp[i][j]=-1,cnt[i]=0;
        for(int i=1;i<=n;i++) 
            cnt[i]=cnt[i-1]+(s[i-1]=='?');
        //printl(cnt,cnt+n+1);
        cout<<get_dep(s,1,n)<<endl;
    }
}