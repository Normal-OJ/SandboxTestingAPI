#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int lp = 998244353;
ll n=0, d=1;
void addd(ll x){ //add the following day, e(x+1) =  (e(x)+ 1)*p(x+1) + (1-p(x+1))*(e(x)+e(x+1)+1) -> p(x+1)e(x+1) =e(x) + 1
	n += d;
	n = (n*100) % lp;
	d = (d*x) % lp;
}
pair<ll,ll> solve(ll a, ll b, ll m){ //solving ax+by == 1(mod m), a,b known
	if (a == 0) return {0,1};

	pair<int,int> lower = solve(b%a, a, m);
	int nx = lower.first, ny = lower.second;
	
	ll y = nx % m;
	ll x = ((ny- (b/a)*y) % m + m) % m;

	return {x,y};
}
ll inv(ll x, ll m){
	pair<int,int> sol = solve(x,m,m);
	return sol.first;
}
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	
	int cnt,temp;
	queue<int> prob;
	cin >> cnt;
	for (int i=0; i<cnt; i++){
		cin >> temp;
		prob.push(temp);
	}
	while (!prob.empty()){
		temp = prob.front();
		prob.pop();
		addd(temp);
	}
	
	cout << (n*inv(d,lp))%lp << endl;
	/*
	int sp = 17;
	for (int i=1; i<sp; i++){
		cout << inv(i,sp) << endl;
	}
	*/ //correct:)
	return 0;
}
