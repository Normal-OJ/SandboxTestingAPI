#include <bits/stdc++.h>
#define pb push_back
using namespace std;#define ll long long
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
ll p[200005];


ll dp[200005];
const ll mod=998244353;
ll ksm(ll a,ll b)
{
	ll res=1;
	while(b)
	{
		if(b%2==1)
		res=res*a%mod;
		a=a*a%mod;
		b/=2;
	}
	return res%mod;
}
int main(int argc, char** argv) {
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&p[i]);
	}

	for(int i=0;i<=n;i++)
	{
		dp[i+1]=(100*(ksm(p[i+1],mod-2))%mod+((dp[i]%mod*100)%mod*ksm(p[i+1],mod-2))%mod)%mod;
	}
	printf("%d",dp[n]%mod);
	return 0;
}