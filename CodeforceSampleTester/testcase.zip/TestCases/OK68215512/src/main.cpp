#include <bits/stdc++.h>
#define all(x) (x).begin(), (x).end()
#define For(i,n) for (int i=0;i<n;i++)
#define fst first
#define scd second
#define pb push_back
using namespace std;
using ll=long long int;
using vll=vector<ll>;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    //cout<<setprecision(15)<<fixed;
    //ifstream cin(""); ofstream cout("");
    int t; cin >> t;
    for (int k = 0; k < t; k++)
    {
        int n; cin >> n;
        vll in(n);
        for (int i = 0; i < n; i++)
            cin >> in[i];
        vll groups;
        ll cnt = 0, cur = in[0];
        for (int i = 0; i < n; i++)
        {
            if (in[i] == cur) cnt++;
            else
            {
                groups.push_back(cnt);
                cur = in[i];
                cnt = 1;
            }
        }
        groups.push_back(cnt);
        vll right_groups;
        ll sum = 0;
        for (auto &x : groups)
        {
            sum += x;
            if (sum <= n / 2)
            {
                right_groups.push_back(x);
            }
            else
            {
                sum -= x;
                break;
            }
        }
        int L = right_groups.size();
        if (L < 3)
        {
            cout << 0 << " " << 0 << " " << 0 << endl;
        }
        else
        {
            ll g = right_groups[0];
            ll s = 0, i = 1;
            while (s <= g && i < L)
            {
                s += right_groups[i];
                i++;
            }
            ll b = 0;
            for (int j = i; j<L; j++)
            {
                b += right_groups[j];
            }
            if (b <= g)
            {
                cout << 0 << " " << 0 << " " << 0 << endl;
            }
            else
            {
                cout << g << " " << s << " " << b << endl;
            }
        }
    }
}