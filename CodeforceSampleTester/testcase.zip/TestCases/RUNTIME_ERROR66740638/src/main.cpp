#include <bits/stdc++.h>
using namespace std;

int main() {
  int n;
  cin >> n;

  for (int i = 0; i < n; i++) {
    int k;
    cin >> k;

    int table[k];
    for (int s = 0; s < k; s++) {
      cin >> table[s];
    }
    int indexes[k];
    int begins[k];
    int ends[k];
    for (size_t s = 0; s < k; s++) {
      indexes[table[k]-1] = table[k]-1;
    }
    begins[0] = indexes[0];
    ends[0] = indexes[0];
    cout << 1;
    for (size_t s = 1; s < k; s++) {
      begins[s] = min(begins[s-1], indexes[s]);
      ends[s] = max(begins[s-1], indexes[s]);
      if (ends[s] - begins[s] == s)
      {
        cout << 1;
      }
      else
      {
        cout << 0;
      }
    }
    cout << endl;
  }
  return 0;
}
