import sys
abcd = list(map(int,input().split()))

if sum(abcd) == 1:
    print ("YES")
    for i in range(4):
        if abcd[i] != 0:
            print (i)
            break
    sys.exit()

for loop in range(4):

    for loop2 in range(4):

        ABCD = abcd.copy()
        p = [None] * sum(abcd)
        lpn = sum(abcd)-2
        
        p[0] = loop
        ABCD[loop] -= 1
        ind = 1
        flag = True
        

        p[-1] = loop2
        ABCD[loop2] -= 1
        lpn = sum(abcd)-2 

        if p[-1] == 0:
            p[-2] = 1
            ABCD[1] -= 1
            lpn -= 1
        if p[-1] == 3:
            p[-2] = 2
            ABCD[2] -= 1
            lpn -= 1
                   
            
        
        for i in range(lpn):

            if p[ind-1] == 0:
                p[ind] = 1
                ind += 1
                ABCD[1] -= 1

            elif p[ind-1] == 1:
                if ABCD[0] > 0:
                    p[ind] = 0
                    ABCD[0] -= 1
                    ind += 1
                else:
                    p[ind] = 2
                    ABCD[2] -= 1
                    ind += 1

            elif p[ind-1] == 2:
                if ABCD[3] > 0:
                    p[ind] = 3
                    ABCD[3] -= 1
                    ind += 1
                else:
                    p[ind] = 1
                    ABCD[1] -= 1
                    ind += 1

            else:
                p[ind] = 2
                ABCD[2] -= 1
                ind += 1

        for i in range(4):
            if ABCD[i] != 0:
                flag = False

        for i in range(5):
            i += 1
            if abs(p[-1 * i]-p[-1 * i - 1]) != 1:
                flag = False
                break

        if flag:
            print ("YES")
            print (" ".join(map(str,p)))
            sys.exit()

print ("NO")
              