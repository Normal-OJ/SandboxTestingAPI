#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
int t,n;
int main()
{
    //freopen(".in","r",stdin);
    //freopen(".out","w",stdout);
    ios::sync_with_stdio(0),cin.tie(0);
    int i,j,k,g,s,b;
    cin>>t;
    while(t--)
    {
        cin>>n;
        int a[n+1];
        for(i=1; i<=n; i++)
            cin>>a[i];
        i=1;
        while(a[i]==a[i+1]&&i+1<=n)
            i++;
        g=i;
        j=i+1;
        while((a[j]==a[j+1]||j-i<=g)&&j+1<=n)
            j++;
        s=j-i;
        k=n/2;
        while(a[k]==a[k+1])
            k--;
        if(k-j>g)
            cout<<g<<' '<<s<<' '<<k-j<<endl;
        else
            cout<<"0 0 0\n";
    }
    return 0;
}
