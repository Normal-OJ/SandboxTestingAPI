t = int(input())
for _ in range(t):
    n = int(input())
    seq = input().split()
    d = {}
    for i in range(n):
        a = int(seq[i])
        if a == ' ':
            continue
        d[a] = i
    soln = [0]*n
    r,l = d[1],d[1]
    for i in range(1,n+1):
        pos = d[i]
        if pos > r:
            r = pos
        if pos < l:
            l = pos
        
        if i == (r-l+1):
            soln[i-1] = 1
        
    print(('').join(soln))
        