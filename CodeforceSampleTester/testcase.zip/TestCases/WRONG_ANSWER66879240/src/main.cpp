#include <bits/stdc++.h>

using namespace std;

#define FOR(i, a, b) for(int i = a; i < b; i++)

typedef vector<int> vi;
typedef vector<double> vd;

void print(vi &p) {
	FOR(i, 0, p.size())
		printf("%d ", p[i]);
	printf("\n");
}

int mod = 998244353;

int main() {
	int n;
	cin >> n;

	vd p(n);
	FOR(i, 0, n) {
		scanf("%lf", &p[i]);
		p[i] /= 100.0;
	}

	double num = 1.0;
	double curr = 1.0;
	FOR(i, 0, n - 1) {
		curr *= p[i];
		num += curr;
	}

	double den = 1;
	FOR(i, 0, n) {
		den *= p[i];
	}

	int ans = (int)round(num / den) % mod;

	// cout << num << " " << den << endl;
	cout << ans << endl;

	return 0;
}