# -*- coding: utf-8 -*-
"""
Created on Sun Dec 22 23:24:12 2019

@author: PC
"""

def bstring(s):
    
    word = ''
    n = len(s)
    for i in range(n-1):
        if s[i] == s[i+1] and s[i] != "?" and s[i+1] != "?":
            return -1
    S = []
    
    for letter in s:
        S.append(letter)
    
    if S[0] == "?":
        
        if S[1] in ("a" , "b"):
                S[0] = "c"
            elif  S[1] in ("a" , "c"):
                S[0] = "b"
            elif  S[1] in ("c" , "b")::
                S[0] = "a"
            else:
                S[0] = "a"
                
    for i in range(1, n):
        
        if S[i] == "?" and i > 0:
            
            if S[i-1] in ("a" , "b") and S[i+1] in ("a" , "b", "?"):
                S[i] = "c"
            elif  S[i-1] in ("a" , "c") and S[i+1] in ("a" , "c", "?"):
                S[i] = "b"
            elif  S[i-1] in ("c" , "b") and S[i+1] in ("c" , "b", "?"):
                S[i] = "a"
        
    
            
                
    for element in S:
        word = word + element
    
    return word


import os
import sys
from atexit import register
from io import BytesIO

sys.stdin = BytesIO(os.read(0, os.fstat(0).st_size))
sys.stdout = BytesIO()
register(lambda: os.write(1, sys.stdout.getvalue()))

input = lambda: sys.stdin.readline().rstrip('\r\n')



