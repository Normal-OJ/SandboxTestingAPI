#include<bits/stdc++.h>
using namespace std;
const int maxn=4e5+5;
int t1[maxn]; int t2[maxn];
int main(void)
{
	int a,b,c,d;
	memset(t1,-1,sizeof(t1));
	memset(t2,-1,sizeof(t2));
	scanf("%d%d%d%d",&a,&b,&c,&d);
	int n=a+b+c+d;
	bool f1=true; bool f2=true;
	for(int i=1,j=1;j<=a+c;i+=2,j++)
	{
		if(j<=a) t1[i]=0;
		else t1[i]=2;
	}
	for(int i=2,j=1;j<=b+d;i+=2,j++)
	{
		if(j<=b) t1[i]=1;
		else t1[i]=3;
	}
//	for(int i=1;i<=n;i++) printf("t==%d\n",t1[i]);
	for(int i=2,j=1;j<=a+c;i+=2,j++)
	{
		if(j<=a) t2[i]=0;
		else t2[i]=2;
	}
	for(int i=1,j=1;j<=b+d;i+=2,j++)
	{
		if(j<=b) t2[i]=1;
		else t2[i]=3;
	}
	
	
	for(int i=1;i<=n;i++)
	{
		if(t1[i]==-1) f1=false;
		if(i<=n-1&&abs(t1[i]-t1[i+1])!=1) f1=false;
	}
	for(int i=1;i<=n;i++)
	{
		if(t2[i]==-1) f2=false;
		if(i<=n-1&&abs(t2[i]-t2[i+1])!=1) f2=false;
	}
	if(f1)
	{
		printf("YES\n");
		for(int i=1;i<=n;i++)
		{
			printf("%d%c",t1[i],i==n?'\n':' ');
		}
		return 0;
	}
	if(f2)
	{
		printf("YES\n");
		for(int i=1;i<=n;i++)
		{
			printf("%d%c",t2[i],i==n?'\n':' ');
		}
		return 0;
	}
	printf("NO\n");
	return 0;
}