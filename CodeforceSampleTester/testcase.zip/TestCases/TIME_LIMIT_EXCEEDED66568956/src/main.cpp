//#pragma comment(linker, "/stack:200000000")
//#pragma GCC optimize("O3")
//#pragma GCC optimization ("unroll-loops")
//#pragma GCC target ("avx2")
#include <iostream>
#include <vector>
#include <string>
#include <stdio.h>
#include <algorithm>
#include <queue>
#include <set>
#include <map>
#include <cmath>
#include <iomanip>
#include <random>
//#include <iterator>
#define ll long long
#define ld long double
#define vi vector < int >
#define PB push_back
#define F first
#define S second

using namespace std;

#define vpi vector<pair<int,int>>
#define pi = pair<int, int>;
#define vvi vector<vector<int>>
#define vvll vector<vector<long long>>
#define vll vector<long long>
#define vpll vector<pair<long long, long long>>

const long long N = 2e5+5, K = 505, inf = 1e9 + 6, mod = 1e9;

vector < int > vals[N];


int main() {
   // freopen("input.txt", "r", stdin);
   // freopen("output.txt", "w", stdout);
    ios_base::sync_with_stdio(0); cin.tie(0);
    int a, b, c, d, x, y, z, w; cin >> x >> y >> z >> w;
    for(int f = 0; f < 2; f++){
        a = x; b = y; c = z; d = w;
        vector < int > ans;
        bool i_do = 0;
        while(f == 1 && a > 0 || f == 0 && b > 0){
            if(f){ans.PB(0); a--;}
            else{ans.PB(1); b--;}
            f = 1 - f;
            i_do = 1;
        }
    //    if(a > 0 || !i_do){continue;}
        
        i_do = 0;
        while(f == 1 && c > 0 || f == 0 && b > 0){
            if(f){ans.PB(2); c--;}
            else{ans.PB(1); b--;}
            f = 1 - f;
            i_do = 1;
        }
        if(b > 0 || !i_do){continue;}
        
        i_do = 0;
        while(f == 1 && c > 0 || f == 0 && d > 0){
            if(f){ans.PB(2); c--;}
            else{ans.PB(3); d--;}
            f = 1 - f;
            i_do = 1;
        }
        if(c > 0 || d > 0){ continue;}
        
        cout << "YES\n";
        for(auto x : ans) cout << x << " ";
        return 0;
    }
    cout << "NO";
}
