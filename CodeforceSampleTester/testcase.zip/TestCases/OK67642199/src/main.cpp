#include<bits/stdc++.h>
using namespace std;
const int mod=998244353 ;
#define ll long long
ll n,p[200010],dp[200010];
ll inv=828542813;
ll binpow(ll a,ll x){
	ll ans=1;
	while(x){
		if(x%2==1) { ans=(ans*a)%mod; x--;}
		else  {
			a=(a*a)%mod;
			x=x>>1;
		}
	}
	return ans;
}
int main(){
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>p[i];
	}

	ll ans=0;
	   for(int i=n-1;i>=0;i--){
	   	if(i==n-1) dp[i]= (100*binpow(p[i],mod-2)) %mod;
	   	else dp[i]= (dp[i+1] * ((100*binpow(p[i],mod-2))%mod)) %mod;
	   	ans+=dp[i];
	   	ans= ans% mod;
	   }
	   cout<<ans<<endl;





	
}
