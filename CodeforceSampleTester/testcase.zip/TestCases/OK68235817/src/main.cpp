#include<iostream>
#include<cstdio>
#include<cstring>
#define maxn 100005
using namespace std;
char s[maxn];
int a[maxn];
int t;
int main( )
{
	cin>>t;
	while(t--)
	{
		memset(s,0,sizeof(s));
		cin>>s;
		int len=strlen(s);
		if(s[0]=='?')
		{
			if(s[1]!='a') s[0]='a';
			if(s[1]!='b') s[0]='b';
			if(s[1]!='c') s[0]='c';
		}
		for(int i=1;i<len-1;i++)
		{
			if(s[i]=='?')
			{
				if(s[i-1]!='a'&&s[i+1]!='a') s[i]='a';
				else if(s[i-1]!='b'&&s[i+1]!='b') s[i]='b';
				else if(s[i-1]!='c'&&s[i+1]!='c') s[i]='c';
			}
		}
		if(s[len-1]=='?')
		{
			if(s[len-2]!='a') s[len-1]='a';
			if(s[len-2]!='b') s[len-1]='b';
			if(s[len-2]!='c') s[len-1]='c';
		}
		int flag=1;
		for(int i=0;i<len;i++)
		{
			if(s[i]=='?'||s[i]==s[i+1]) 
			{
				flag=0;
				break;
			}
		}
		if(flag)
		cout<<s<<endl;
		else
		cout<<-1<<endl;
	}
	return 0;
}
   	   	    	  	 					 	 	    	