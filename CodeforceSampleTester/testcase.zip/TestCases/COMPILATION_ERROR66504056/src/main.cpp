#pragma gcc target("avx,avx2")
#pragma gcc optimize("ofast,fast-math")
#include <map>
#include <set>
#include <cmath>
#include <ctime>
#include <queue>
#include <stack>
#include <bitset>
#include <cstdio>
#include <string>
#include <vector>
#include <climits>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>
#define mid (s+e>>1)
#define id(x) (x-'a')
#define sca(aa) scanf("%d",&aa)
#define pp(x) x*x
#define ls(x) x<<1
#define rs(x) x<<1|1
#define lson(x) ls(x),s,mid
#define rson(x) rs(x),mid + 1,e
using namespace std;
typedef long long LL;
typedef unsigned long long ull;
const LL inf = 1e8;
const LL N = 200003;
const double eps = 1e-10;
const ull strmod = 212370440130137957ll;
const LL strp = 233;
inline int read() {
	char ch = getchar(); int x = 0, f = 1;
	while (ch < '0' || ch > '9') {
		if (ch == '-') f = -1;
		ch = getchar();
	} while ('0' <= ch && ch <= '9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	} return x * f;
}
map<int, int,greater<> >p;
map<int, int,greater<> >::iterator it, ed;
int main()
{
	int n, x;
	int T, s, b, g;
	int ans = 0, res;
	T = read();
	while (T--)
	{
		p.clear();
		n = read();
		s = b = g = 0, x = 0;
		for (int i = 1; i <= n; i++)
			p[read()]++;
		if (n <= 5 || p.size() < 3) { printf("0 0 0\n"); continue; }
		ed = p.begin();
		while (x < (n >> 1) && ed != p.end())
			x += ed->second, ed++;
		if (x > (n >> 1))
			ed--, x -= ed->second;
		it = p.begin();
		int cnt = 0;
		while (it != ed)
			it++, cnt++;
		if (cnt < 3) { printf("0 0 0\n"); continue; }
		it = p.begin();
		while (g < x / 3)
			g += it->second, it++;
		if (g > x / 3)
			it--, g -= it->second;
		if (g == 0) { printf("0 0 0\n"); continue; }
		s = it->second;
		b = x - s - g;
		printf("%d %d %d\n", g, s, b);
	}

}

/*

*/