#include <cstdio>
using namespace std;
typedef long long ll;
#define Mod 998244353
int n, a[200005];
ll dp[200005];
ll Pow(ll bas, int tms)
{
	ll res = 1;
	while (tms)
	{
		if (tms & 1)
		{
			res = (res*bas) % Mod;
		}
		tms >>= 1;
		bas = (bas*bas) % Mod;
	}
	return res;
}
int main()
{
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i)
	{
		scanf("%d", &a[i]);
		dp[i] = (1 + dp[i - 1]) * 100 % Mod*Pow(a[i], Mod - 2) % Mod;
	}
	printf("%lld", dp[n]);
	return 0;
}
