q=int(input())
for _ in range(q):
	n=int(input())
	d={}
	arr=list(map(int,input().split()))
	for i in arr:
		d[i]=d.get(i,0)+1
	arr=sorted(list(d.keys()),reverse=True)
	g=d[arr[0]]
	s=0
	b=0
	i=1
	while(i<len(arr)):
		if s>g:
			break
		s+=d[arr[i]]
		i+=1
	while(i<len(arr)):
		if b+d[arr[i]]+s+g<=n//2:
			b+=d[arr[i]]
			i+=1
		else:
			break
	if g<s and g<b:
		print(g,s,b)
	else:
		print(0,0,0)
	
