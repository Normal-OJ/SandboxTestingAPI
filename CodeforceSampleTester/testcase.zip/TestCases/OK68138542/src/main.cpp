#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <unordered_map>
#include <map>
#include <unordered_set>
#include <set>
#include <list>
 
using namespace std;
 
#define _ ios_base::sync_with_stdio(0);cin.tie(0);
 
const long long INF = 0x3f3f3f3f;
 
int main() { _

	int a, b, c, d;

	cin >> a >> b >> c >> d;
	int n = a + b + c + d;

	list<int> solution;

	int x = 0;
	if(a != 0) {

		x = 0;
		a -= 1;
	}
	else if(a == 0 && b != 0) {

		x = 1;
		b -= 1;
	}
	else if(b == 0 && c != 0) {

		x = 2;
		c -= 1;
	}
	else {

		x = 3;
		d -= 1;
	}

	solution.push_back(x);

	bool flag1 = true, flag2 = true;
	while(1) {

		if(a == 0 && b == 0 && c == 0 && d == 0) break;
		int first = solution.front(), last = solution.back();
		flag1 = true;
		flag2 = true;
		if(last == 0) {
			if(b == 0) {
				flag1 = false;
			}
			else {
				solution.push_back(1);
				b -= 1;
			}
		}
		else if(last == 1) {
			if(a == 0 && c == 0) {
				flag1 = false;
			}
			else if(a != 0) {

				solution.push_back(0);
				a -= 1;
			}
			else if(c != 0) {

				solution.push_back(2);
				c -= 1;
			}
		}
		else if(last == 2) {
			if(b == 0 && d == 0) {
				flag1 = false;
			}
			else if(b != 0) {

				solution.push_back(1);
				b -= 1;
			}
			else if(d != 0) {

				solution.push_back(3);
				d -= 1;
			}
		}
		else {
			if(c == 0) {
				flag1 = false;
			}
			else {
				solution.push_back(2);
				c -= 1;
			}
		}

		if(first == 0) {
			if(b == 0) {
				flag2 = false;
			}
			else {
				solution.push_front(1);
				b -= 1;
			}
		}
		else if(first == 1) {
			if(a == 0 && c == 0) {
				flag2 = false;
			}
			else if(a != 0) {

				solution.push_front(0);
				a -= 1;
			}
			else if(c != 0) {

				solution.push_front(2);
				c -= 1;
			}
		}
		else if(first == 2) {
			if(b == 0 && d == 0) {
				flag2 = false;
			}
			else if(b != 0) {

				solution.push_front(1);
				b -= 1;
			}
			else if(d != 0) {

				solution.push_front(3);
				d -= 1;
			}
		}
		else {
			if(c == 0) {
				flag2 = false;
			}
			else {
				solution.push_front(2);
				c -= 1;
			}
		}

		if(!flag1 && !flag2) break;
	}

	if(a != 0 || b != 0 || c != 0 || d != 0) {

		printf("NO\n");
	}
	else {

		printf("YES\n");
		int k = 0;
		for(auto &num : solution) {

			if(k == n - 1) {
				printf("%d\n", num);
			}
			else {
				printf("%d ", num);
			}
			k++;
		}
	}

	return 0;
}











