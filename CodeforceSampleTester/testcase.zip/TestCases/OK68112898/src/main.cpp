#include <bits/stdc++.h>
#define ll long long
#define endl '\n'
using namespace std;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    int q;
    cin >> q;
    while (q--)
    {
        int n;
        cin >> n;
        int need = n / 2;
        vector<int> a(n);
        for (int i = 0; i < n; i++)
            cin >> a[i];
        map<int, int> cnt;
        for (int i : a)
            cnt[i]++;
        vector<int> num;
        for (auto it : cnt)
            num.push_back(it.second);
        reverse(num.begin(), num.end());
        int g = num[0], s = 0, b = 0, i = 1;
        while (s <= g && i < (int)num.size())
        {
            s += num[i];
            i++;
        }
        while (b <= g && i < (int)num.size())
        {
            b += num[i];
            i++;
        }
        while (i < (int)num.size() && g + s + b + num[i] <= need)
        {
            b += num[i];
            i++;
        }
        if (g + s + b <= need && g < s && g < b)
            cout << g << ' ' << s << ' ' << b << endl;
        else
            cout << 0 << ' ' << 0 << ' ' << 0 << endl;
    }
    return 0;
}
