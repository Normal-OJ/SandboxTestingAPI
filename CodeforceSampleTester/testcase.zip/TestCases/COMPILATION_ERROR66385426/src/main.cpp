#include<bits/stdc++.h>
using namespace std;
int a[400040];
int main()
{
    int a,b,c,d,t1=0,t2=0,t3=0,i;
    cin>>a>>b>>c>>d;
    if(a+b+c+d==1)
    {
        cout<<"YES"<<endl;
        for(i=0;i<a;i++)cout<<"0";
        for(i=0;i<b;i++)cout<<"1";
        for(i=0;i<c;i++)cout<<"2";
        for(i=0;i<d;i++)cout<<"3";
        return 0;
    }
    if(a!=b)
    {
        t1=min(a,b);
        a-=t1;b-=t1;
    }
    else if(a!=0)
    {
        t1=a-1;
        a=1;b=1;
    }
    if(c!=d)
    {
        t2=min(c,d);
        c-=t2;d-=t2;
    }
    else if(c!=0)
    {
        t2=c-1;
        c=1;d=1;
    }
    if(b!=c)
    {
        t3=min(b,c);
        b-=t3;c-=t3;
    }
    else if(b!=0)
    {
        t3=b-1;
        b=1;c=1;
    }
    if(a>=1&&(c>=1||d>=1)&&b==0||(d>=1&&b>=1&&c==0)||a>1||b>1||c>1||d>1)
    {
        cout<<"NO";
        return 0;
    }
    cout<<"YES"<<endl;
    if(a==0&&b==1)
    {
        for(i=0;i<t1;i++)
        cout<<"1 0 ";
        cout<<"1 ";
    }
    else
    {
        if(a==1&&b==0) cout<"1 ";
        for(i=0;i<t1;i++)
        cout<<"0 1 ";
        if(a==1&&b==1)cout<<"0 1 ";
    }
    if(c==1)
    {
        cout<<"2 ";
        for(i=0;i<t3;i++) cout<<"1 2 ";
        for(i=0;i<t2;i++)
        cout<<"3 2 ";
        if(d==1)cout<<"3 ";
    }
    else
    {
        for(i=0;i<t3;i++) cout<<"2 1 ";
        if(d==1) cout<<"3 ";
        for(i=0;i<t2;i++)
        cout<<"2 3 ";

    }
}
