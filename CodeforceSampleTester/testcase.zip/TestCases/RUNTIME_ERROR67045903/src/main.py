t=int(input(""))

for i in range(t):
	l=int(input(""))
	s=''
	X= list(map(int, input("").split())) 
	for j in range(1,l+1):
		k=X.index(j)
		for z in range(k-j+1,k+1):
			if(z>=0 and z+j<n):
				if max(L[z:z+j])==j:
					s=s+str(j)
					break
	print(s)				





