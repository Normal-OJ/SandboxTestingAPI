a, b, c, d = map(int, input().split())
for st in range(4):
    list = [a, b, c, d]
    path = []
    while True:
        if list[st]==0:
            break
        list[st]-=1
        path.append(st)
        if st == 0:
            st=1
        elif st == 3:
            st=2
        elif st==1:
            if list[0]==0:
                st+=1
            else:
                st=0
        else:
            if list[3]==0:
                st-=1
            else:
                st+=1
    #print(list)
    if max(list)==0:
        print("YES")
        for i in range(len(path)):
            print(path[i], end="")
            if i!=len(path)-1:
                print(" ", end="")
            else:
                print("")
        exit(0)
print("NO")
