#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
int a_[8];
int num[400005], sum=0;
int fx[2] = {-1, 1};
bool find(){
	int a[8]={0};
	int i , j;
	for(j=1;j<5;++j){
		for(i=0;i<8;++i)
			a[i]=a_[i];
		if(!a[j]) continue;
		int index_ = j;
		sum=0;
		int min_ = 0x3f3f3f3f;
	    while (a[1] + a[2] + a[3] + a[4])
	    {
	        min_ = 0x3f3f3f3f;
	        int p = index_;
	        --a[index_];
	        num[sum++] = index_ - 1;
	        for (i = 0; i < 2; ++i)
	        {
	            if (a[index_ + fx[i]] == 0)
	                continue;
	            if (min_ > a[index_ + fx[i]])
	            {
	                min_ = a[index_ + fx[i]];
	                p = index_ + fx[i];
	            }
	        }
	        if (p == index_){
	        	break;
			}
	        index_ = p;
	    }
	    if(a[1]+a[2]+a[3]+a[4]==0) return 1;
	}
	return 0;
}
int main()
{
    int i, j, k;
    for (i = 1; i < 5; ++i)
    {
        cin >> a_[i];
    }
    if(find()){
    	printf("YES\n");
    	for(i=0;i<sum;++i)
    		printf("%d ",num[i]);
	}else printf("NO");
    return 0;
}
	   	 		   	  					 		   			