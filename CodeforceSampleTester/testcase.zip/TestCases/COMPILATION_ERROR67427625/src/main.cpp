#include <bits/stdc++.h>
#define ll long long int
 
using namespace std;
 
 
int main() {
	int t;
	cin >> t;
	while(t--) {
		string s;
		cin >> s;
		int flag = 0;
		int F[3];
		for(int i = 0; i < s.size(); i++) {
			F[0] = 1;
			F[1] = 1;
			F[2] = 1;
			if(s[i] == '?') {
				F[s[i - 1] - 'a'] = 0;
				F[s[i + 1] - 'a'] = 0;
				if(F[0]) {
					s[i] = 'a';
				} else if(F[1]) {
					s[i] = 'b';
				} else {
					s[i] = 'c';
				}
			} else {
				if(s[i] == s[i - 1]) {
					cout << -1 << endl;
					flag = 1;
					break;
				}
			}
		}
		if(!fl)
			cout << s << endl;
	}
	return 0;
}