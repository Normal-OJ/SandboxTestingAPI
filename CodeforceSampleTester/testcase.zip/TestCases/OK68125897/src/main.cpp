#include <iostream>
#include <algorithm>
#include <stdio.h>
#include <math.h>
#include <bits/stdc++.h>

using namespace std;

int s, l, u, k, q, n;
int t[400400], a[400400];

void slove() {
    cin >> n;
    s = 0; l = 0; u = 1;
    for ( int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    for ( int i = 2; i <= n; i++) {
        if ( a[i] != a[i - 1] ) {
            if ( s + u <= n / 2 ) {
                s = s + u;
                l++; t[l] = u; u = 1;
            }
            else {
                break;
            }
        }
        else {
            u++;
        }
    }
    if ( l >= 3 ) {
        k = 0;
        for ( int i = 2; i <= l; i++) {
            k = k + t[i];
            if ( k > t[1] ) {
                break;
            }
        }
        if ( k > t[1] && s - k - t[1] > t[1] ) {
            cout << t[1] << " " << k << " " << s - k - t[1] << endl;
        }
        else {
            cout << 0 << " " << 0 << " " << 0 << endl;
        }
    }
    else {
        cout << 0 << " " << 0 << " " << 0 << endl;
    }
}

int main () {
    cin >> q;
    while (q--) {
        slove();
    }
}
