#include<bits/stdc++.h>
using namespace std;

#define Fast ios_base::sync_with_stdio(0); cin.tie(0);
#define ll long long

bool cmp(pair<string, int>x, pair<string,int> y) {
    if (x.second == y.second) return x.first < y.first;
    return x.second > y.second;
}

int main() {
    #ifdef FariD
        freopen("in.txt", "r", stdin);
        freopen("out.txt", "w", stdout);
    #endif
    
    Fast
    int t;
    
    cin >> t;
    
    while( t-- ) {
        int n;
        
        cin >> n;
        
        int arr[n+5];
        int pos[n + 5];
        
        for( int i=1; i<=n; i++ ) {
            cin >> arr[i];
            pos[arr[i]] = i;
        }
        int mx= -1, mn = 1e9;
        for( int i=1; i<=n; i++ ) {
            mx = max(mx, pos[i]);
            mn = min(mn, pos[i]);
            
            if( mx-mn + 1 == i ) cout << 1;
            else cout << 0;
        }
        cout << endl;
        
    }
    
    return 0;

}
 		 	 		 		 	  	 		   			     	