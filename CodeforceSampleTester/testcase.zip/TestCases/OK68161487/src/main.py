'''input
1
50
3
10 20 50
'''
from sys import stdin,stdout
read = lambda : map(int,stdin.readline().split())
I = lambda: stdin.readline()
m = 998244353
n = int(I())
arr = tuple(read())
p = 1
fac = 1
s1 = s2 = 0
pows = [1]
for i in range(n):
	pows.append(pows[-1]*100%m)

for ind,i in enumerate(arr):
	fac = p*(100-i)*pows[n-ind-1]
	s1 = (s1 + fac*(ind+1))%m
	s2 = (s2 + fac)%m
	p = (p*i)%m
s1 = (s1+p*n)%m
s0 = pow(100,n,m)
p,q = s1,s0-s2
div,mod = divmod(p,q)
if mod == 0:
	print(div)
else:
	q1 = pow(q,m-2,m)
	print(p*q1%m)
