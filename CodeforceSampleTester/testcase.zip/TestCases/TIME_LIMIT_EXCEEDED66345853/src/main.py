a,b,c,d = map(int,input().split())
x, i, s = a*['0']+b*['1']+c*['2']+d*['3'], 0, ''
l = len(x)
while True:
	if '0' in x:
		s += '0'
		x.remove('0')
		if '1' in x:
			s += '1'
			x.remove('1')
		else:
			break
	else:
		break
while True:
	if '2' in x:
		s += '2'
		x.remove('2')
		if '3' in x:
			s += '3'
			x.remove('3')
		else:
			break
	else:
		break


if len(s)==l:
	print("YES")
	for i in s:
		print(i,end=' ')
else:
	print("NO")