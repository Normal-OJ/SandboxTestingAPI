#include <string.h>
#include <assert.h>
#include <cassert>
#include <unordered_map>

#include <sstream>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <bitset>
#include <algorithm>
#include <iostream>
#include <stack>
#include <queue>
#include <set>

#include <map>
#include <vector>
#include <string>
#include <stdlib.h>
#include <cassert>

#define ll long long
#define clr(x) memset(x,0,sizeof(x))
#define _clr(x) memset(x,-1,sizeof(x))
#define fr(i,a,b) for(int i = a; i < b; ++i)
#define frr(i,a,b) for(int i = a; i > b; --i)
#define pb push_back
#define sf scanf

#define pf printf
#define mp make_pair
#define N 3000

const int mod = 998244353;

using namespace std;


//string s;
char s[N];
int dp1[N][N],dp2[N][N];

void sol(){
    clr(dp2);
    clr(dp1);
    int n = strlen(s+1);
   // .size();
    //int n = s.size();

    dp1[0][0] = 1;
    dp2[n+1][0] = 1;

    for(int i = 0; i <= n;++i) {
        for(int j = 0; j <=n; ++j) {
            if(s[i]=='(') {
                if(j)
                    dp1[i][j] = (dp1[i][j]+dp1[i-1][j-1])%mod;
            }
            else if(s[i]==')') {
                dp1[i][j] = (dp1[i][j]+dp1[i-1][j])%mod;
            }
            else {
                dp1[i][j] = (dp1[i][j]+dp1[i-1][j])%mod;
                if(j) {
                    dp1[i][j] = (dp1[i][j]+dp1[i-1][j-1])%mod;
                }
            }
        }
    }

    for(int i = n; i >=0;--i) {
        for(int j = 0; j <=n; ++j) {
            if(s[i]==')') {
                if(j)
                    dp2[i][j] = (dp2[i][j]+dp2[i+1][j-1])%mod;
            }
            else if(s[i]=='(') {
                dp2[i][j] = (dp2[i][j]+dp2[i+1][j])%mod;
            }
            else {
                dp2[i][j] = (dp2[i][j]+dp2[i+1][j])%mod;
                if(j)
                    dp2[i][j] = (dp2[i][j]+dp2[i+1][j-1])%mod;
            }
            //printf("dp2 i = %d j = %d dp = %d\n",i,j,dp2[i][j]);
        }
    }
    ll ans = 0;
    for(int i = 1; i <=n;++i) {
        for(int j = 1; j <=n; ++j) {
        //for(int j = 1; j <=n; ++j) {
            //if(n-i<j)break;
            ans = (ans + ((1ll*j*dp1[i][j])%mod)*dp2[i+1][j])%mod;
        }
    }
    cout<<ans<<endl;

}

int main(){
    cin>>s+1;
    sol();
}