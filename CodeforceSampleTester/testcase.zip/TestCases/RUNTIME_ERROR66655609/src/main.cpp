    #include <bits/stdc++.h>
    using namespace std;

    #define RESET(ara, b) memset(ara, b, sizeof(ara))

    int ans[100005];
    int main()
    {
        int ara[5];
        RESET(ans, -1);
        for(int i = 0; i < 4; i++){
            cin>>ara[i];
        }
        int idx = 1;
        for(int i = 0; i < ara[0]; i++){
            ans[idx] = 0;
            idx += 2;
        }

        for(int i = 0; i < ara[2]; i++){
            ans[idx] = 2;
            idx += 2;
        }

        int last = idx-1;
        idx -= 3;

        int d = 0;
        for(int i = 0; i < ara[3]; i++){
            //cout<<d<<' '<<idx<<' '<<ans[idx+1]<<endl;
            if(idx == 0){
                if(ans[idx+1] == 2){
                    d++;
                    ans[idx] = 3;
                    idx -= 2;
                }
                continue;
            }
            if(idx < 0){
                if(ara[3]-d > 1){
                    cout<<"NO"<<endl;
                    return 0;
                }
                else{
                    break;
                }
            }
            if(ans[idx-1] == 2){
                ans[idx] = 3;
                d++;
                idx -= 2;
            }
            else{
                break;
            }
        }

        if(ara[3]-d == 1){
            if(last-1 < 0 || ans[last-1] == 2){
                ans[last] = 3;
                d++;
            }
        }
        if(d != ara[3]){
            cout<<"NO"<<endl;
            return 0;
        }
        for(int i = 2; i <= last && ara[1] > 0; i+=2){
            if(ans[i] == -1){
                ans[i] = 1;
                ara[1]--;
            }
            if(ara[1] == 0){
                break;
            }
        }
        if(ara[1] == 1){
            if(ans[0] == -1){
                ans[0] = 1;
                ara[1]--;
            }
        }
        if(ara[1] > 0){
            cout<<"NO"<<endl;
            return 0;
        }
        for(int i = 1; i < last; i++){
            if(ans[i] == -1){
                cout<<"NO"<<endl;
                return 0;
            }
        }
        cout<<"YES"<<endl;
        for(int i = 0; i <= last; i++){
            if(ans[i] != -1){
                cout<<ans[i]<<' ';
            }
        }
        cout<<endl;
    }
