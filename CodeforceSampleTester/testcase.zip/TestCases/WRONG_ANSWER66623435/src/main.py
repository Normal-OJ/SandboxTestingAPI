import os
T = int(input())
print (T)